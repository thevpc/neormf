package camaieu.common;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Hashtable;
import java.util.NoSuchElementException;

/**
 * Classe utilitaire pour la gestion des requets SQL
 *
 * @author tbensalah (Taha Ben Salah, ADD'IT Tunisie)
 * @creation_date date 27/01/2004
 * @last_modification_date date 01/08/2004
 * @status pour validation
 */
public final class QueryManager {
    // TODO en production remettre � false
    public static boolean NO_CACHE = false;
    private static Hashtable queries = new Hashtable();

    public static String getQuery(String queryId) throws NoSuchElementException {
        return getQuery(queryId, QueryManager.class.getClassLoader());
    }

    public static String getQuery(String queryId, ClassLoader classLoader) throws NoSuchElementException {
        String query = (String) queries.get(queryId);
        if (query == null) {
            String queryUrl = '/' + queryId.replace('.', '/') + ".sql";
            StringBuffer sb = null;
            try {
                BufferedReader r = new BufferedReader(new InputStreamReader(classLoader.getResource(queryUrl).openStream()));
                sb = new StringBuffer();
                String line = null;
                while ((line = r.readLine()) != null) {
                    if (line.trim().startsWith("--")) {
                        // do nothing
                    } else {
                        if (sb.length() > 0) {
                            sb.append("\n");
                        }
                        sb.append(line);
                    }
                }
                r.close();
            } catch (IOException e) {
                throw new NoSuchElementException(queryId + " : " + e.toString());
            }
            query = sb.toString().trim();
            if (!NO_CACHE) {
                queries.put(queryId, query);
            }
        }
        return query;
    }
}
