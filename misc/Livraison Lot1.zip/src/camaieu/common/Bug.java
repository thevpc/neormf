package camaieu.common;

/**
 * Class d�notant les Bugs
 * 
 * @author tbensalah (Taha Ben Salah, ADD'IT Tunisie)
 * @creation_date date Apr 18, 2004 � 9:36:29 AM
 * @last_modification_date date Apr 18, 2004 � 9:36:29 AM
 * @status pour validation
 */
public class Bug extends RuntimeException {
    public Bug() {
    }

    public Bug(String message) {
        super(message);
    }

    public Bug(Throwable cause) {
        super(cause);
    }

    public Bug(String message, Throwable cause) {
        super(message, cause);
    }
}
