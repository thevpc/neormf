package camaieu.common;

/**
 * Classe utilitaire d'ordre g�n�ral
 *
 * @author tbensalah (Taha Ben Salah, ADD'IT Tunisie)
 * @creation_date date 01/07/2004
 * @last_modification_date date 01/07/2004
 */

public final class Utils {
    private Utils() {
    }

    /**
     * comparaison de deux object pouvant �tre nuls
     *
     * @param o1
     * @param o2
     * @return
     */
    public static final boolean equals(Object o1, Object o2) {
        return (o1 == o2) || (o1 != null && o1.equals(o2));
    }

    public static String capitalize(String word) {

        if (word != null && word.length() > 0) {
            String w = word.toLowerCase();
            return Character.toUpperCase(w.charAt(0)) + w.substring(1);
        } else {
            return word;
        }
    }
}
