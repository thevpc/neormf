package camaieu.common;

import org.apache.log4j.Category;
import org.apache.log4j.Priority;
import wg4.bean.ancestor.BoAncestorBean;
import wg4.bean.ancestor.TechniqueException;
import wg4.fwk.dataobject.DataObject;
import wg4.fwk.dataobject.IDoDescription;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NameNotFoundException;
import javax.naming.NamingException;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * Classe de base pour les Bo.
 * <BR> Elle donne des facilit�s en plus que celles donn�es par BoAncestorBean.
 *
 * @author tbensalah (Taha Ben Salah, ADD'IT Tunisie)
 * @creation_date date 21/01/2004
 * @last_modification_date date 05/05/2004 (retreiveAll)
 * @last_modification_date date 07/05/2004 (retreiveAll x 3)
 * @status pour validation
 */
public class BoEasyAncestorBean extends BoAncestorBean {
    static {
        MAX_ROW = 10000;
    }

    /**
     * instance priv�e de DataObject
     */
    private DataObject sampleInstance;
    /**
     * instance priv�e de IDoDescription
     */
    private IDoDescription doDescInstance;

    /**
     * nom par d�faut de la datasource
     */
    private String defaultDatasourceName;

    /**
     * constructeur unique
     *
     * @param someDoClass           la classe des DataObjects associ�s
     * @param defaultDatasourceName nom par d�faut de la datasource
     */
    public BoEasyAncestorBean(Class someDoClass, String defaultDatasourceName) {
        this.defaultDatasourceName = defaultDatasourceName;
        try {
            sampleInstance = (DataObject) someDoClass.newInstance();
        } catch (InstantiationException e) {
            throw new ClassCastException(someDoClass + " is not a legal DataObject class");
        } catch (ClassCastException e) {
            throw new ClassCastException(someDoClass + " is not a legal DataObject class");
        } catch (IllegalAccessException e) {
            throw new ClassCastException(someDoClass + " is not a legal DataObject class");
        }
        doDescInstance = sampleInstance.getDescription();
    }

    /**
     * recharge toutes les donn�es du DataObject
     * d�crit par la clef primaire donn�e par <code>object</code>
     * <BR> la datasource par d�faut sera utilis�e
     *
     * @param object contient la clef (tous les champs de la clef primaire)
     * @return une nouvelle instance de DataObject contenant les champs charg�s
     * @throws TechniqueException
     */
    public DataObject reload(DataObject object) throws TechniqueException {
        return reload(defaultDatasourceName, object, null);
    }

    /**
     * recharge les champs <codes>fields</code> du DataObject
     * d�crit par la clef primaire donn�e par <code>object</code>
     * <BR> la datasource par d�faut sera utilis�e
     *
     * @param object contient la clef (tous les champs de la clef primaire)
     * @param fields la liste des champs � charger. si null, tous les champs seront charg�s
     * @return une nouvelle instance de DataObject contenant les champs charg�s
     * @throws TechniqueException
     */
    public DataObject reload(DataObject object, String[] fields) throws TechniqueException {
        return reload(defaultDatasourceName, object, fields);
    }

    /**
     * recharge les champs <codes>fields</code> du DataObject
     * d�crit par la clef primaire donn�e par <code>object</code>
     * <BR> la datasource <code>poolName</code> sera utilis�e
     *
     * @param poolName nom de la datasource
     * @param object   contient la clef (tous les champs de la clef primaire)
     * @param fields   la liste des champs � charger. si null, tous les champs seront charg�s
     * @return une nouvelle instance de DataObject contenant les champs charg�s
     * @throws TechniqueException
     */
    public DataObject reload(String poolName, DataObject object, String[] fields) throws TechniqueException {
        if (object == null) {
            throw new NullPointerException("Object could not be null");
        }
        // ce code est d�sactiv� � cause d'un probl�me sur tomcat
//        if(sampleInstance.getClass().isAssignableFrom(object.getClass())){
//            throw new ClassCastException("Object must be from class "+sampleInstance.getClass()+" but class "+object.getClass()+" was found");
//        }
        StringBuffer sb = new StringBuffer();
        sb.append("Select ");
        if (fields == null || fields.length == 0) {
            sb.append("*");
        } else {
            for (int i = 0; i < fields.length; i++) {
                if (i > 0) {
                    sb.append(",");
                }
                sb.append(fields[i]);
            }
        }
        sb.append(" FROM ");
        sb.append(doDescInstance.getTableName());
        sb.append(" WHERE ");
        Object[] key = getKey(object);
        String[] pkKeys = doDescInstance.getPkColName();
        for (int i = 0; i < pkKeys.length; i++) {
            if (i > 0) {
                sb.append(" AND ");
            }
            sb.append(pkKeys[i]);
            sb.append("= ? ");
        }
        DataObject[][] o = retrieve(poolName, sb.toString(), key, new Class[]{sampleInstance.getClass()}, 0, 1);
        if (o.length == 0 || o[0].length == 0) {
            return null;
        } else {
            return o[0][0];
        }
    }

    /**
     * charge les colonnes <code>fields</code> de toutes les lignes de la table
     *
     * @param poolName nom de la datasource
     * @param fields   les champs � charger, si nul tous les champs seront charg�s
     * @return
     * @throws TechniqueException
     */
    public DataObject[] retrieveAll(String poolName, String[] fields) throws TechniqueException {
        StringBuffer sb = new StringBuffer();
        sb.append("Select ");
        if (fields == null || fields.length == 0) {
            sb.append("*");
        } else {
            for (int i = 0; i < fields.length; i++) {
                if (i > 0) {
                    sb.append(",");
                }
                sb.append(fields[i]);
            }
        }
        sb.append(" FROM ");
        sb.append(doDescInstance.getTableName());
        return retrieve(poolName, sb.toString(), new Object[0], new Class[]{sampleInstance.getClass()})[0];
    }

    /**
     * charge les colonnes <code>fields</code> de toutes les lignes de la table
     *
     * @param poolName nom de la datasource
     * @param fields   les champs � charger, si nul tous les champs seront charg�s
     * @return
     * @throws TechniqueException
     * @since 2.0
     */
    public DataObject[] retrieveAll(String poolName, DataObject sampleInstance, String[] fields, String joins, String whereClause, String orderByClause) throws TechniqueException {
        return retrieveAll(poolName, sampleInstance, sampleInstance.getDescription(), fields, joins, whereClause, orderByClause, false);
    }

    /**
     * charge les colonnes <code>fields</code> de toutes les lignes de la table
     *
     * @param poolName nom de la datasource
     * @param fields   les champs � charger, si nul tous les champs seront charg�s
     * @return
     * @throws TechniqueException
     * @since 2.0
     */
    public DataObject[] retrieveAll(String poolName, DataObject sampleInstance, String[] fields, String joins, String whereClause, String orderByClause, boolean selectDistinct) throws TechniqueException {
        return retrieveAll(poolName, sampleInstance, sampleInstance.getDescription(), fields, joins, whereClause, orderByClause, selectDistinct);
    }

    /**
     * charge les colonnes <code>fields</code> de toutes les lignes de la table
     *
     * @param poolName nom de la datasource
     * @param fields   les champs � charger, si nul tous les champs seront charg�s
     * @return
     * @throws TechniqueException
     * @since 2.0
     */
    public DataObject[] retrieveAll(String poolName, String[] fields, String joins, String whereClause, String orderByClause) throws TechniqueException {
        return retrieveAll(poolName, sampleInstance, doDescInstance, fields, joins, whereClause, orderByClause);
    }

    /**
     * charge les colonnes <code>fields</code> de toutes les lignes de la table
     *
     * @param poolName nom de la datasource
     * @param fields   les champs � charger, si nul tous les champs seront charg�s
     * @return
     * @throws TechniqueException
     * @since 2.0
     */
    private DataObject[] retrieveAll(String poolName, DataObject sampleInstance, IDoDescription doDescInstance, String[] fields, String joins, String whereClause, String orderByClause) throws TechniqueException {
        return retrieveAll(poolName, sampleInstance, doDescInstance, fields, joins, whereClause, orderByClause, false);
    }

    /**
     * charge les colonnes <code>fields</code> de toutes les lignes de la table
     *
     * @param poolName nom de la datasource
     * @param fields   les champs � charger, si nul tous les champs seront charg�s
     * @return
     * @throws TechniqueException
     * @since 2.0
     */
    private DataObject[] retrieveAll(String poolName, DataObject sampleInstance, IDoDescription doDescInstance, String[] fields, String joins, String whereClause, String orderByClause, boolean selectDistinct) throws TechniqueException {
        StringBuffer sb = new StringBuffer();
        sb.append("Select ");
        if (selectDistinct) {
            sb.append(" DISTINCT ");
        }
        if (fields == null || fields.length == 0) {
            sb.append("*");
        } else {
            for (int i = 0; i < fields.length; i++) {
                if (i > 0) {
                    sb.append(",");
                }
                sb.append(fields[i]);
            }
        }
        sb.append(" FROM ");
        sb.append(doDescInstance.getTableName());
        if (joins != null && joins.length() > 0) {
            sb.append(",");
            sb.append(joins);
            sb.append(" ");
        }
        if (whereClause != null && whereClause.length() > 0) {
            sb.append(" WHERE ");
            sb.append(whereClause);
            sb.append(" ");
        }

        if (orderByClause != null && orderByClause.length() > 0) {
            sb.append(" ORDER BY ");
            sb.append(orderByClause);
            sb.append(" ");
        }
        return retrieve(poolName, sb.toString(), new Object[0], new Class[]{sampleInstance.getClass()})[0];
    }

    /**
     * r�cup�re la clef � partir d'un DataObject
     *
     * @param dataObject contient la clef (tous les champs de la clef primaire)
     * @return la clef primaire
     * @throws IllegalArgumentException si l'un des champs de la clef est nul
     */
    public Object[] getKey(DataObject dataObject) throws IllegalArgumentException {
        int[] pkKeysIndexes = doDescInstance.getPkColNum();
        Object[] keyValues = new Object[pkKeysIndexes.length];
        for (int i = 0; i < keyValues.length; i++) {
            keyValues[i] = dataObject.get(pkKeysIndexes[i]);
            if (keyValues[i] == null) {
                throw new IllegalArgumentException("Key cannot be null. Expected non null value for key part (index " + i + ") " + doDescInstance.getTableName() + "." + doDescInstance.getPkColName()[i]);
            }
        }
        return keyValues;
    }

    /**
     * default datasource name
     *
     * @return
     */
    public String getDefaultDatasourceName() {
        return defaultDatasourceName;
    }

    /**
     * default datasource name
     *
     * @param defaultDatasourceName
     */
    public void setDefaultDatasourceName(String defaultDatasourceName) {
        this.defaultDatasourceName = defaultDatasourceName;
    }

    /**
     * foinction redefinie pour etre protected
     *
     * @param poolName
     * @return
     * @throws TechniqueException
     */
    protected java.sql.Connection getConnection(String poolName) throws TechniqueException {
        Connection localConn;
        try {
            Context ctx = new InitialContext();
/*			NamingEnumeration e = ctx.list("java:comp/env");
			while (e.hasMoreElements()) {
				Object o = e.next();
				System.out.println(o);
			}
*/			ctx = (Context) ctx.lookup("java:comp/env");

            if (poolName == null)
                poolName = JNDI_NAME;
            DataSource ds = (javax.sql.DataSource) ctx.lookup(poolName);
            if (JDBC_USER == null)
                localConn = ds.getConnection();
            else
                localConn = ds.getConnection(JDBC_USER, JDBC_PWD);
        } catch (NameNotFoundException e) {
            throw new TechniqueException("Le pool de connection " + poolName + " est inconnu. V�rifiez le param�trage du serveur d'application");
        } catch (NamingException e) {
            throw new TechniqueException("Erreur lors de la r�cup�ration du pool de connection " + poolName, e);
        } catch (SQLException e) {
            throw new TechniqueException("Erreur lors de la connection ", e);
        } catch (Throwable t) {
            throw new TechniqueException(t);
        }
        return localConn;
    }

    protected java.sql.Connection getConnection() throws TechniqueException {
        return getConnection(getDefaultDatasourceName());
    }


    /**
     * fonction redefinie pour pouvoir gerer le nombre maximum d'�lements retourn�s
     *
     * @param poolName
     * @param query
     * @param param
     * @param maxElements
     * @return
     * @throws TechniqueException
     * @author taha BEN SALAH (ADD'IT Tunisie)
     * @creation_date 01/08/2004
     */
    public Object[][] retrieve(String poolName, String query, Object[] param, int maxElements) throws TechniqueException {
        /*
         * Pr�paration de l'objet de Log
         */
        Category logger = Category.getInstance(this.getClass().getName() + ".retrieve");

        Connection conn = getConnection(poolName);
        /*
         * log de la requ�te en type INFO
         */
        long time = 0;
        if (logger.isInfoEnabled()) {
            time = System.currentTimeMillis();
            StringBuffer buffer = new StringBuffer();
            for (int i = 0; i < param.length; i++) {
                buffer.append("[" + i + ";");
                if (param[i] == null)
                    buffer.append("null");
                else if (param[i] instanceof Object)
                    buffer.append(param[i].getClass().getName() + "," + param[i]);
                else
                    buffer.append("primitif," + param[i]);
                buffer.append("]");
            }
            logger.info("D�but retrieve-objet " + query + buffer.toString());
        }
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Object[][] result = null;
        try {
            stmt = conn.prepareStatement(query);
            for (int i = 0; i < param.length; i++) {
                stmt.setObject(i + 1, param[i]);
            }
            rs = stmt.executeQuery();
            if (rs == null) return null;
            int nbCol = rs.getMetaData().getColumnCount();
            Object[] row;
            ArrayList tempRes = new ArrayList();
            if (maxElements > 0) {
                int elements = 0;
                while (elements < maxElements && rs.next()) {
                    row = new Object[nbCol];
                    for (int i = 0; i < nbCol; i++) {
                        row[i] = rs.getObject(i + 1);
                    }
                    tempRes.add(row);
                    elements++;
                }
            } else {
                while (rs.next()) {
                    row = new Object[nbCol];
                    for (int i = 0; i < nbCol; i++) {
                        row[i] = rs.getObject(i + 1);
                    }
                    tempRes.add(row);
                }
            }
            result = (Object[][]) tempRes.toArray(new Object[tempRes.size()][nbCol]);
        } catch (SQLException e) {
            /*
             * log de l'erreur en type ERROR
             */
            if (logger.isEnabledFor(Priority.ERROR)) {
                StringBuffer buffer = new StringBuffer();
                for (int i = 0; i < param.length; i++) {
                    buffer.append("[" + i + ";");
                    if (param[i] == null)
                        buffer.append("null");
                    else if (param[i] instanceof Object)
                        buffer.append(param[i].getClass().getName() + "," + param[i]);
                    else
                        buffer.append("primitif," + param[i]);
                    buffer.append("]");
                }
                logger.error("Erreur SQL pour :" + query + buffer.toString(), e);
            }
            throw new TechniqueException("Erreur SQL:" + e.getMessage(), e);
        } finally   // code de nettoyage ex�cut� quel que soit le r�sultat de la clause try
        {
            try {
                rs.close();
            } catch (Throwable e) {
            }
            rs = null;
            try {
                stmt.close();
            } catch (Throwable e) {
            }
            stmt = null;
            try {
                if (!MOD_DEV) {
                    conn.close();
                    conn = null;
                }
            } catch (Throwable e) {
            }
            /*
             * log de la fin de la requ�te en type INFO. Possibilit� de logger en type WARN en fonction du temps de la requ�te !!!!
             */
            if (logger.isInfoEnabled()) {
                time = System.currentTimeMillis() - time;
                logger.info("Fin requ�te " + query + " en " + time + " avec " + result.length + " lignes");
            }
        }
        return result;
    }
}
