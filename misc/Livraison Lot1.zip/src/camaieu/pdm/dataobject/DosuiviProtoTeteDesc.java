package camaieu.pdm.dataobject;

import wg4.fwk.dataobject.IDoDescription;

import java.util.HashMap;

/**
 * /* Description de l'objetDosuiviProtoTete correspondant � la table SUIVI_PROTO_TETE
 */
public class DosuiviProtoTeteDesc implements IDoDescription {
    public static final int SPT_MODELE_CODE = 0;
    public static final int SPT_CLT_AN = 1;
    public static final int SPT_CLT_SAI_CODE = 2;
    public static final int SPT_CLT_CODE = 3;
    public static final int SPT_NOM_MODELE = 4;
    public static final int SPT_REF_NODHOS = 5;
    public static final int SPT_FAA_CODE = 6;
    public static final int SPT_SFA_CODE = 7;
    public static final int SPT_QUALITE = 8;
    public static final int SPT_LAVAGE = 9;
    public static final int SPT_FOU_CODE_TISSU = 10;
    public static final int SPT_BUREAU_TYPE = 11;
    public static final int SPT_BUREAU_CODE = 12;
    public static final int SPT_FAC_CODE = 13;
    public static final int SPT_DT_TRANSMISSION = 14;
    public static final int SPT_DT_ENV_FTECH_BUR = 15;
    public static final int SPT_DT_ENV_CT_BUR = 16;
    public static final int SPT_DT_RECEP_FTECH_BUR = 17;
    public static final int SPT_DT_RECEP_CT_BUR = 18;
    public static final int SPT_ENV_CTYPE_ESSAI_MAT = 19;
    public static final int SPT_PRIX_FACON = 20;
    public static final int SPT_EMP_PROVISOIRE = 21;
    public static final int SPT_RECEP_DISQ_PAT = 22;
    public static final int SPT_DT_ENV_PATRONAGE = 23;
    public static final int SPT_DT_RECEP_PAT = 24;
    public static final int SPT_DT_ENV_FTECH_FAC = 25;
    public static final int SPT_DT_ENV_CT_FAC = 26;
    public static final int SPT_DT_RECEP_FTECH_FAC = 27;
    public static final int SPT_DT_RECEP_CT_FAC = 28;
    public static final int SPT_DDE_TETE_SERIE = 29;
    public static final int SPT_TETE_SERIE = 30;
    public static final int SPT_OK_ACCESSOIRES = 31;
    public static final int SPT_OK_COLORIS = 32;
    public static final int SPT_EMPLOI_DEF = 33;
    public static final int SPT_OK_PROD_ENTREP = 34;
    public static final int SPT_OK_MATIERE = 35;
    public static final int SPT_DEBUT_PROD = 36;
    public static final int SPT_VALID_ECHAN_SOURCE = 37;
    public static final int SPT_COMMENT_ACHATS = 38;
    public static final int SPT_COMMENT_MODELISTE = 39;
    public static final int SPT_COMMENT_BUREAU = 40;
    public static final int SPT_STATUS = 41;
    public static final int SPT_PIC_TISSU = 42;
    public static final int SPT_PIC_MODELE = 43;

    public static final String tableName = "SUIVI_PROTO_TETE";

    /*
     * Liste des noms de colonnes
     */
    public static final String[] dbColName = new String[]{
        "SPT_MODELE_CODE", "SPT_CLT_AN", "SPT_CLT_SAI_CODE", "SPT_CLT_CODE", "SPT_NOM_MODELE", "SPT_REF_NODHOS", "SPT_FAA_CODE", "SPT_SFA_CODE", "SPT_QUALITE", "SPT_LAVAGE", "SPT_FOU_CODE_TISSU", "SPT_BUREAU_TYPE", "SPT_BUREAU_CODE", "SPT_FAC_CODE", "SPT_DT_TRANSMISSION", "SPT_DT_ENV_FTECH_BUR", "SPT_DT_ENV_CT_BUR", "SPT_DT_RECEP_FTECH_BUR", "SPT_DT_RECEP_CT_BUR", "SPT_ENV_CTYPE_ESSAI_MAT", "SPT_PRIX_FACON", "SPT_EMP_PROVISOIRE", "SPT_RECEP_DISQ_PAT", "SPT_DT_ENV_PATRONAGE", "SPT_DT_RECEP_PAT", "SPT_DT_ENV_FTECH_FAC", "SPT_DT_ENV_CT_FAC", "SPT_DT_RECEP_FTECH_FAC", "SPT_DT_RECEP_CT_FAC", "SPT_DDE_TETE_SERIE", "SPT_TETE_SERIE", "SPT_OK_ACCESSOIRES", "SPT_OK_COLORIS", "SPT_EMPLOI_DEF", "SPT_OK_PROD_ENTREP", "SPT_OK_MATIERE", "SPT_DEBUT_PROD", "SPT_VALID_ECHAN_SOURCE", "SPT_COMMENT_ACHATS", "SPT_COMMENT_MODELISTE", "SPT_COMMENT_BUREAU", "SPT_STATUS", "SPT_PIC_TISSU", "SPT_PIC_MODELE"};
    private static final HashMap colBase;

    static {
        colBase = new HashMap(44);
        colBase.put("SPT_MODELE_CODE", new Integer(SPT_MODELE_CODE));
        colBase.put("SPT_CLT_AN", new Integer(SPT_CLT_AN));
        colBase.put("SPT_CLT_SAI_CODE", new Integer(SPT_CLT_SAI_CODE));
        colBase.put("SPT_CLT_CODE", new Integer(SPT_CLT_CODE));
        colBase.put("SPT_NOM_MODELE", new Integer(SPT_NOM_MODELE));
        colBase.put("SPT_REF_NODHOS", new Integer(SPT_REF_NODHOS));
        colBase.put("SPT_FAA_CODE", new Integer(SPT_FAA_CODE));
        colBase.put("SPT_SFA_CODE", new Integer(SPT_SFA_CODE));
        colBase.put("SPT_QUALITE", new Integer(SPT_QUALITE));
        colBase.put("SPT_LAVAGE", new Integer(SPT_LAVAGE));
        colBase.put("SPT_FOU_CODE_TISSU", new Integer(SPT_FOU_CODE_TISSU));
        colBase.put("SPT_BUREAU_TYPE", new Integer(SPT_BUREAU_TYPE));
        colBase.put("SPT_BUREAU_CODE", new Integer(SPT_BUREAU_CODE));
        colBase.put("SPT_FAC_CODE", new Integer(SPT_FAC_CODE));
        colBase.put("SPT_DT_TRANSMISSION", new Integer(SPT_DT_TRANSMISSION));
        colBase.put("SPT_DT_ENV_FTECH_BUR", new Integer(SPT_DT_ENV_FTECH_BUR));
        colBase.put("SPT_DT_ENV_CT_BUR", new Integer(SPT_DT_ENV_CT_BUR));
        colBase.put("SPT_DT_RECEP_FTECH_BUR", new Integer(SPT_DT_RECEP_FTECH_BUR));
        colBase.put("SPT_DT_RECEP_CT_BUR", new Integer(SPT_DT_RECEP_CT_BUR));
        colBase.put("SPT_ENV_CTYPE_ESSAI_MAT", new Integer(SPT_ENV_CTYPE_ESSAI_MAT));
        colBase.put("SPT_PRIX_FACON", new Integer(SPT_PRIX_FACON));
        colBase.put("SPT_EMP_PROVISOIRE", new Integer(SPT_EMP_PROVISOIRE));
        colBase.put("SPT_RECEP_DISQ_PAT", new Integer(SPT_RECEP_DISQ_PAT));
        colBase.put("SPT_DT_ENV_PATRONAGE", new Integer(SPT_DT_ENV_PATRONAGE));
        colBase.put("SPT_DT_RECEP_PAT", new Integer(SPT_DT_RECEP_PAT));
        colBase.put("SPT_DT_ENV_FTECH_FAC", new Integer(SPT_DT_ENV_FTECH_FAC));
        colBase.put("SPT_DT_ENV_CT_FAC", new Integer(SPT_DT_ENV_CT_FAC));
        colBase.put("SPT_DT_RECEP_FTECH_FAC", new Integer(SPT_DT_RECEP_FTECH_FAC));
        colBase.put("SPT_DT_RECEP_CT_FAC", new Integer(SPT_DT_RECEP_CT_FAC));
        colBase.put("SPT_DDE_TETE_SERIE", new Integer(SPT_DDE_TETE_SERIE));
        colBase.put("SPT_TETE_SERIE", new Integer(SPT_TETE_SERIE));
        colBase.put("SPT_OK_ACCESSOIRES", new Integer(SPT_OK_ACCESSOIRES));
        colBase.put("SPT_OK_COLORIS", new Integer(SPT_OK_COLORIS));
        colBase.put("SPT_EMPLOI_DEF", new Integer(SPT_EMPLOI_DEF));
        colBase.put("SPT_OK_PROD_ENTREP", new Integer(SPT_OK_PROD_ENTREP));
        colBase.put("SPT_OK_MATIERE", new Integer(SPT_OK_MATIERE));
        colBase.put("SPT_DEBUT_PROD", new Integer(SPT_DEBUT_PROD));
        colBase.put("SPT_VALID_ECHAN_SOURCE", new Integer(SPT_VALID_ECHAN_SOURCE));
        colBase.put("SPT_COMMENT_ACHATS", new Integer(SPT_COMMENT_ACHATS));
        colBase.put("SPT_COMMENT_MODELISTE", new Integer(SPT_COMMENT_MODELISTE));
        colBase.put("SPT_COMMENT_BUREAU", new Integer(SPT_COMMENT_BUREAU));
        colBase.put("SPT_STATUS", new Integer(SPT_STATUS));
        colBase.put("SPT_PIC_TISSU", new Integer(SPT_PIC_TISSU));
        colBase.put("SPT_PIC_MODELE", new Integer(SPT_PIC_MODELE));
    }

    /*
     * Noms de colonnes de la cl� primaire
     */
    private static final String[] pkColName = new String[]{
        "SPT_MODELE_CODE"};

    private static final int[] pkColNum = new int[]{0};

    private static final HashMap fkColName = new HashMap(0);

    static {
        fkColName.put("ALERTES", new String[]{
            "SPT_MODELE_CODE"
        });
        fkColName.put("FICHIERS", new String[]{
            "SPT_MODELE_CODE"
        });
        fkColName.put("SUIVI_PROTO_MAP", new String[]{
            "SPT_MODELE_CODE"
        });
        fkColName.put("SUIVI_PROTO_PROD", new String[]{
            "SPT_MODELE_CODE"
        });
    }


    private static final HashMap fkColNum = new HashMap(0);

    static {
        fkColNum.put("ALERTES", new int[]{
            0
        });
        fkColNum.put("FICHIERS", new int[]{
            0
        });
        fkColNum.put("SUIVI_PROTO_MAP", new int[]{
            0
        });
        fkColNum.put("SUIVI_PROTO_PROD", new int[]{
            0
        });
    }

    /**
     * @see IDoDescription.getTableName()
     */
    public String getTableName() {
        return tableName;
    }

    /**
     * @see IDoDescription.getDbColName()
     */
    public String[] getDbColName() {
        return dbColName;
    }

    /**
     * @see IDoDescription.getDbColNum()
     */
    public HashMap getDbColNum() {
        return colBase;
    }

    /**
     * @see IDoDescription.getPkColName()
     */
    public String[] getPkColName() {
        return pkColName;
    }

    /**
     * @see IDoDescription.getPkColNum()
     */
    public int[] getPkColNum() {
        return pkColNum;
    }
    /**
     * @see IDoDescription.getPkColNumInsert()
     */
    /**
     * @see IDoDescription.getFkColName()
     */
    public String[] getFkColName(String tableName) {
        return (String[]) fkColName.get(tableName);
    }

    /**
     * @see IDoDescription.getFkColNum()
     */
    public int[] getFkColNum(String tableName) {
        return (int[]) fkColNum.get(tableName);
    }
}
