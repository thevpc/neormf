package camaieu.pdm.dataobject;

import wg4.fwk.dataobject.DataObject;
import wg4.fwk.dataobject.IDoDescription;
import wg4.fwk.dataobject.ParameterException;
import wg4.fwk.dataobject.SqlArg;
import wg4.fwk.mvc.tool.StrConvertor;

import javax.servlet.http.HttpServletRequest;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.HashSet;

public class DoaccessLog implements DataObject {

    private static final IDoDescription description = new DoaccessLogDesc();
    private transient int persist = PERSIST_UPDATE_INSERT;
    private transient int[] updCol = new int[2];
    private transient String sql;
    private transient Object[] param;

//tables correspondantes
    private static final String[] tableNames = new String[]{"ACCESS_LOG"};
    //variables correspondant � la table ACCESS_LOG
    private String logFouCode = null;
    private Timestamp logDate = null;

    /**
     * Constructeur utilis� par la m�thode setPropertie
     */
    public DoaccessLog() {
    }

    /**
     * Constructeur permettant d'initialiser le type de persistance
     */
    public DoaccessLog(int persistTyp) {
        persist = persistTyp;
    }

    /**
     * Constructeur permettant d'initialiser le type de persistance
     */
    public DoaccessLog(DoaccessLog arg) {
        setLogFouCode(arg.logFouCode);
        setLogDate(arg.logDate);
    }

    /**
     * Constructeur utilis� par la m�thode retrieve
     */
    public DoaccessLog(String newSql, Object[] newParam) {
        sql = newSql;
        param = newParam;
    }

    public int getPersist() {
        return persist;
    }

    public void setPersist(int newPersist) {
        persist = newPersist;
    }

    public void resetUpdate() {
        Arrays.fill(updCol, -1);
    }

    public Object[] getParam() {
        return param;
    }

    public String getSQL() {
        return sql;
    }

    public HashSet getColNotInsertable() {
        return null;
    }

    public String getLogFouCode() {
        return logFouCode;
    }

    public Timestamp getLogDate() {
        return logDate;
    }

    public void setLogFouCode(String newLogFouCode) {
        logFouCode = newLogFouCode;
        if (persist > 0)
            updCol[DoaccessLogDesc.LOG_FOU_CODE] = 1;
    }

    public void setLogDate(Timestamp newLogDate) {
        logDate = newLogDate;
        if (persist > 0)
            updCol[DoaccessLogDesc.LOG_DATE] = 1;
    }

    public Object get(int numCol) {
        if (numCol == DoaccessLogDesc.LOG_FOU_CODE)
            return logFouCode;
        else if (numCol == DoaccessLogDesc.LOG_DATE)
            return logDate;
        return null;
    }

    public void set(int numCol, Object value) {
        if (numCol == DoaccessLogDesc.LOG_FOU_CODE) {
            logFouCode = (String) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DoaccessLogDesc.LOG_DATE) {
            logDate = (Timestamp) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
    }

    public DataObject setProperty(SqlArg sqlArg) throws SQLException {
        return setProperty(sqlArg, new DoaccessLog());
    }

    private DataObject setProperty(SqlArg sqlArg, DoaccessLog djo) throws SQLException {
        ResultSet rs = sqlArg.getResultSet();
        int[] val = sqlArg.getVal();
        if (val[DoaccessLogDesc.LOG_FOU_CODE] != -1) {
            djo.logFouCode = rs.getString(val[DoaccessLogDesc.LOG_FOU_CODE]);
        }
        if (val[DoaccessLogDesc.LOG_DATE] != -1) {
            djo.logDate = rs.getTimestamp(val[DoaccessLogDesc.LOG_DATE]);
        }
        return djo;
    }

    public void getProperty(SqlArg sqlArg) throws SQLException {
        PreparedStatement stmt = sqlArg.getStmt();
        int[] val = sqlArg.getVal();
        if (val[DoaccessLogDesc.LOG_FOU_CODE] > 0) {
            stmt.setString(val[DoaccessLogDesc.LOG_FOU_CODE], logFouCode);
        }
        if (val[DoaccessLogDesc.LOG_DATE] > 0) {
            stmt.setTimestamp(val[DoaccessLogDesc.LOG_DATE], logDate);
        }
    }

    /**
     * M�thode g�n�r�e automatiquement permettant de remplir un dataobject � partir des valeurs
     * d'une requ�te http.
     * Les noms des param�tres de la requ�te doivent �tre strictement identique aux noms des attributs du DataObject.
     * Cette m�thode peut �tre compl�t�e afin de prendre en compte d'�ventuels param�tres se trouvant en session.
     * Pour une reg�n�ration �ventuelle, faites attention � ne coder qu'entre les tags de d�but et de fin.
     * Date de cr�ation : (25/05/01 08:03:14)
     *
     * @param request javax.servlet.http.HttpServletRequest
     */
    public DataObject[] setParameters(HttpServletRequest request)
            throws ParameterException, java.text.ParseException {
        String[] params = null;
        String localVal = null;
        int size = 0;
        DoaccessLog[] result = null;
        params = request.getParameterValues("logFouCode");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoaccessLog[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoaccessLog();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setLogFouCode(localVal);
            }
        }
        params = request.getParameterValues("logDate");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoaccessLog[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoaccessLog();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setLogDate((Timestamp) StrConvertor.convert(localVal, Timestamp.class));
            }
        }
        /************************ INSTRUCTIONS DEVELOPPEMENT SPECIFIQUE *******************/
        /********************** FIN INSTRUCTIONS DEVELOPPEMENT SPECIFIQUE *****************/
        return result;
    }

    /*
     * @see DataObject#addChild(DataObject)
     */
    public void addChild(DataObject doChild) {
    }

    /*
     * @see DataObject#getDescription()
     */
    public IDoDescription getDescription() {
        return description;
    }

    /*
     * @see DataObject#getUpdateCol()
     */
    public int[] getUpdateCol() {
        return updCol;
    }

}
