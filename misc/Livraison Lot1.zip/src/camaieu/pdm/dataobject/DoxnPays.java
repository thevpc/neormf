package camaieu.pdm.dataobject;

import wg4.fwk.dataobject.DataObject;
import wg4.fwk.dataobject.IDoDescription;
import wg4.fwk.dataobject.ParameterException;
import wg4.fwk.dataobject.SqlArg;
import wg4.fwk.mvc.tool.StrConvertor;

import javax.servlet.http.HttpServletRequest;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.HashSet;

public class DoxnPays implements DataObject {

    private static final IDoDescription description = new DoxnPaysDesc();
    private transient int persist = PERSIST_UPDATE_INSERT;
    private transient int[] updCol = new int[12];
    private transient String sql;
    private transient Object[] param;

//tables correspondantes
    private static final String[] tableNames = new String[]{"XN_PAYS"};
    //variables correspondant � la table XN_PAYS
    private String payCode = null;
    private String payNom = null;
    private String payNomInt = null;
    private String payNomGpe = null;
    private String payCee = null;
    private String payNoCee = null;
    private Integer payNoOrdre = null;
    private Timestamp payDtCreat = null;
    private Timestamp payDtMaj = null;
    private String payUtilMaj = null;
    private Integer xtxId = null;
    private String zStatus = null;

    /**
     * Constructeur utilis� par la m�thode setPropertie
     */
    public DoxnPays() {
    }

    /**
     * Constructeur permettant d'initialiser le type de persistance
     */
    public DoxnPays(int persistTyp) {
        persist = persistTyp;
    }

    /**
     * Constructeur permettant d'initialiser le type de persistance
     */
    public DoxnPays(DoxnPays arg) {
        setPayCode(arg.payCode);
        setPayNom(arg.payNom);
        setPayNomInt(arg.payNomInt);
        setPayNomGpe(arg.payNomGpe);
        setPayCee(arg.payCee);
        setPayNoCee(arg.payNoCee);
        setPayNoOrdre(arg.payNoOrdre);
        setPayDtCreat(arg.payDtCreat);
        setPayDtMaj(arg.payDtMaj);
        setPayUtilMaj(arg.payUtilMaj);
        setXtxId(arg.xtxId);
        setZStatus(arg.zStatus);
    }

    /**
     * Constructeur utilis� par la m�thode retrieve
     */
    public DoxnPays(String newSql, Object[] newParam) {
        sql = newSql;
        param = newParam;
    }

    public int getPersist() {
        return persist;
    }

    public void setPersist(int newPersist) {
        persist = newPersist;
    }

    public void resetUpdate() {
        Arrays.fill(updCol, -1);
    }

    public Object[] getParam() {
        return param;
    }

    public String getSQL() {
        return sql;
    }

    public HashSet getColNotInsertable() {
        return null;
    }

    public String getPayCode() {
        return payCode;
    }

    public String getPayNom() {
        return payNom;
    }

    public String getPayNomInt() {
        return payNomInt;
    }

    public String getPayNomGpe() {
        return payNomGpe;
    }

    public String getPayCee() {
        return payCee;
    }

    public String getPayNoCee() {
        return payNoCee;
    }

    public Integer getPayNoOrdre() {
        return payNoOrdre;
    }

    public Timestamp getPayDtCreat() {
        return payDtCreat;
    }

    public Timestamp getPayDtMaj() {
        return payDtMaj;
    }

    public String getPayUtilMaj() {
        return payUtilMaj;
    }

    public Integer getXtxId() {
        return xtxId;
    }

    public String getZStatus() {
        return zStatus;
    }

    public void setPayCode(String newPayCode) {
        payCode = newPayCode;
    }

    public void setPayNom(String newPayNom) {
        payNom = newPayNom;
        if (persist > 0)
            updCol[DoxnPaysDesc.PAY_NOM] = 1;
    }

    public void setPayNomInt(String newPayNomInt) {
        payNomInt = newPayNomInt;
        if (persist > 0)
            updCol[DoxnPaysDesc.PAY_NOM_INT] = 1;
    }

    public void setPayNomGpe(String newPayNomGpe) {
        payNomGpe = newPayNomGpe;
        if (persist > 0)
            updCol[DoxnPaysDesc.PAY_NOM_GPE] = 1;
    }

    public void setPayCee(String newPayCee) {
        payCee = newPayCee;
        if (persist > 0)
            updCol[DoxnPaysDesc.PAY_CEE] = 1;
    }

    public void setPayNoCee(String newPayNoCee) {
        payNoCee = newPayNoCee;
        if (persist > 0)
            updCol[DoxnPaysDesc.PAY_NO_CEE] = 1;
    }

    public void setPayNoOrdre(Integer newPayNoOrdre) {
        payNoOrdre = newPayNoOrdre;
        if (persist > 0)
            updCol[DoxnPaysDesc.PAY_NO_ORDRE] = 1;
    }

    public void setPayDtCreat(Timestamp newPayDtCreat) {
        payDtCreat = newPayDtCreat;
        if (persist > 0)
            updCol[DoxnPaysDesc.PAY_DT_CREAT] = 1;
    }

    public void setPayDtMaj(Timestamp newPayDtMaj) {
        payDtMaj = newPayDtMaj;
        if (persist > 0)
            updCol[DoxnPaysDesc.PAY_DT_MAJ] = 1;
    }

    public void setPayUtilMaj(String newPayUtilMaj) {
        payUtilMaj = newPayUtilMaj;
        if (persist > 0)
            updCol[DoxnPaysDesc.PAY_UTIL_MAJ] = 1;
    }

    public void setXtxId(Integer newXtxId) {
        xtxId = newXtxId;
        if (persist > 0)
            updCol[DoxnPaysDesc.XTX_ID] = 1;
    }

    public void setZStatus(String newZStatus) {
        zStatus = newZStatus;
        if (persist > 0)
            updCol[DoxnPaysDesc.Z_STATUS] = 1;
    }

    public Object get(int numCol) {
        if (numCol == DoxnPaysDesc.PAY_CODE)
            return payCode;
        else if (numCol == DoxnPaysDesc.PAY_NOM)
            return payNom;
        else if (numCol == DoxnPaysDesc.PAY_NOM_INT)
            return payNomInt;
        else if (numCol == DoxnPaysDesc.PAY_NOM_GPE)
            return payNomGpe;
        else if (numCol == DoxnPaysDesc.PAY_CEE)
            return payCee;
        else if (numCol == DoxnPaysDesc.PAY_NO_CEE)
            return payNoCee;
        else if (numCol == DoxnPaysDesc.PAY_NO_ORDRE)
            return payNoOrdre;
        else if (numCol == DoxnPaysDesc.PAY_DT_CREAT)
            return payDtCreat;
        else if (numCol == DoxnPaysDesc.PAY_DT_MAJ)
            return payDtMaj;
        else if (numCol == DoxnPaysDesc.PAY_UTIL_MAJ)
            return payUtilMaj;
        else if (numCol == DoxnPaysDesc.XTX_ID)
            return xtxId;
        else if (numCol == DoxnPaysDesc.Z_STATUS)
            return zStatus;
        return null;
    }

    public void set(int numCol, Object value) {
        if (numCol == DoxnPaysDesc.PAY_CODE) {
            payCode = (String) value;
        }
        if (numCol == DoxnPaysDesc.PAY_NOM) {
            payNom = (String) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DoxnPaysDesc.PAY_NOM_INT) {
            payNomInt = (String) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DoxnPaysDesc.PAY_NOM_GPE) {
            payNomGpe = (String) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DoxnPaysDesc.PAY_CEE) {
            payCee = (String) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DoxnPaysDesc.PAY_NO_CEE) {
            payNoCee = (String) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DoxnPaysDesc.PAY_NO_ORDRE) {
            payNoOrdre = (Integer) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DoxnPaysDesc.PAY_DT_CREAT) {
            payDtCreat = (Timestamp) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DoxnPaysDesc.PAY_DT_MAJ) {
            payDtMaj = (Timestamp) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DoxnPaysDesc.PAY_UTIL_MAJ) {
            payUtilMaj = (String) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DoxnPaysDesc.XTX_ID) {
            xtxId = (Integer) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DoxnPaysDesc.Z_STATUS) {
            zStatus = (String) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
    }

    public DataObject setProperty(SqlArg sqlArg) throws SQLException {
        return setProperty(sqlArg, new DoxnPays());
    }

    private DataObject setProperty(SqlArg sqlArg, DoxnPays djo) throws SQLException {
        ResultSet rs = sqlArg.getResultSet();
        int[] val = sqlArg.getVal();
        if (val[DoxnPaysDesc.PAY_CODE] != -1) {
            djo.payCode = rs.getString(val[DoxnPaysDesc.PAY_CODE]);
        }
        if (val[DoxnPaysDesc.PAY_NOM] != -1) {
            djo.payNom = rs.getString(val[DoxnPaysDesc.PAY_NOM]);
        }
        if (val[DoxnPaysDesc.PAY_NOM_INT] != -1) {
            djo.payNomInt = rs.getString(val[DoxnPaysDesc.PAY_NOM_INT]);
        }
        if (val[DoxnPaysDesc.PAY_NOM_GPE] != -1) {
            djo.payNomGpe = rs.getString(val[DoxnPaysDesc.PAY_NOM_GPE]);
        }
        if (val[DoxnPaysDesc.PAY_CEE] != -1) {
            djo.payCee = rs.getString(val[DoxnPaysDesc.PAY_CEE]);
        }
        if (val[DoxnPaysDesc.PAY_NO_CEE] != -1) {
            djo.payNoCee = rs.getString(val[DoxnPaysDesc.PAY_NO_CEE]);
        }
        if (val[DoxnPaysDesc.PAY_NO_ORDRE] != -1) {
            int temp = rs.getInt(val[DoxnPaysDesc.PAY_NO_ORDRE]);
            if (!rs.wasNull())
                djo.payNoOrdre = new Integer(temp);
        }
        if (val[DoxnPaysDesc.PAY_DT_CREAT] != -1) {
            djo.payDtCreat = rs.getTimestamp(val[DoxnPaysDesc.PAY_DT_CREAT]);
        }
        if (val[DoxnPaysDesc.PAY_DT_MAJ] != -1) {
            djo.payDtMaj = rs.getTimestamp(val[DoxnPaysDesc.PAY_DT_MAJ]);
        }
        if (val[DoxnPaysDesc.PAY_UTIL_MAJ] != -1) {
            djo.payUtilMaj = rs.getString(val[DoxnPaysDesc.PAY_UTIL_MAJ]);
        }
        if (val[DoxnPaysDesc.XTX_ID] != -1) {
            int temp = rs.getInt(val[DoxnPaysDesc.XTX_ID]);
            if (!rs.wasNull())
                djo.xtxId = new Integer(temp);
        }
        if (val[DoxnPaysDesc.Z_STATUS] != -1) {
            djo.zStatus = rs.getString(val[DoxnPaysDesc.Z_STATUS]);
        }
        return djo;
    }

    public void getProperty(SqlArg sqlArg) throws SQLException {
        PreparedStatement stmt = sqlArg.getStmt();
        int[] val = sqlArg.getVal();
        if (val[DoxnPaysDesc.PAY_CODE] > 0) {
            stmt.setString(val[DoxnPaysDesc.PAY_CODE], payCode);
        }
        if (val[DoxnPaysDesc.PAY_NOM] > 0) {
            stmt.setString(val[DoxnPaysDesc.PAY_NOM], payNom);
        }
        if (val[DoxnPaysDesc.PAY_NOM_INT] > 0) {
            stmt.setString(val[DoxnPaysDesc.PAY_NOM_INT], payNomInt);
        }
        if (val[DoxnPaysDesc.PAY_NOM_GPE] > 0) {
            stmt.setString(val[DoxnPaysDesc.PAY_NOM_GPE], payNomGpe);
        }
        if (val[DoxnPaysDesc.PAY_CEE] > 0) {
            stmt.setString(val[DoxnPaysDesc.PAY_CEE], payCee);
        }
        if (val[DoxnPaysDesc.PAY_NO_CEE] > 0) {
            stmt.setString(val[DoxnPaysDesc.PAY_NO_CEE], payNoCee);
        }
        if (val[DoxnPaysDesc.PAY_NO_ORDRE] > 0) {
            if (payNoOrdre == null)
                stmt.setNull(val[DoxnPaysDesc.PAY_NO_ORDRE], 3);
            else
                stmt.setInt(val[DoxnPaysDesc.PAY_NO_ORDRE], payNoOrdre.intValue());
        }
        if (val[DoxnPaysDesc.PAY_DT_CREAT] > 0) {
            stmt.setTimestamp(val[DoxnPaysDesc.PAY_DT_CREAT], payDtCreat);
        }
        if (val[DoxnPaysDesc.PAY_DT_MAJ] > 0) {
            stmt.setTimestamp(val[DoxnPaysDesc.PAY_DT_MAJ], payDtMaj);
        }
        if (val[DoxnPaysDesc.PAY_UTIL_MAJ] > 0) {
            stmt.setString(val[DoxnPaysDesc.PAY_UTIL_MAJ], payUtilMaj);
        }
        if (val[DoxnPaysDesc.XTX_ID] > 0) {
            if (xtxId == null)
                stmt.setNull(val[DoxnPaysDesc.XTX_ID], 3);
            else
                stmt.setInt(val[DoxnPaysDesc.XTX_ID], xtxId.intValue());
        }
        if (val[DoxnPaysDesc.Z_STATUS] > 0) {
            stmt.setString(val[DoxnPaysDesc.Z_STATUS], zStatus);
        }
    }

    /**
     * M�thode g�n�r�e automatiquement permettant de remplir un dataobject � partir des valeurs
     * d'une requ�te http.
     * Les noms des param�tres de la requ�te doivent �tre strictement identique aux noms des attributs du DataObject.
     * Cette m�thode peut �tre compl�t�e afin de prendre en compte d'�ventuels param�tres se trouvant en session.
     * Pour une reg�n�ration �ventuelle, faites attention � ne coder qu'entre les tags de d�but et de fin.
     * Date de cr�ation : (25/05/01 08:03:14)
     *
     * @param request javax.servlet.http.HttpServletRequest
     */
    public DataObject[] setParameters(HttpServletRequest request)
            throws ParameterException, java.text.ParseException {
        String[] params = null;
        String localVal = null;
        int size = 0;
        DoxnPays[] result = null;
        params = request.getParameterValues("payCode");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoxnPays[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoxnPays();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setPayCode(localVal);
            }
        }
        params = request.getParameterValues("payNom");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoxnPays[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoxnPays();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setPayNom(localVal);
            }
        }
        params = request.getParameterValues("payNomInt");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoxnPays[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoxnPays();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setPayNomInt(localVal);
            }
        }
        params = request.getParameterValues("payNomGpe");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoxnPays[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoxnPays();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setPayNomGpe(localVal);
            }
        }
        params = request.getParameterValues("payCee");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoxnPays[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoxnPays();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setPayCee(localVal);
            }
        }
        params = request.getParameterValues("payNoCee");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoxnPays[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoxnPays();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setPayNoCee(localVal);
            }
        }
        params = request.getParameterValues("payNoOrdre");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoxnPays[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoxnPays();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setPayNoOrdre((Integer) StrConvertor.convert(localVal, Integer.class));
            }
        }
        params = request.getParameterValues("payDtCreat");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoxnPays[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoxnPays();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setPayDtCreat((Timestamp) StrConvertor.convert(localVal, Timestamp.class));
            }
        }
        params = request.getParameterValues("payDtMaj");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoxnPays[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoxnPays();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setPayDtMaj((Timestamp) StrConvertor.convert(localVal, Timestamp.class));
            }
        }
        params = request.getParameterValues("payUtilMaj");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoxnPays[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoxnPays();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setPayUtilMaj(localVal);
            }
        }
        params = request.getParameterValues("xtxId");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoxnPays[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoxnPays();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setXtxId((Integer) StrConvertor.convert(localVal, Integer.class));
            }
        }
        params = request.getParameterValues("zStatus");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoxnPays[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoxnPays();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setZStatus(localVal);
            }
        }
        /************************ INSTRUCTIONS DEVELOPPEMENT SPECIFIQUE *******************/
        /********************** FIN INSTRUCTIONS DEVELOPPEMENT SPECIFIQUE *****************/
        return result;
    }

    /*
     * @see DataObject#addChild(DataObject)
     */
    public void addChild(DataObject doChild) {
    }

    /*
     * @see DataObject#getDescription()
     */
    public IDoDescription getDescription() {
        return description;
    }

    /*
     * @see DataObject#getUpdateCol()
     */
    public int[] getUpdateCol() {
        return updCol;
    }

}
