package camaieu.pdm.dataobject;

import wg4.fwk.dataobject.DataObject;
import wg4.fwk.dataobject.IDoDescription;
import wg4.fwk.dataobject.ParameterException;
import wg4.fwk.dataobject.SqlArg;
import wg4.fwk.mvc.tool.StrConvertor;

import javax.servlet.http.HttpServletRequest;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.HashSet;

public class DoxnFamArt implements DataObject {

    private static final IDoDescription description = new DoxnFamArtDesc();
    private transient int persist = PERSIST_UPDATE_INSERT;
    private transient int[] updCol = new int[12];
    private transient String sql;
    private transient Object[] param;

//tables correspondantes
    private static final String[] tableNames = new String[]{"XN_FAM_ART"};
    //variables correspondant � la table XN_FAM_ART
    private String faaCode = null;
    private String faaLib = null;
    private String faaCpteAch = null;
    private String faaCpteAnaVte = null;
    private Timestamp faaDtCreat = null;
    private Timestamp faaDtMaj = null;
    private String faaUtilMaj = null;
    private Double faaRemise = null;
    private String faaCpteVte = null;
    private String faaCpteAnaAch = null;
    private Integer xtxId = null;
    private String zStatus = null;

    /**
     * Constructeur utilis� par la m�thode setPropertie
     */
    public DoxnFamArt() {
    }

    /**
     * Constructeur permettant d'initialiser le type de persistance
     */
    public DoxnFamArt(int persistTyp) {
        persist = persistTyp;
    }

    /**
     * Constructeur permettant d'initialiser le type de persistance
     */
    public DoxnFamArt(DoxnFamArt arg) {
        setFaaCode(arg.faaCode);
        setFaaLib(arg.faaLib);
        setFaaCpteAch(arg.faaCpteAch);
        setFaaCpteAnaVte(arg.faaCpteAnaVte);
        setFaaDtCreat(arg.faaDtCreat);
        setFaaDtMaj(arg.faaDtMaj);
        setFaaUtilMaj(arg.faaUtilMaj);
        setFaaRemise(arg.faaRemise);
        setFaaCpteVte(arg.faaCpteVte);
        setFaaCpteAnaAch(arg.faaCpteAnaAch);
        setXtxId(arg.xtxId);
        setZStatus(arg.zStatus);
    }

    /**
     * Constructeur utilis� par la m�thode retrieve
     */
    public DoxnFamArt(String newSql, Object[] newParam) {
        sql = newSql;
        param = newParam;
    }

    public int getPersist() {
        return persist;
    }

    public void setPersist(int newPersist) {
        persist = newPersist;
    }

    public void resetUpdate() {
        Arrays.fill(updCol, -1);
    }

    public Object[] getParam() {
        return param;
    }

    public String getSQL() {
        return sql;
    }

    public HashSet getColNotInsertable() {
        return null;
    }

    public String getFaaCode() {
        return faaCode;
    }

    public String getFaaLib() {
        return faaLib;
    }

    public String getFaaCpteAch() {
        return faaCpteAch;
    }

    public String getFaaCpteAnaVte() {
        return faaCpteAnaVte;
    }

    public Timestamp getFaaDtCreat() {
        return faaDtCreat;
    }

    public Timestamp getFaaDtMaj() {
        return faaDtMaj;
    }

    public String getFaaUtilMaj() {
        return faaUtilMaj;
    }

    public Double getFaaRemise() {
        return faaRemise;
    }

    public String getFaaCpteVte() {
        return faaCpteVte;
    }

    public String getFaaCpteAnaAch() {
        return faaCpteAnaAch;
    }

    public Integer getXtxId() {
        return xtxId;
    }

    public String getZStatus() {
        return zStatus;
    }

    public void setFaaCode(String newFaaCode) {
        faaCode = newFaaCode;
    }

    public void setFaaLib(String newFaaLib) {
        faaLib = newFaaLib;
        if (persist > 0)
            updCol[DoxnFamArtDesc.FAA_LIB] = 1;
    }

    public void setFaaCpteAch(String newFaaCpteAch) {
        faaCpteAch = newFaaCpteAch;
        if (persist > 0)
            updCol[DoxnFamArtDesc.FAA_CPTE_ACH] = 1;
    }

    public void setFaaCpteAnaVte(String newFaaCpteAnaVte) {
        faaCpteAnaVte = newFaaCpteAnaVte;
        if (persist > 0)
            updCol[DoxnFamArtDesc.FAA_CPTE_ANA_VTE] = 1;
    }

    public void setFaaDtCreat(Timestamp newFaaDtCreat) {
        faaDtCreat = newFaaDtCreat;
        if (persist > 0)
            updCol[DoxnFamArtDesc.FAA_DT_CREAT] = 1;
    }

    public void setFaaDtMaj(Timestamp newFaaDtMaj) {
        faaDtMaj = newFaaDtMaj;
        if (persist > 0)
            updCol[DoxnFamArtDesc.FAA_DT_MAJ] = 1;
    }

    public void setFaaUtilMaj(String newFaaUtilMaj) {
        faaUtilMaj = newFaaUtilMaj;
        if (persist > 0)
            updCol[DoxnFamArtDesc.FAA_UTIL_MAJ] = 1;
    }

    public void setFaaRemise(Double newFaaRemise) {
        faaRemise = newFaaRemise;
        if (persist > 0)
            updCol[DoxnFamArtDesc.FAA_REMISE] = 1;
    }

    public void setFaaCpteVte(String newFaaCpteVte) {
        faaCpteVte = newFaaCpteVte;
        if (persist > 0)
            updCol[DoxnFamArtDesc.FAA_CPTE_VTE] = 1;
    }

    public void setFaaCpteAnaAch(String newFaaCpteAnaAch) {
        faaCpteAnaAch = newFaaCpteAnaAch;
        if (persist > 0)
            updCol[DoxnFamArtDesc.FAA_CPTE_ANA_ACH] = 1;
    }

    public void setXtxId(Integer newXtxId) {
        xtxId = newXtxId;
        if (persist > 0)
            updCol[DoxnFamArtDesc.XTX_ID] = 1;
    }

    public void setZStatus(String newZStatus) {
        zStatus = newZStatus;
        if (persist > 0)
            updCol[DoxnFamArtDesc.Z_STATUS] = 1;
    }

    public Object get(int numCol) {
        if (numCol == DoxnFamArtDesc.FAA_CODE)
            return faaCode;
        else if (numCol == DoxnFamArtDesc.FAA_LIB)
            return faaLib;
        else if (numCol == DoxnFamArtDesc.FAA_CPTE_ACH)
            return faaCpteAch;
        else if (numCol == DoxnFamArtDesc.FAA_CPTE_ANA_VTE)
            return faaCpteAnaVte;
        else if (numCol == DoxnFamArtDesc.FAA_DT_CREAT)
            return faaDtCreat;
        else if (numCol == DoxnFamArtDesc.FAA_DT_MAJ)
            return faaDtMaj;
        else if (numCol == DoxnFamArtDesc.FAA_UTIL_MAJ)
            return faaUtilMaj;
        else if (numCol == DoxnFamArtDesc.FAA_REMISE)
            return faaRemise;
        else if (numCol == DoxnFamArtDesc.FAA_CPTE_VTE)
            return faaCpteVte;
        else if (numCol == DoxnFamArtDesc.FAA_CPTE_ANA_ACH)
            return faaCpteAnaAch;
        else if (numCol == DoxnFamArtDesc.XTX_ID)
            return xtxId;
        else if (numCol == DoxnFamArtDesc.Z_STATUS)
            return zStatus;
        return null;
    }

    public void set(int numCol, Object value) {
        if (numCol == DoxnFamArtDesc.FAA_CODE) {
            faaCode = (String) value;
        }
        if (numCol == DoxnFamArtDesc.FAA_LIB) {
            faaLib = (String) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DoxnFamArtDesc.FAA_CPTE_ACH) {
            faaCpteAch = (String) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DoxnFamArtDesc.FAA_CPTE_ANA_VTE) {
            faaCpteAnaVte = (String) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DoxnFamArtDesc.FAA_DT_CREAT) {
            faaDtCreat = (Timestamp) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DoxnFamArtDesc.FAA_DT_MAJ) {
            faaDtMaj = (Timestamp) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DoxnFamArtDesc.FAA_UTIL_MAJ) {
            faaUtilMaj = (String) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DoxnFamArtDesc.FAA_REMISE) {
            faaRemise = (Double) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DoxnFamArtDesc.FAA_CPTE_VTE) {
            faaCpteVte = (String) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DoxnFamArtDesc.FAA_CPTE_ANA_ACH) {
            faaCpteAnaAch = (String) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DoxnFamArtDesc.XTX_ID) {
            xtxId = (Integer) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DoxnFamArtDesc.Z_STATUS) {
            zStatus = (String) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
    }

    public DataObject setProperty(SqlArg sqlArg) throws SQLException {
        return setProperty(sqlArg, new DoxnFamArt());
    }

    private DataObject setProperty(SqlArg sqlArg, DoxnFamArt djo) throws SQLException {
        ResultSet rs = sqlArg.getResultSet();
        int[] val = sqlArg.getVal();
        if (val[DoxnFamArtDesc.FAA_CODE] != -1) {
            djo.faaCode = rs.getString(val[DoxnFamArtDesc.FAA_CODE]);
        }
        if (val[DoxnFamArtDesc.FAA_LIB] != -1) {
            djo.faaLib = rs.getString(val[DoxnFamArtDesc.FAA_LIB]);
        }
        if (val[DoxnFamArtDesc.FAA_CPTE_ACH] != -1) {
            djo.faaCpteAch = rs.getString(val[DoxnFamArtDesc.FAA_CPTE_ACH]);
        }
        if (val[DoxnFamArtDesc.FAA_CPTE_ANA_VTE] != -1) {
            djo.faaCpteAnaVte = rs.getString(val[DoxnFamArtDesc.FAA_CPTE_ANA_VTE]);
        }
        if (val[DoxnFamArtDesc.FAA_DT_CREAT] != -1) {
            djo.faaDtCreat = rs.getTimestamp(val[DoxnFamArtDesc.FAA_DT_CREAT]);
        }
        if (val[DoxnFamArtDesc.FAA_DT_MAJ] != -1) {
            djo.faaDtMaj = rs.getTimestamp(val[DoxnFamArtDesc.FAA_DT_MAJ]);
        }
        if (val[DoxnFamArtDesc.FAA_UTIL_MAJ] != -1) {
            djo.faaUtilMaj = rs.getString(val[DoxnFamArtDesc.FAA_UTIL_MAJ]);
        }
        if (val[DoxnFamArtDesc.FAA_REMISE] != -1) {
            double temp = rs.getDouble(val[DoxnFamArtDesc.FAA_REMISE]);
            if (!rs.wasNull())
                djo.faaRemise = new Double(temp);
        }
        if (val[DoxnFamArtDesc.FAA_CPTE_VTE] != -1) {
            djo.faaCpteVte = rs.getString(val[DoxnFamArtDesc.FAA_CPTE_VTE]);
        }
        if (val[DoxnFamArtDesc.FAA_CPTE_ANA_ACH] != -1) {
            djo.faaCpteAnaAch = rs.getString(val[DoxnFamArtDesc.FAA_CPTE_ANA_ACH]);
        }
        if (val[DoxnFamArtDesc.XTX_ID] != -1) {
            int temp = rs.getInt(val[DoxnFamArtDesc.XTX_ID]);
            if (!rs.wasNull())
                djo.xtxId = new Integer(temp);
        }
        if (val[DoxnFamArtDesc.Z_STATUS] != -1) {
            djo.zStatus = rs.getString(val[DoxnFamArtDesc.Z_STATUS]);
        }
        return djo;
    }

    public void getProperty(SqlArg sqlArg) throws SQLException {
        PreparedStatement stmt = sqlArg.getStmt();
        int[] val = sqlArg.getVal();
        if (val[DoxnFamArtDesc.FAA_CODE] > 0) {
            stmt.setString(val[DoxnFamArtDesc.FAA_CODE], faaCode);
        }
        if (val[DoxnFamArtDesc.FAA_LIB] > 0) {
            stmt.setString(val[DoxnFamArtDesc.FAA_LIB], faaLib);
        }
        if (val[DoxnFamArtDesc.FAA_CPTE_ACH] > 0) {
            stmt.setString(val[DoxnFamArtDesc.FAA_CPTE_ACH], faaCpteAch);
        }
        if (val[DoxnFamArtDesc.FAA_CPTE_ANA_VTE] > 0) {
            stmt.setString(val[DoxnFamArtDesc.FAA_CPTE_ANA_VTE], faaCpteAnaVte);
        }
        if (val[DoxnFamArtDesc.FAA_DT_CREAT] > 0) {
            stmt.setTimestamp(val[DoxnFamArtDesc.FAA_DT_CREAT], faaDtCreat);
        }
        if (val[DoxnFamArtDesc.FAA_DT_MAJ] > 0) {
            stmt.setTimestamp(val[DoxnFamArtDesc.FAA_DT_MAJ], faaDtMaj);
        }
        if (val[DoxnFamArtDesc.FAA_UTIL_MAJ] > 0) {
            stmt.setString(val[DoxnFamArtDesc.FAA_UTIL_MAJ], faaUtilMaj);
        }
        if (val[DoxnFamArtDesc.FAA_REMISE] > 0) {
            if (faaRemise == null)
                stmt.setNull(val[DoxnFamArtDesc.FAA_REMISE], 3);
            else
                stmt.setDouble(val[DoxnFamArtDesc.FAA_REMISE], faaRemise.doubleValue());
        }
        if (val[DoxnFamArtDesc.FAA_CPTE_VTE] > 0) {
            stmt.setString(val[DoxnFamArtDesc.FAA_CPTE_VTE], faaCpteVte);
        }
        if (val[DoxnFamArtDesc.FAA_CPTE_ANA_ACH] > 0) {
            stmt.setString(val[DoxnFamArtDesc.FAA_CPTE_ANA_ACH], faaCpteAnaAch);
        }
        if (val[DoxnFamArtDesc.XTX_ID] > 0) {
            if (xtxId == null)
                stmt.setNull(val[DoxnFamArtDesc.XTX_ID], 3);
            else
                stmt.setInt(val[DoxnFamArtDesc.XTX_ID], xtxId.intValue());
        }
        if (val[DoxnFamArtDesc.Z_STATUS] > 0) {
            stmt.setString(val[DoxnFamArtDesc.Z_STATUS], zStatus);
        }
    }

    /**
     * M�thode g�n�r�e automatiquement permettant de remplir un dataobject � partir des valeurs
     * d'une requ�te http.
     * Les noms des param�tres de la requ�te doivent �tre strictement identique aux noms des attributs du DataObject.
     * Cette m�thode peut �tre compl�t�e afin de prendre en compte d'�ventuels param�tres se trouvant en session.
     * Pour une reg�n�ration �ventuelle, faites attention � ne coder qu'entre les tags de d�but et de fin.
     * Date de cr�ation : (25/05/01 08:03:14)
     *
     * @param request javax.servlet.http.HttpServletRequest
     */
    public DataObject[] setParameters(HttpServletRequest request)
            throws ParameterException, java.text.ParseException {
        String[] params = null;
        String localVal = null;
        int size = 0;
        DoxnFamArt[] result = null;
        params = request.getParameterValues("faaCode");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoxnFamArt[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoxnFamArt();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setFaaCode(localVal);
            }
        }
        params = request.getParameterValues("faaLib");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoxnFamArt[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoxnFamArt();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setFaaLib(localVal);
            }
        }
        params = request.getParameterValues("faaCpteAch");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoxnFamArt[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoxnFamArt();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setFaaCpteAch(localVal);
            }
        }
        params = request.getParameterValues("faaCpteAnaVte");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoxnFamArt[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoxnFamArt();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setFaaCpteAnaVte(localVal);
            }
        }
        params = request.getParameterValues("faaDtCreat");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoxnFamArt[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoxnFamArt();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setFaaDtCreat((Timestamp) StrConvertor.convert(localVal, Timestamp.class));
            }
        }
        params = request.getParameterValues("faaDtMaj");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoxnFamArt[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoxnFamArt();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setFaaDtMaj((Timestamp) StrConvertor.convert(localVal, Timestamp.class));
            }
        }
        params = request.getParameterValues("faaUtilMaj");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoxnFamArt[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoxnFamArt();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setFaaUtilMaj(localVal);
            }
        }
        params = request.getParameterValues("faaRemise");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoxnFamArt[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoxnFamArt();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setFaaRemise((Double) StrConvertor.convert(localVal, Double.class));
            }
        }
        params = request.getParameterValues("faaCpteVte");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoxnFamArt[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoxnFamArt();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setFaaCpteVte(localVal);
            }
        }
        params = request.getParameterValues("faaCpteAnaAch");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoxnFamArt[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoxnFamArt();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setFaaCpteAnaAch(localVal);
            }
        }
        params = request.getParameterValues("xtxId");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoxnFamArt[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoxnFamArt();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setXtxId((Integer) StrConvertor.convert(localVal, Integer.class));
            }
        }
        params = request.getParameterValues("zStatus");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoxnFamArt[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoxnFamArt();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setZStatus(localVal);
            }
        }
        /************************ INSTRUCTIONS DEVELOPPEMENT SPECIFIQUE *******************/
        /********************** FIN INSTRUCTIONS DEVELOPPEMENT SPECIFIQUE *****************/
        return result;
    }

    /*
     * @see DataObject#addChild(DataObject)
     */
    public void addChild(DataObject doChild) {
    }

    /*
     * @see DataObject#getDescription()
     */
    public IDoDescription getDescription() {
        return description;
    }

    /*
     * @see DataObject#getUpdateCol()
     */
    public int[] getUpdateCol() {
        return updCol;
    }

}
