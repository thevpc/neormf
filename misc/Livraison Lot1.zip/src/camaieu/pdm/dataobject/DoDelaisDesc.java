package camaieu.pdm.dataobject;

import wg4.fwk.dataobject.IDoDescription;

import java.util.HashMap;

/**
 * /* Description de l'objetDoDelais correspondant � la table DELAIS
 */
public class DoDelaisDesc implements IDoDescription {
    public static final int DEL_PAY_CODE = 0;
    public static final int DEL_VALEUR = 1;

    public static final String tableName = "DELAIS";

    /*
     * Liste des noms de colonnes
     */
    public static final String[] dbColName = new String[]{
        "DEL_PAY_CODE", "DEL_VALEUR"};
    private static final HashMap colBase;

    static {
        colBase = new HashMap(2);
        colBase.put("DEL_PAY_CODE", new Integer(DEL_PAY_CODE));
        colBase.put("DEL_VALEUR", new Integer(DEL_VALEUR));
    }

    /*
     * Noms de colonnes de la cl� primaire
     */
    private static final String[] pkColName = new String[]{
        "DEL_PAY_CODE"};

    private static final int[] pkColNum = new int[]{0};

    private static final HashMap fkColName = new HashMap(0);

    private static final HashMap fkColNum = new HashMap(0);

    /**
     * @see IDoDescription.getTableName()
     */
    public String getTableName() {
        return tableName;
    }

    /**
     * @see IDoDescription.getDbColName()
     */
    public String[] getDbColName() {
        return dbColName;
    }

    /**
     * @see IDoDescription.getDbColNum()
     */
    public HashMap getDbColNum() {
        return colBase;
    }

    /**
     * @see IDoDescription.getPkColName()
     */
    public String[] getPkColName() {
        return pkColName;
    }

    /**
     * @see IDoDescription.getPkColNum()
     */
    public int[] getPkColNum() {
        return pkColNum;
    }
    /**
     * @see IDoDescription.getPkColNumInsert()
     */
    /**
     * @see IDoDescription.getFkColName()
     */
    public String[] getFkColName(String tableName) {
        return (String[]) fkColName.get(tableName);
    }

    /**
     * @see IDoDescription.getFkColNum()
     */
    public int[] getFkColNum(String tableName) {
        return (int[]) fkColNum.get(tableName);
    }
}
