package camaieu.pdm.dataobject;

import wg4.fwk.dataobject.IDoDescription;

import java.util.HashMap;

/**
 * /* Description de l'objetDoxnFamArt correspondant � la table XN_FAM_ART
 */
public class DoxnFamArtDesc implements IDoDescription {
    public static final int FAA_CODE = 0;
    public static final int FAA_LIB = 1;
    public static final int FAA_CPTE_ACH = 2;
    public static final int FAA_CPTE_ANA_VTE = 3;
    public static final int FAA_DT_CREAT = 4;
    public static final int FAA_DT_MAJ = 5;
    public static final int FAA_UTIL_MAJ = 6;
    public static final int FAA_REMISE = 7;
    public static final int FAA_CPTE_VTE = 8;
    public static final int FAA_CPTE_ANA_ACH = 9;
    public static final int XTX_ID = 10;
    public static final int Z_STATUS = 11;

    public static final String tableName = "XN_FAM_ART";

    /*
     * Liste des noms de colonnes
     */
    public static final String[] dbColName = new String[]{
        "FAA_CODE", "FAA_LIB", "FAA_CPTE_ACH", "FAA_CPTE_ANA_VTE", "FAA_DT_CREAT", "FAA_DT_MAJ", "FAA_UTIL_MAJ", "FAA_REMISE", "FAA_CPTE_VTE", "FAA_CPTE_ANA_ACH", "XTX_ID", "Z_STATUS"};
    private static final HashMap colBase;

    static {
        colBase = new HashMap(12);
        colBase.put("FAA_CODE", new Integer(FAA_CODE));
        colBase.put("FAA_LIB", new Integer(FAA_LIB));
        colBase.put("FAA_CPTE_ACH", new Integer(FAA_CPTE_ACH));
        colBase.put("FAA_CPTE_ANA_VTE", new Integer(FAA_CPTE_ANA_VTE));
        colBase.put("FAA_DT_CREAT", new Integer(FAA_DT_CREAT));
        colBase.put("FAA_DT_MAJ", new Integer(FAA_DT_MAJ));
        colBase.put("FAA_UTIL_MAJ", new Integer(FAA_UTIL_MAJ));
        colBase.put("FAA_REMISE", new Integer(FAA_REMISE));
        colBase.put("FAA_CPTE_VTE", new Integer(FAA_CPTE_VTE));
        colBase.put("FAA_CPTE_ANA_ACH", new Integer(FAA_CPTE_ANA_ACH));
        colBase.put("XTX_ID", new Integer(XTX_ID));
        colBase.put("Z_STATUS", new Integer(Z_STATUS));
    }

    /*
     * Noms de colonnes de la cl� primaire
     */
    private static final String[] pkColName = new String[]{
        "FAA_CODE"};

    private static final int[] pkColNum = new int[]{0};

    private static final HashMap fkColName = new HashMap(0);

    static {
        fkColName.put("CF_OPER_COMMER", new String[]{
            "FAA_CODE"
        });
        fkColName.put("XN_ART", new String[]{
            "FAA_CODE"
        });
        fkColName.put("XN_BUDGET_VENTE", new String[]{
            "FAA_CODE"
        });
        fkColName.put("XN_EHF_TRANSF_STOCK", new String[]{
            "FAA_CODE"
        });
        fkColName.put("XN_EHF_VENTES", new String[]{
            "FAA_CODE"
        });
        fkColName.put("XN_EXCEP_TARIF_CLI", new String[]{
            "FAA_CODE"
        });
        fkColName.put("XN_EXCEP_TARIF_FOUR", new String[]{
            "FAA_CODE"
        });
        fkColName.put("XN_FAM_ART_FOUR", new String[]{
            "FAA_CODE"
        });
        fkColName.put("XN_FAM_ART_LANGUE", new String[]{
            "FAA_CODE"
        });
        fkColName.put("XN_FLASH_FOUR", new String[]{
            "FAA_CODE"
        });
        fkColName.put("XN_LOT_TETE", new String[]{
            "FAA_CODE"
        });
        fkColName.put("XN_MODELE", new String[]{
            "FAA_CODE"
        });
        fkColName.put("XN_SFAM_ART", new String[]{
            "FAA_CODE"
        });
    }


    private static final HashMap fkColNum = new HashMap(0);

    static {
        fkColNum.put("CF_OPER_COMMER", new int[]{
            0
        });
        fkColNum.put("XN_ART", new int[]{
            0
        });
        fkColNum.put("XN_BUDGET_VENTE", new int[]{
            0
        });
        fkColNum.put("XN_EHF_TRANSF_STOCK", new int[]{
            0
        });
        fkColNum.put("XN_EHF_VENTES", new int[]{
            0
        });
        fkColNum.put("XN_EXCEP_TARIF_CLI", new int[]{
            0
        });
        fkColNum.put("XN_EXCEP_TARIF_FOUR", new int[]{
            0
        });
        fkColNum.put("XN_FAM_ART_FOUR", new int[]{
            0
        });
        fkColNum.put("XN_FAM_ART_LANGUE", new int[]{
            0
        });
        fkColNum.put("XN_FLASH_FOUR", new int[]{
            0
        });
        fkColNum.put("XN_LOT_TETE", new int[]{
            0
        });
        fkColNum.put("XN_MODELE", new int[]{
            0
        });
        fkColNum.put("XN_SFAM_ART", new int[]{
            0
        });
    }

    /**
     * @see IDoDescription.getTableName()
     */
    public String getTableName() {
        return tableName;
    }

    /**
     * @see IDoDescription.getDbColName()
     */
    public String[] getDbColName() {
        return dbColName;
    }

    /**
     * @see IDoDescription.getDbColNum()
     */
    public HashMap getDbColNum() {
        return colBase;
    }

    /**
     * @see IDoDescription.getPkColName()
     */
    public String[] getPkColName() {
        return pkColName;
    }

    /**
     * @see IDoDescription.getPkColNum()
     */
    public int[] getPkColNum() {
        return pkColNum;
    }
    /**
     * @see IDoDescription.getPkColNumInsert()
     */
    /**
     * @see IDoDescription.getFkColName()
     */
    public String[] getFkColName(String tableName) {
        return (String[]) fkColName.get(tableName);
    }

    /**
     * @see IDoDescription.getFkColNum()
     */
    public int[] getFkColNum(String tableName) {
        return (int[]) fkColNum.get(tableName);
    }
}
