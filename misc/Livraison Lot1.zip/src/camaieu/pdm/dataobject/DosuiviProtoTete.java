package camaieu.pdm.dataobject;

import wg4.fwk.dataobject.DataObject;
import wg4.fwk.dataobject.IDoDescription;
import wg4.fwk.dataobject.ParameterException;
import wg4.fwk.dataobject.SqlArg;
import wg4.fwk.mvc.tool.StrConvertor;

import javax.servlet.http.HttpServletRequest;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.HashSet;

public class DosuiviProtoTete implements DataObject {

    private static final IDoDescription description = new
            DosuiviProtoTeteDesc();
    private transient int persist = PERSIST_UPDATE_INSERT;
    private transient int[] updCol = new int[44];
    private transient String sql;
    private transient Object[] param;

//tables correspondantes
    private static final String[] tableNames = new String[]
    {"SUIVI_PROTO_TETE"};
    //variables correspondant � la table SUIVI_PROTO_TETE
    private Integer sptModeleCode = null;
    private String sptCltAn = null;
    private String sptCltSaiCode = null;
    private String sptCltCode = null;
    private String sptNomModele = null;
    private String sptRefNodhos = null;
    private String sptFaaCode = null;
    private String sptSfaCode = null;
    private String sptQualite = null;
    private String sptLavage = null;
    private String sptFouCodeTissu = null;
    private String sptBureauType = null;
    private String sptBureauCode = null;
    private String sptFacCode = null;
    private Timestamp sptDtTransmission = null;
    private Timestamp sptDtEnvFtechBur = null;
    private Timestamp sptDtEnvCtBur = null;
    private Timestamp sptDtRecepFtechBur = null;
    private Timestamp sptDtRecepCtBur = null;
    private String sptEnvCtypeEssaiMat = null;
    private Double sptPrixFacon = null;
    private Double sptEmpProvisoire = null;
    private Timestamp sptRecepDisqPat = null;
    private Timestamp sptDtEnvPatronage = null;
    private Timestamp sptDtRecepPat = null;
    private Timestamp sptDtEnvFtechFac = null;
    private Timestamp sptDtEnvCtFac = null;
    private Timestamp sptDtRecepFtechFac = null;
    private Timestamp sptDtRecepCtFac = null;
    private String sptDdeTeteSerie = null;
    private Timestamp sptTeteSerie = null;
    private Timestamp sptOkAccessoires = null;
    private Timestamp sptOkColoris = null;
    private Double sptEmploiDef = null;
    private Timestamp sptOkProdEntrep = null;
    private Timestamp sptOkMatiere = null;
    private Timestamp sptDebutProd = null;
    private Timestamp sptValidEchanSource = null;
    private String sptCommentAchats = null;
    private String sptCommentModeliste = null;
    private String sptCommentBureau = null;
    private String sptStatus = null;
    private byte[] sptPicTissu = null;
    private byte[] sptPicModele = null;

    /**
     * Constructeur utilis� par la m�thode setPropertie
     */
    public DosuiviProtoTete() {
    }

    /**
     * Constructeur permettant d'initialiser le type de persistance
     */
    public DosuiviProtoTete(int persistTyp) {
        persist = persistTyp;
    }

    /**
     * Constructeur permettant d'initialiser le type de persistance
     */
    public DosuiviProtoTete(DosuiviProtoTete arg) {
        setSptModeleCode(arg.sptModeleCode);
        setSptCltAn(arg.sptCltAn);
        setSptCltSaiCode(arg.sptCltSaiCode);
        setSptCltCode(arg.sptCltCode);
        setSptNomModele(arg.sptNomModele);
        setSptRefNodhos(arg.sptRefNodhos);
        setSptFaaCode(arg.sptFaaCode);
        setSptSfaCode(arg.sptSfaCode);
        setSptQualite(arg.sptQualite);
        setSptLavage(arg.sptLavage);
        setSptFouCodeTissu(arg.sptFouCodeTissu);
        setSptBureauType(arg.sptBureauType);
        setSptBureauCode(arg.sptBureauCode);
        setSptFacCode(arg.sptFacCode);
        setSptDtTransmission(arg.sptDtTransmission);
        setSptDtEnvFtechBur(arg.sptDtEnvFtechBur);
        setSptDtEnvCtBur(arg.sptDtEnvCtBur);
        setSptDtRecepFtechBur(arg.sptDtRecepFtechBur);
        setSptDtRecepCtBur(arg.sptDtRecepCtBur);
        setSptEnvCtypeEssaiMat(arg.sptEnvCtypeEssaiMat);
        setSptPrixFacon(arg.sptPrixFacon);
        setSptEmpProvisoire(arg.sptEmpProvisoire);
        setSptRecepDisqPat(arg.sptRecepDisqPat);
        setSptDtEnvPatronage(arg.sptDtEnvPatronage);
        setSptDtRecepPat(arg.sptDtRecepPat);
        setSptDtEnvFtechFac(arg.sptDtEnvFtechFac);
        setSptDtEnvCtFac(arg.sptDtEnvCtFac);
        setSptDtRecepFtechFac(arg.sptDtRecepFtechFac);
        setSptDtRecepCtFac(arg.sptDtRecepCtFac);
        setSptDdeTeteSerie(arg.sptDdeTeteSerie);
        setSptTeteSerie(arg.sptTeteSerie);
        setSptOkAccessoires(arg.sptOkAccessoires);
        setSptOkColoris(arg.sptOkColoris);
        setSptEmploiDef(arg.sptEmploiDef);
        setSptOkProdEntrep(arg.sptOkProdEntrep);
        setSptOkMatiere(arg.sptOkMatiere);
        setSptDebutProd(arg.sptDebutProd);
        setSptValidEchanSource(arg.sptValidEchanSource);
        setSptCommentAchats(arg.sptCommentAchats);
        setSptCommentModeliste(arg.sptCommentModeliste);
        setSptCommentBureau(arg.sptCommentBureau);
        setSptStatus(arg.sptStatus);
        setSptPicTissu(arg.sptPicTissu);
        setSptPicModele(arg.sptPicModele);
    }

    /**
     * Constructeur utilis� par la m�thode retrieve
     */
    public DosuiviProtoTete(String newSql, Object[] newParam) {
        sql = newSql;
        param = newParam;
    }

    public int getPersist() {
        return persist;
    }

    public void setPersist(int newPersist) {
        persist = newPersist;
    }

    public void resetUpdate() {
        Arrays.fill(updCol, -1);
    }

    public Object[] getParam() {
        return param;
    }

    public String getSQL() {
        return sql;
    }

    public HashSet getColNotInsertable() {
        return null;
    }

    public Integer getSptModeleCode() {
        return sptModeleCode;
    }

    public String getSptCltAn() {
        return sptCltAn;
    }

    public String getSptCltSaiCode() {
        return sptCltSaiCode;
    }

    public String getSptCltCode() {
        return sptCltCode;
    }

    public String getSptNomModele() {
        return sptNomModele;
    }

    public String getSptRefNodhos() {
        return sptRefNodhos;
    }

    public String getSptFaaCode() {
        return sptFaaCode;
    }

    public String getSptSfaCode() {
        return sptSfaCode;
    }

    public String getSptQualite() {
        return sptQualite;
    }

    public String getSptLavage() {
        return sptLavage;
    }

    public String getSptFouCodeTissu() {
        return sptFouCodeTissu;
    }

    public String getSptBureauType() {
        return sptBureauType;
    }

    public String getSptBureauCode() {
        return sptBureauCode;
    }

    public String getSptFacCode() {
        return sptFacCode;
    }

    public Timestamp getSptDtTransmission() {
        return sptDtTransmission;
    }

    public Timestamp getSptDtEnvFtechBur() {
        return sptDtEnvFtechBur;
    }

    public Timestamp getSptDtEnvCtBur() {
        return sptDtEnvCtBur;
    }

    public Timestamp getSptDtRecepFtechBur() {
        return sptDtRecepFtechBur;
    }

    public Timestamp getSptDtRecepCtBur() {
        return sptDtRecepCtBur;
    }

    public String getSptEnvCtypeEssaiMat() {
        return sptEnvCtypeEssaiMat;
    }

    public Double getSptPrixFacon() {
        return sptPrixFacon;
    }

    public Double getSptEmpProvisoire() {
        return sptEmpProvisoire;
    }

    public Timestamp getSptRecepDisqPat() {
        return sptRecepDisqPat;
    }

    public Timestamp getSptDtEnvPatronage() {
        return sptDtEnvPatronage;
    }

    public Timestamp getSptDtRecepPat() {
        return sptDtRecepPat;
    }

    public Timestamp getSptDtEnvFtechFac() {
        return sptDtEnvFtechFac;
    }

    public Timestamp getSptDtEnvCtFac() {
        return sptDtEnvCtFac;
    }

    public Timestamp getSptDtRecepFtechFac() {
        return sptDtRecepFtechFac;
    }

    public Timestamp getSptDtRecepCtFac() {
        return sptDtRecepCtFac;
    }

    public String getSptDdeTeteSerie() {
        return sptDdeTeteSerie;
    }

    public Timestamp getSptTeteSerie() {
        return sptTeteSerie;
    }

    public Timestamp getSptOkAccessoires() {
        return sptOkAccessoires;
    }

    public Timestamp getSptOkColoris() {
        return sptOkColoris;
    }

    public Double getSptEmploiDef() {
        return sptEmploiDef;
    }

    public Timestamp getSptOkProdEntrep() {
        return sptOkProdEntrep;
    }

    public Timestamp getSptOkMatiere() {
        return sptOkMatiere;
    }

    public Timestamp getSptDebutProd() {
        return sptDebutProd;
    }

    public Timestamp getSptValidEchanSource() {
        return sptValidEchanSource;
    }

    public String getSptCommentAchats() {
        return sptCommentAchats;
    }

    public String getSptCommentModeliste() {
        return sptCommentModeliste;
    }

    public String getSptCommentBureau() {
        return sptCommentBureau;
    }

    public String getSptStatus() {
        return sptStatus;
    }

    public byte[] getSptPicTissu() {
        return sptPicTissu;
    }

    public byte[] getSptPicModele() {
        return sptPicModele;
    }

    public void setSptModeleCode(Integer newSptModeleCode) {
        sptModeleCode = newSptModeleCode;
    }

    public void setSptCltAn(String newSptCltAn) {
        sptCltAn = newSptCltAn;
        if (persist > 0)
            updCol[DosuiviProtoTeteDesc.SPT_CLT_AN] = 1;
    }

    public void setSptCltSaiCode(String newSptCltSaiCode) {
        sptCltSaiCode = newSptCltSaiCode;
        if (persist > 0)
            updCol[DosuiviProtoTeteDesc.SPT_CLT_SAI_CODE] = 1;
    }

    public void setSptCltCode(String newSptCltCode) {
        sptCltCode = newSptCltCode;
        if (persist > 0)
            updCol[DosuiviProtoTeteDesc.SPT_CLT_CODE] = 1;
    }

    public void setSptNomModele(String newSptNomModele) {
        sptNomModele = newSptNomModele;
        if (persist > 0)
            updCol[DosuiviProtoTeteDesc.SPT_NOM_MODELE] = 1;
    }

    public void setSptRefNodhos(String newSptRefNodhos) {
        sptRefNodhos = newSptRefNodhos;
        if (persist > 0)
            updCol[DosuiviProtoTeteDesc.SPT_REF_NODHOS] = 1;
    }

    public void setSptFaaCode(String newSptFaaCode) {
        sptFaaCode = newSptFaaCode;
        if (persist > 0)
            updCol[DosuiviProtoTeteDesc.SPT_FAA_CODE] = 1;
    }

    public void setSptSfaCode(String newSptSfaCode) {
        sptSfaCode = newSptSfaCode;
        if (persist > 0)
            updCol[DosuiviProtoTeteDesc.SPT_SFA_CODE] = 1;
    }

    public void setSptQualite(String newSptQualite) {
        sptQualite = newSptQualite;
        if (persist > 0)
            updCol[DosuiviProtoTeteDesc.SPT_QUALITE] = 1;
    }

    public void setSptLavage(String newSptLavage) {
        sptLavage = newSptLavage;
        if (persist > 0)
            updCol[DosuiviProtoTeteDesc.SPT_LAVAGE] = 1;
    }

    public void setSptFouCodeTissu(String newSptFouCodeTissu) {
        sptFouCodeTissu = newSptFouCodeTissu;
        if (persist > 0)
            updCol[DosuiviProtoTeteDesc.SPT_FOU_CODE_TISSU] = 1;
    }

    public void setSptBureauType(String newSptBureauType) {
        sptBureauType = newSptBureauType;
        if (persist > 0)
            updCol[DosuiviProtoTeteDesc.SPT_BUREAU_TYPE] = 1;
    }

    public void setSptBureauCode(String newSptBureauCode) {
        sptBureauCode = newSptBureauCode;
        if (persist > 0)
            updCol[DosuiviProtoTeteDesc.SPT_BUREAU_CODE] = 1;
    }

    public void setSptFacCode(String newSptFacCode) {
        sptFacCode = newSptFacCode;
        if (persist > 0)
            updCol[DosuiviProtoTeteDesc.SPT_FAC_CODE] = 1;
    }

    public void setSptDtTransmission(Timestamp newSptDtTransmission) {
        sptDtTransmission = newSptDtTransmission;
        if (persist > 0)
            updCol[DosuiviProtoTeteDesc.SPT_DT_TRANSMISSION] = 1;
    }

    public void setSptDtEnvFtechBur(Timestamp newSptDtEnvFtechBur) {
        sptDtEnvFtechBur = newSptDtEnvFtechBur;
        if (persist > 0)
            updCol[DosuiviProtoTeteDesc.SPT_DT_ENV_FTECH_BUR] = 1;
    }

    public void setSptDtEnvCtBur(Timestamp newSptDtEnvCtBur) {
        sptDtEnvCtBur = newSptDtEnvCtBur;
        if (persist > 0)
            updCol[DosuiviProtoTeteDesc.SPT_DT_ENV_CT_BUR] = 1;
    }

    public void setSptDtRecepFtechBur(Timestamp newSptDtRecepFtechBur) {
        sptDtRecepFtechBur = newSptDtRecepFtechBur;
        if (persist > 0)
            updCol[DosuiviProtoTeteDesc.SPT_DT_RECEP_FTECH_BUR] = 1;
    }

    public void setSptDtRecepCtBur(Timestamp newSptDtRecepCtBur) {
        sptDtRecepCtBur = newSptDtRecepCtBur;
        if (persist > 0)
            updCol[DosuiviProtoTeteDesc.SPT_DT_RECEP_CT_BUR] = 1;
    }

    public void setSptEnvCtypeEssaiMat(String newSptEnvCtypeEssaiMat) {
        sptEnvCtypeEssaiMat = newSptEnvCtypeEssaiMat;
        if (persist > 0)
            updCol[DosuiviProtoTeteDesc.SPT_ENV_CTYPE_ESSAI_MAT] = 1;
    }

    public void setSptPrixFacon(Double newSptPrixFacon) {
        sptPrixFacon = newSptPrixFacon;
        if (persist > 0)
            updCol[DosuiviProtoTeteDesc.SPT_PRIX_FACON] = 1;
    }

    public void setSptEmpProvisoire(Double newSptEmpProvisoire) {
        sptEmpProvisoire = newSptEmpProvisoire;
        if (persist > 0)
            updCol[DosuiviProtoTeteDesc.SPT_EMP_PROVISOIRE] = 1;
    }

    public void setSptRecepDisqPat(Timestamp newSptRecepDisqPat) {
        sptRecepDisqPat = newSptRecepDisqPat;
        if (persist > 0)
            updCol[DosuiviProtoTeteDesc.SPT_RECEP_DISQ_PAT] = 1;
    }

    public void setSptDtEnvPatronage(Timestamp newSptDtEnvPatronage) {
        sptDtEnvPatronage = newSptDtEnvPatronage;
        if (persist > 0)
            updCol[DosuiviProtoTeteDesc.SPT_DT_ENV_PATRONAGE] = 1;
    }

    public void setSptDtRecepPat(Timestamp newSptDtRecepPat) {
        sptDtRecepPat = newSptDtRecepPat;
        if (persist > 0)
            updCol[DosuiviProtoTeteDesc.SPT_DT_RECEP_PAT] = 1;
    }

    public void setSptDtEnvFtechFac(Timestamp newSptDtEnvFtechFac) {
        sptDtEnvFtechFac = newSptDtEnvFtechFac;
        if (persist > 0)
            updCol[DosuiviProtoTeteDesc.SPT_DT_ENV_FTECH_FAC] = 1;
    }

    public void setSptDtEnvCtFac(Timestamp newSptDtEnvCtFac) {
        sptDtEnvCtFac = newSptDtEnvCtFac;
        if (persist > 0)
            updCol[DosuiviProtoTeteDesc.SPT_DT_ENV_CT_FAC] = 1;
    }

    public void setSptDtRecepFtechFac(Timestamp newSptDtRecepFtechFac) {
        sptDtRecepFtechFac = newSptDtRecepFtechFac;
        if (persist > 0)
            updCol[DosuiviProtoTeteDesc.SPT_DT_RECEP_FTECH_FAC] = 1;
    }

    public void setSptDtRecepCtFac(Timestamp newSptDtRecepCtFac) {
        sptDtRecepCtFac = newSptDtRecepCtFac;
        if (persist > 0)
            updCol[DosuiviProtoTeteDesc.SPT_DT_RECEP_CT_FAC] = 1;
    }

    public void setSptDdeTeteSerie(String newSptDdeTeteSerie) {
        sptDdeTeteSerie = newSptDdeTeteSerie;
        if (persist > 0)
            updCol[DosuiviProtoTeteDesc.SPT_DDE_TETE_SERIE] = 1;
    }

    public void setSptTeteSerie(Timestamp newSptTeteSerie) {
        sptTeteSerie = newSptTeteSerie;
        if (persist > 0)
            updCol[DosuiviProtoTeteDesc.SPT_TETE_SERIE] = 1;
    }

    public void setSptOkAccessoires(Timestamp newSptOkAccessoires) {
        sptOkAccessoires = newSptOkAccessoires;
        if (persist > 0)
            updCol[DosuiviProtoTeteDesc.SPT_OK_ACCESSOIRES] = 1;
    }

    public void setSptOkColoris(Timestamp newSptOkColoris) {
        sptOkColoris = newSptOkColoris;
        if (persist > 0)
            updCol[DosuiviProtoTeteDesc.SPT_OK_COLORIS] = 1;
    }

    public void setSptEmploiDef(Double newSptEmploiDef) {
        sptEmploiDef = newSptEmploiDef;
        if (persist > 0)
            updCol[DosuiviProtoTeteDesc.SPT_EMPLOI_DEF] = 1;
    }

    public void setSptOkProdEntrep(Timestamp newSptOkProdEntrep) {
        sptOkProdEntrep = newSptOkProdEntrep;
        if (persist > 0)
            updCol[DosuiviProtoTeteDesc.SPT_OK_PROD_ENTREP] = 1;
    }

    public void setSptOkMatiere(Timestamp newSptOkMatiere) {
        sptOkMatiere = newSptOkMatiere;
        if (persist > 0)
            updCol[DosuiviProtoTeteDesc.SPT_OK_MATIERE] = 1;
    }

    public void setSptDebutProd(Timestamp newSptDebutProd) {
        sptDebutProd = newSptDebutProd;
        if (persist > 0)
            updCol[DosuiviProtoTeteDesc.SPT_DEBUT_PROD] = 1;
    }

    public void setSptValidEchanSource(Timestamp newSptValidEchanSource) {
        sptValidEchanSource = newSptValidEchanSource;
        if (persist > 0)
            updCol[DosuiviProtoTeteDesc.SPT_VALID_ECHAN_SOURCE] = 1;
    }

    public void setSptCommentAchats(String newSptCommentAchats) {
        sptCommentAchats = newSptCommentAchats;
        if (persist > 0)
            updCol[DosuiviProtoTeteDesc.SPT_COMMENT_ACHATS] = 1;
    }

    public void setSptCommentModeliste(String newSptCommentModeliste) {
        sptCommentModeliste = newSptCommentModeliste;
        if (persist > 0)
            updCol[DosuiviProtoTeteDesc.SPT_COMMENT_MODELISTE] = 1;
    }

    public void setSptCommentBureau(String newSptCommentBureau) {
        sptCommentBureau = newSptCommentBureau;
        if (persist > 0)
            updCol[DosuiviProtoTeteDesc.SPT_COMMENT_BUREAU] = 1;
    }

    public void setSptStatus(String newSptStatus) {
        sptStatus = newSptStatus;
        if (persist > 0)
            updCol[DosuiviProtoTeteDesc.SPT_STATUS] = 1;
    }

    public void setSptPicTissu(byte[] newSptPicTissu) {
        sptPicTissu = newSptPicTissu;
        if (persist > 0)
            updCol[DosuiviProtoTeteDesc.SPT_PIC_TISSU] = 1;
    }

    public void setSptPicModele(byte[] newSptPicModele) {
        sptPicModele = newSptPicModele;
        if (persist > 0)
            updCol[DosuiviProtoTeteDesc.SPT_PIC_MODELE] = 1;
    }

    public Object get(int numCol) {
        if (numCol == DosuiviProtoTeteDesc.SPT_MODELE_CODE)
            return sptModeleCode;
        else if (numCol == DosuiviProtoTeteDesc.SPT_CLT_AN)
            return sptCltAn;
        else if (numCol == DosuiviProtoTeteDesc.SPT_CLT_SAI_CODE)
            return sptCltSaiCode;
        else if (numCol == DosuiviProtoTeteDesc.SPT_CLT_CODE)
            return sptCltCode;
        else if (numCol == DosuiviProtoTeteDesc.SPT_NOM_MODELE)
            return sptNomModele;
        else if (numCol == DosuiviProtoTeteDesc.SPT_REF_NODHOS)
            return sptRefNodhos;
        else if (numCol == DosuiviProtoTeteDesc.SPT_FAA_CODE)
            return sptFaaCode;
        else if (numCol == DosuiviProtoTeteDesc.SPT_SFA_CODE)
            return sptSfaCode;
        else if (numCol == DosuiviProtoTeteDesc.SPT_QUALITE)
            return sptQualite;
        else if (numCol == DosuiviProtoTeteDesc.SPT_LAVAGE)
            return sptLavage;
        else if (numCol == DosuiviProtoTeteDesc.SPT_FOU_CODE_TISSU)
            return sptFouCodeTissu;
        else if (numCol == DosuiviProtoTeteDesc.SPT_BUREAU_TYPE)
            return sptBureauType;
        else if (numCol == DosuiviProtoTeteDesc.SPT_BUREAU_CODE)
            return sptBureauCode;
        else if (numCol == DosuiviProtoTeteDesc.SPT_FAC_CODE)
            return sptFacCode;
        else if (numCol == DosuiviProtoTeteDesc.SPT_DT_TRANSMISSION)
            return sptDtTransmission;
        else if (numCol == DosuiviProtoTeteDesc.SPT_DT_ENV_FTECH_BUR)
            return sptDtEnvFtechBur;
        else if (numCol == DosuiviProtoTeteDesc.SPT_DT_ENV_CT_BUR)
            return sptDtEnvCtBur;
        else if (numCol == DosuiviProtoTeteDesc.SPT_DT_RECEP_FTECH_BUR)
            return sptDtRecepFtechBur;
        else if (numCol == DosuiviProtoTeteDesc.SPT_DT_RECEP_CT_BUR)
            return sptDtRecepCtBur;
        else if (numCol == DosuiviProtoTeteDesc.SPT_ENV_CTYPE_ESSAI_MAT)
            return sptEnvCtypeEssaiMat;
        else if (numCol == DosuiviProtoTeteDesc.SPT_PRIX_FACON)
            return sptPrixFacon;
        else if (numCol == DosuiviProtoTeteDesc.SPT_EMP_PROVISOIRE)
            return sptEmpProvisoire;
        else if (numCol == DosuiviProtoTeteDesc.SPT_RECEP_DISQ_PAT)
            return sptRecepDisqPat;
        else if (numCol == DosuiviProtoTeteDesc.SPT_DT_ENV_PATRONAGE)
            return sptDtEnvPatronage;
        else if (numCol == DosuiviProtoTeteDesc.SPT_DT_RECEP_PAT)
            return sptDtRecepPat;
        else if (numCol == DosuiviProtoTeteDesc.SPT_DT_ENV_FTECH_FAC)
            return sptDtEnvFtechFac;
        else if (numCol == DosuiviProtoTeteDesc.SPT_DT_ENV_CT_FAC)
            return sptDtEnvCtFac;
        else if (numCol == DosuiviProtoTeteDesc.SPT_DT_RECEP_FTECH_FAC)
            return sptDtRecepFtechFac;
        else if (numCol == DosuiviProtoTeteDesc.SPT_DT_RECEP_CT_FAC)
            return sptDtRecepCtFac;
        else if (numCol == DosuiviProtoTeteDesc.SPT_DDE_TETE_SERIE)
            return sptDdeTeteSerie;
        else if (numCol == DosuiviProtoTeteDesc.SPT_TETE_SERIE)
            return sptTeteSerie;
        else if (numCol == DosuiviProtoTeteDesc.SPT_OK_ACCESSOIRES)
            return sptOkAccessoires;
        else if (numCol == DosuiviProtoTeteDesc.SPT_OK_COLORIS)
            return sptOkColoris;
        else if (numCol == DosuiviProtoTeteDesc.SPT_EMPLOI_DEF)
            return sptEmploiDef;
        else if (numCol == DosuiviProtoTeteDesc.SPT_OK_PROD_ENTREP)
            return sptOkProdEntrep;
        else if (numCol == DosuiviProtoTeteDesc.SPT_OK_MATIERE)
            return sptOkMatiere;
        else if (numCol == DosuiviProtoTeteDesc.SPT_DEBUT_PROD)
            return sptDebutProd;
        else if (numCol == DosuiviProtoTeteDesc.SPT_VALID_ECHAN_SOURCE)
            return sptValidEchanSource;
        else if (numCol == DosuiviProtoTeteDesc.SPT_COMMENT_ACHATS)
            return sptCommentAchats;
        else if (numCol == DosuiviProtoTeteDesc.SPT_COMMENT_MODELISTE)
            return sptCommentModeliste;
        else if (numCol == DosuiviProtoTeteDesc.SPT_COMMENT_BUREAU)
            return sptCommentBureau;
        else if (numCol == DosuiviProtoTeteDesc.SPT_STATUS)
            return sptStatus;
        else if (numCol == DosuiviProtoTeteDesc.SPT_PIC_TISSU)
            return sptPicTissu;
        else if (numCol == DosuiviProtoTeteDesc.SPT_PIC_MODELE)
            return sptPicModele;
        return null;
    }

    public void set(int numCol, Object value) {
        if (numCol == DosuiviProtoTeteDesc.SPT_MODELE_CODE) {
            sptModeleCode = (Integer) value;
        }
        if (numCol == DosuiviProtoTeteDesc.SPT_CLT_AN) {
            sptCltAn = (String) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoTeteDesc.SPT_CLT_SAI_CODE) {
            sptCltSaiCode = (String) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoTeteDesc.SPT_CLT_CODE) {
            sptCltCode = (String) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoTeteDesc.SPT_NOM_MODELE) {
            sptNomModele = (String) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoTeteDesc.SPT_REF_NODHOS) {
            sptRefNodhos = (String) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoTeteDesc.SPT_FAA_CODE) {
            sptFaaCode = (String) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoTeteDesc.SPT_SFA_CODE) {
            sptSfaCode = (String) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoTeteDesc.SPT_QUALITE) {
            sptQualite = (String) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoTeteDesc.SPT_LAVAGE) {
            sptLavage = (String) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoTeteDesc.SPT_FOU_CODE_TISSU) {
            sptFouCodeTissu = (String) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoTeteDesc.SPT_BUREAU_TYPE) {
            sptBureauType = (String) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoTeteDesc.SPT_BUREAU_CODE) {
            sptBureauCode = (String) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoTeteDesc.SPT_FAC_CODE) {
            sptFacCode = (String) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoTeteDesc.SPT_DT_TRANSMISSION) {
            sptDtTransmission = (Timestamp) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoTeteDesc.SPT_DT_ENV_FTECH_BUR) {
            sptDtEnvFtechBur = (Timestamp) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoTeteDesc.SPT_DT_ENV_CT_BUR) {
            sptDtEnvCtBur = (Timestamp) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoTeteDesc.SPT_DT_RECEP_FTECH_BUR) {
            sptDtRecepFtechBur = (Timestamp) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoTeteDesc.SPT_DT_RECEP_CT_BUR) {
            sptDtRecepCtBur = (Timestamp) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoTeteDesc.SPT_ENV_CTYPE_ESSAI_MAT) {
            sptEnvCtypeEssaiMat = (String) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoTeteDesc.SPT_PRIX_FACON) {
            sptPrixFacon = (Double) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoTeteDesc.SPT_EMP_PROVISOIRE) {
            sptEmpProvisoire = (Double) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoTeteDesc.SPT_RECEP_DISQ_PAT) {
            sptRecepDisqPat = (Timestamp) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoTeteDesc.SPT_DT_ENV_PATRONAGE) {
            sptDtEnvPatronage = (Timestamp) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoTeteDesc.SPT_DT_RECEP_PAT) {
            sptDtRecepPat = (Timestamp) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoTeteDesc.SPT_DT_ENV_FTECH_FAC) {
            sptDtEnvFtechFac = (Timestamp) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoTeteDesc.SPT_DT_ENV_CT_FAC) {
            sptDtEnvCtFac = (Timestamp) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoTeteDesc.SPT_DT_RECEP_FTECH_FAC) {
            sptDtRecepFtechFac = (Timestamp) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoTeteDesc.SPT_DT_RECEP_CT_FAC) {
            sptDtRecepCtFac = (Timestamp) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoTeteDesc.SPT_DDE_TETE_SERIE) {
            sptDdeTeteSerie = (String) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoTeteDesc.SPT_TETE_SERIE) {
            sptTeteSerie = (Timestamp) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoTeteDesc.SPT_OK_ACCESSOIRES) {
            sptOkAccessoires = (Timestamp) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoTeteDesc.SPT_OK_COLORIS) {
            sptOkColoris = (Timestamp) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoTeteDesc.SPT_EMPLOI_DEF) {
            sptEmploiDef = (Double) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoTeteDesc.SPT_OK_PROD_ENTREP) {
            sptOkProdEntrep = (Timestamp) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoTeteDesc.SPT_OK_MATIERE) {
            sptOkMatiere = (Timestamp) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoTeteDesc.SPT_DEBUT_PROD) {
            sptDebutProd = (Timestamp) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoTeteDesc.SPT_VALID_ECHAN_SOURCE) {
            sptValidEchanSource = (Timestamp) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoTeteDesc.SPT_COMMENT_ACHATS) {
            sptCommentAchats = (String) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoTeteDesc.SPT_COMMENT_MODELISTE) {
            sptCommentModeliste = (String) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoTeteDesc.SPT_COMMENT_BUREAU) {
            sptCommentBureau = (String) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoTeteDesc.SPT_STATUS) {
            sptStatus = (String) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoTeteDesc.SPT_PIC_TISSU) {
            sptPicTissu = (byte[]) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoTeteDesc.SPT_PIC_MODELE) {
            sptPicModele = (byte[]) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
    }

    public DataObject setProperty(SqlArg sqlArg) throws SQLException {
        return setProperty(sqlArg, new DosuiviProtoTete());
    }

    private DataObject setProperty(SqlArg sqlArg, DosuiviProtoTete djo) throws
            SQLException {
        ResultSet rs = sqlArg.getResultSet();
        int[] val = sqlArg.getVal();
        if (val[DosuiviProtoTeteDesc.SPT_MODELE_CODE] != -1) {
            int temp = rs.getInt(val[DosuiviProtoTeteDesc.SPT_MODELE_CODE]);
            if (!rs.wasNull())
                djo.sptModeleCode = new Integer(temp);
        }
        if (val[DosuiviProtoTeteDesc.SPT_CLT_AN] != -1) {
            djo.sptCltAn = rs.getString(val[DosuiviProtoTeteDesc.SPT_CLT_AN]);
        }
        if (val[DosuiviProtoTeteDesc.SPT_CLT_SAI_CODE] != -1) {
            djo.sptCltSaiCode = rs.getString(val[DosuiviProtoTeteDesc.SPT_CLT_SAI_CODE]);
        }
        if (val[DosuiviProtoTeteDesc.SPT_CLT_CODE] != -1) {
            djo.sptCltCode = rs.getString(val[DosuiviProtoTeteDesc.SPT_CLT_CODE]);
        }
        if (val[DosuiviProtoTeteDesc.SPT_NOM_MODELE] != -1) {
            djo.sptNomModele = rs.getString(val[DosuiviProtoTeteDesc.SPT_NOM_MODELE]);
        }
        if (val[DosuiviProtoTeteDesc.SPT_REF_NODHOS] != -1) {
            djo.sptRefNodhos = rs.getString(val[DosuiviProtoTeteDesc.SPT_REF_NODHOS]);
        }
        if (val[DosuiviProtoTeteDesc.SPT_FAA_CODE] != -1) {
            djo.sptFaaCode = rs.getString(val[DosuiviProtoTeteDesc.SPT_FAA_CODE]);
        }
        if (val[DosuiviProtoTeteDesc.SPT_SFA_CODE] != -1) {
            djo.sptSfaCode = rs.getString(val[DosuiviProtoTeteDesc.SPT_SFA_CODE]);
        }
        if (val[DosuiviProtoTeteDesc.SPT_QUALITE] != -1) {
            djo.sptQualite = rs.getString(val[DosuiviProtoTeteDesc.SPT_QUALITE]);
        }
        if (val[DosuiviProtoTeteDesc.SPT_LAVAGE] != -1) {
            djo.sptLavage = rs.getString(val[DosuiviProtoTeteDesc.SPT_LAVAGE]);
        }
        if (val[DosuiviProtoTeteDesc.SPT_FOU_CODE_TISSU] != -1) {
            djo.sptFouCodeTissu = rs.getString(val[DosuiviProtoTeteDesc.SPT_FOU_CODE_TISSU]);
        }
        if (val[DosuiviProtoTeteDesc.SPT_BUREAU_TYPE] != -1) {
            djo.sptBureauType = rs.getString(val[DosuiviProtoTeteDesc.SPT_BUREAU_TYPE]);
        }
        if (val[DosuiviProtoTeteDesc.SPT_BUREAU_CODE] != -1) {
            djo.sptBureauCode = rs.getString(val[DosuiviProtoTeteDesc.SPT_BUREAU_CODE]);
        }
        if (val[DosuiviProtoTeteDesc.SPT_FAC_CODE] != -1) {
            djo.sptFacCode = rs.getString(val[DosuiviProtoTeteDesc.SPT_FAC_CODE]);
        }
        if (val[DosuiviProtoTeteDesc.SPT_DT_TRANSMISSION] != -1) {
            djo.sptDtTransmission = rs.getTimestamp(val[DosuiviProtoTeteDesc.SPT_DT_TRANSMISSION]);
        }
        if (val[DosuiviProtoTeteDesc.SPT_DT_ENV_FTECH_BUR] != -1) {
            djo.sptDtEnvFtechBur = rs.getTimestamp(val[DosuiviProtoTeteDesc.SPT_DT_ENV_FTECH_BUR]);
        }
        if (val[DosuiviProtoTeteDesc.SPT_DT_ENV_CT_BUR] != -1) {
            djo.sptDtEnvCtBur = rs.getTimestamp(val[DosuiviProtoTeteDesc.SPT_DT_ENV_CT_BUR]);
        }
        if (val[DosuiviProtoTeteDesc.SPT_DT_RECEP_FTECH_BUR] != -1) {
            djo.sptDtRecepFtechBur = rs.getTimestamp(val[DosuiviProtoTeteDesc.SPT_DT_RECEP_FTECH_BUR]);
        }
        if (val[DosuiviProtoTeteDesc.SPT_DT_RECEP_CT_BUR] != -1) {
            djo.sptDtRecepCtBur = rs.getTimestamp(val[DosuiviProtoTeteDesc.SPT_DT_RECEP_CT_BUR]);
        }
        if (val[DosuiviProtoTeteDesc.SPT_ENV_CTYPE_ESSAI_MAT] != -1) {
            djo.sptEnvCtypeEssaiMat = rs.getString(val[DosuiviProtoTeteDesc.SPT_ENV_CTYPE_ESSAI_MAT]);
        }
        if (val[DosuiviProtoTeteDesc.SPT_PRIX_FACON] != -1) {
        }
        if (val[DosuiviProtoTeteDesc.SPT_EMP_PROVISOIRE] != -1) {
        }
        if (val[DosuiviProtoTeteDesc.SPT_RECEP_DISQ_PAT] != -1) {
            djo.sptRecepDisqPat = rs.getTimestamp(val[DosuiviProtoTeteDesc.SPT_RECEP_DISQ_PAT]);
        }
        if (val[DosuiviProtoTeteDesc.SPT_DT_ENV_PATRONAGE] != -1) {
            djo.sptDtEnvPatronage = rs.getTimestamp(val[DosuiviProtoTeteDesc.SPT_DT_ENV_PATRONAGE]);
        }
        if (val[DosuiviProtoTeteDesc.SPT_DT_RECEP_PAT] != -1) {
            djo.sptDtRecepPat = rs.getTimestamp(val[DosuiviProtoTeteDesc.SPT_DT_RECEP_PAT]);
        }
        if (val[DosuiviProtoTeteDesc.SPT_DT_ENV_FTECH_FAC] != -1) {
            djo.sptDtEnvFtechFac = rs.getTimestamp(val[DosuiviProtoTeteDesc.SPT_DT_ENV_FTECH_FAC]);
        }
        if (val[DosuiviProtoTeteDesc.SPT_DT_ENV_CT_FAC] != -1) {
            djo.sptDtEnvCtFac = rs.getTimestamp(val[DosuiviProtoTeteDesc.SPT_DT_ENV_CT_FAC]);
        }
        if (val[DosuiviProtoTeteDesc.SPT_DT_RECEP_FTECH_FAC] != -1) {
            djo.sptDtRecepFtechFac = rs.getTimestamp(val[DosuiviProtoTeteDesc.SPT_DT_RECEP_FTECH_FAC]);
        }
        if (val[DosuiviProtoTeteDesc.SPT_DT_RECEP_CT_FAC] != -1) {
            djo.sptDtRecepCtFac = rs.getTimestamp(val[DosuiviProtoTeteDesc.SPT_DT_RECEP_CT_FAC]);
        }
        if (val[DosuiviProtoTeteDesc.SPT_DDE_TETE_SERIE] != -1) {
            djo.sptDdeTeteSerie = rs.getString(val[DosuiviProtoTeteDesc.SPT_DDE_TETE_SERIE]);
        }
        if (val[DosuiviProtoTeteDesc.SPT_TETE_SERIE] != -1) {
            djo.sptTeteSerie = rs.getTimestamp(val[DosuiviProtoTeteDesc.SPT_TETE_SERIE]);
        }
        if (val[DosuiviProtoTeteDesc.SPT_OK_ACCESSOIRES] != -1) {
            djo.sptOkAccessoires = rs.getTimestamp(val[DosuiviProtoTeteDesc.SPT_OK_ACCESSOIRES]);
        }
        if (val[DosuiviProtoTeteDesc.SPT_OK_COLORIS] != -1) {
            djo.sptOkColoris = rs.getTimestamp(val[DosuiviProtoTeteDesc.SPT_OK_COLORIS]);
        }
        if (val[DosuiviProtoTeteDesc.SPT_EMPLOI_DEF] != -1) {
        }
        if (val[DosuiviProtoTeteDesc.SPT_OK_PROD_ENTREP] != -1) {
            djo.sptOkProdEntrep = rs.getTimestamp(val[DosuiviProtoTeteDesc.SPT_OK_PROD_ENTREP]);
        }
        if (val[DosuiviProtoTeteDesc.SPT_OK_MATIERE] != -1) {
            djo.sptOkMatiere = rs.getTimestamp(val[DosuiviProtoTeteDesc.SPT_OK_MATIERE]);
        }
        if (val[DosuiviProtoTeteDesc.SPT_DEBUT_PROD] != -1) {
            djo.sptDebutProd = rs.getTimestamp(val[DosuiviProtoTeteDesc.SPT_DEBUT_PROD]);
        }
        if (val[DosuiviProtoTeteDesc.SPT_VALID_ECHAN_SOURCE] != -1) {
            djo.sptValidEchanSource = rs.getTimestamp(val[DosuiviProtoTeteDesc.SPT_VALID_ECHAN_SOURCE]);
        }
        if (val[DosuiviProtoTeteDesc.SPT_COMMENT_ACHATS] != -1) {
            djo.sptCommentAchats = rs.getString(val[DosuiviProtoTeteDesc.SPT_COMMENT_ACHATS]);
        }
        if (val[DosuiviProtoTeteDesc.SPT_COMMENT_MODELISTE] != -1) {
            djo.sptCommentModeliste = rs.getString(val[DosuiviProtoTeteDesc.SPT_COMMENT_MODELISTE]);
        }
        if (val[DosuiviProtoTeteDesc.SPT_COMMENT_BUREAU] != -1) {
            djo.sptCommentBureau = rs.getString(val[DosuiviProtoTeteDesc.SPT_COMMENT_BUREAU]);
        }
        if (val[DosuiviProtoTeteDesc.SPT_STATUS] != -1) {
            djo.sptStatus = rs.getString(val[DosuiviProtoTeteDesc.SPT_STATUS]);
        }
        if (val[DosuiviProtoTeteDesc.SPT_PIC_TISSU] != -1) {
        }
        if (val[DosuiviProtoTeteDesc.SPT_PIC_MODELE] != -1) {
        }
        return djo;
    }

    public void getProperty(SqlArg sqlArg) throws SQLException {
        PreparedStatement stmt = sqlArg.getStmt();
        int[] val = sqlArg.getVal();
        if (val[DosuiviProtoTeteDesc.SPT_MODELE_CODE] > 0) {
            if (sptModeleCode == null)
                stmt.setNull(val[DosuiviProtoTeteDesc.SPT_MODELE_CODE], 3);
            else
                stmt.setInt(val[DosuiviProtoTeteDesc.SPT_MODELE_CODE], sptModeleCode.intValue());
        }
        if (val[DosuiviProtoTeteDesc.SPT_CLT_AN] > 0) {
            stmt.setString(val[DosuiviProtoTeteDesc.SPT_CLT_AN], sptCltAn);
        }
        if (val[DosuiviProtoTeteDesc.SPT_CLT_SAI_CODE] > 0) {
            stmt.setString(val[DosuiviProtoTeteDesc.SPT_CLT_SAI_CODE], sptCltSaiCode);
        }
        if (val[DosuiviProtoTeteDesc.SPT_CLT_CODE] > 0) {
            stmt.setString(val[DosuiviProtoTeteDesc.SPT_CLT_CODE], sptCltCode);
        }
        if (val[DosuiviProtoTeteDesc.SPT_NOM_MODELE] > 0) {
            stmt.setString(val[DosuiviProtoTeteDesc.SPT_NOM_MODELE], sptNomModele);
        }
        if (val[DosuiviProtoTeteDesc.SPT_REF_NODHOS] > 0) {
            stmt.setString(val[DosuiviProtoTeteDesc.SPT_REF_NODHOS], sptRefNodhos);
        }
        if (val[DosuiviProtoTeteDesc.SPT_FAA_CODE] > 0) {
            stmt.setString(val[DosuiviProtoTeteDesc.SPT_FAA_CODE], sptFaaCode);
        }
        if (val[DosuiviProtoTeteDesc.SPT_SFA_CODE] > 0) {
            stmt.setString(val[DosuiviProtoTeteDesc.SPT_SFA_CODE], sptSfaCode);
        }
        if (val[DosuiviProtoTeteDesc.SPT_QUALITE] > 0) {
            stmt.setString(val[DosuiviProtoTeteDesc.SPT_QUALITE], sptQualite);
        }
        if (val[DosuiviProtoTeteDesc.SPT_LAVAGE] > 0) {
            stmt.setString(val[DosuiviProtoTeteDesc.SPT_LAVAGE], sptLavage);
        }
        if (val[DosuiviProtoTeteDesc.SPT_FOU_CODE_TISSU] > 0) {
            stmt.setString(val[DosuiviProtoTeteDesc.SPT_FOU_CODE_TISSU], sptFouCodeTissu);
        }
        if (val[DosuiviProtoTeteDesc.SPT_BUREAU_TYPE] > 0) {
            stmt.setString(val[DosuiviProtoTeteDesc.SPT_BUREAU_TYPE], sptBureauType);
        }
        if (val[DosuiviProtoTeteDesc.SPT_BUREAU_CODE] > 0) {
            stmt.setString(val[DosuiviProtoTeteDesc.SPT_BUREAU_CODE], sptBureauCode);
        }
        if (val[DosuiviProtoTeteDesc.SPT_FAC_CODE] > 0) {
            stmt.setString(val[DosuiviProtoTeteDesc.SPT_FAC_CODE], sptFacCode);
        }
        if (val[DosuiviProtoTeteDesc.SPT_DT_TRANSMISSION] > 0) {
            stmt.setTimestamp(val[DosuiviProtoTeteDesc.SPT_DT_TRANSMISSION], sptDtTransmission);
        }
        if (val[DosuiviProtoTeteDesc.SPT_DT_ENV_FTECH_BUR] > 0) {
            stmt.setTimestamp(val[DosuiviProtoTeteDesc.SPT_DT_ENV_FTECH_BUR], sptDtEnvFtechBur);
        }
        if (val[DosuiviProtoTeteDesc.SPT_DT_ENV_CT_BUR] > 0) {
            stmt.setTimestamp(val[DosuiviProtoTeteDesc.SPT_DT_ENV_CT_BUR], sptDtEnvCtBur);
        }
        if (val[DosuiviProtoTeteDesc.SPT_DT_RECEP_FTECH_BUR] > 0) {
            stmt.setTimestamp(val[DosuiviProtoTeteDesc.SPT_DT_RECEP_FTECH_BUR], sptDtRecepFtechBur);
        }
        if (val[DosuiviProtoTeteDesc.SPT_DT_RECEP_CT_BUR] > 0) {
            stmt.setTimestamp(val[DosuiviProtoTeteDesc.SPT_DT_RECEP_CT_BUR], sptDtRecepCtBur);
        }
        if (val[DosuiviProtoTeteDesc.SPT_ENV_CTYPE_ESSAI_MAT] > 0) {
            stmt.setString(val[DosuiviProtoTeteDesc.SPT_ENV_CTYPE_ESSAI_MAT], sptEnvCtypeEssaiMat);
        }
        if (val[DosuiviProtoTeteDesc.SPT_PRIX_FACON] > 0) {
            stmt.setObject(val[DosuiviProtoTeteDesc.SPT_PRIX_FACON], sptPrixFacon);
        }
        if (val[DosuiviProtoTeteDesc.SPT_EMP_PROVISOIRE] > 0) {
            stmt.setObject(val[DosuiviProtoTeteDesc.SPT_EMP_PROVISOIRE], sptEmpProvisoire);
        }
        if (val[DosuiviProtoTeteDesc.SPT_RECEP_DISQ_PAT] > 0) {
            stmt.setTimestamp(val[DosuiviProtoTeteDesc.SPT_RECEP_DISQ_PAT], sptRecepDisqPat);
        }
        if (val[DosuiviProtoTeteDesc.SPT_DT_ENV_PATRONAGE] > 0) {
            stmt.setTimestamp(val[DosuiviProtoTeteDesc.SPT_DT_ENV_PATRONAGE], sptDtEnvPatronage);
        }
        if (val[DosuiviProtoTeteDesc.SPT_DT_RECEP_PAT] > 0) {
            stmt.setTimestamp(val[DosuiviProtoTeteDesc.SPT_DT_RECEP_PAT], sptDtRecepPat);
        }
        if (val[DosuiviProtoTeteDesc.SPT_DT_ENV_FTECH_FAC] > 0) {
            stmt.setTimestamp(val[DosuiviProtoTeteDesc.SPT_DT_ENV_FTECH_FAC], sptDtEnvFtechFac);
        }
        if (val[DosuiviProtoTeteDesc.SPT_DT_ENV_CT_FAC] > 0) {
            stmt.setTimestamp(val[DosuiviProtoTeteDesc.SPT_DT_ENV_CT_FAC], sptDtEnvCtFac);
        }
        if (val[DosuiviProtoTeteDesc.SPT_DT_RECEP_FTECH_FAC] > 0) {
            stmt.setTimestamp(val[DosuiviProtoTeteDesc.SPT_DT_RECEP_FTECH_FAC], sptDtRecepFtechFac);
        }
        if (val[DosuiviProtoTeteDesc.SPT_DT_RECEP_CT_FAC] > 0) {
            stmt.setTimestamp(val[DosuiviProtoTeteDesc.SPT_DT_RECEP_CT_FAC], sptDtRecepCtFac);
        }
        if (val[DosuiviProtoTeteDesc.SPT_DDE_TETE_SERIE] > 0) {
            stmt.setString(val[DosuiviProtoTeteDesc.SPT_DDE_TETE_SERIE], sptDdeTeteSerie);
        }
        if (val[DosuiviProtoTeteDesc.SPT_TETE_SERIE] > 0) {
            stmt.setTimestamp(val[DosuiviProtoTeteDesc.SPT_TETE_SERIE], sptTeteSerie);
        }
        if (val[DosuiviProtoTeteDesc.SPT_OK_ACCESSOIRES] > 0) {
            stmt.setTimestamp(val[DosuiviProtoTeteDesc.SPT_OK_ACCESSOIRES], sptOkAccessoires);
        }
        if (val[DosuiviProtoTeteDesc.SPT_OK_COLORIS] > 0) {
            stmt.setTimestamp(val[DosuiviProtoTeteDesc.SPT_OK_COLORIS], sptOkColoris);
        }
        if (val[DosuiviProtoTeteDesc.SPT_EMPLOI_DEF] > 0) {
            stmt.setObject(val[DosuiviProtoTeteDesc.SPT_EMPLOI_DEF], sptEmploiDef);
        }
        if (val[DosuiviProtoTeteDesc.SPT_OK_PROD_ENTREP] > 0) {
            stmt.setTimestamp(val[DosuiviProtoTeteDesc.SPT_OK_PROD_ENTREP], sptOkProdEntrep);
        }
        if (val[DosuiviProtoTeteDesc.SPT_OK_MATIERE] > 0) {
            stmt.setTimestamp(val[DosuiviProtoTeteDesc.SPT_OK_MATIERE], sptOkMatiere);
        }
        if (val[DosuiviProtoTeteDesc.SPT_DEBUT_PROD] > 0) {
            stmt.setTimestamp(val[DosuiviProtoTeteDesc.SPT_DEBUT_PROD], sptDebutProd);
        }
        if (val[DosuiviProtoTeteDesc.SPT_VALID_ECHAN_SOURCE] > 0) {
            stmt.setTimestamp(val[DosuiviProtoTeteDesc.SPT_VALID_ECHAN_SOURCE], sptValidEchanSource);
        }
        if (val[DosuiviProtoTeteDesc.SPT_COMMENT_ACHATS] > 0) {
            stmt.setString(val[DosuiviProtoTeteDesc.SPT_COMMENT_ACHATS], sptCommentAchats);
        }
        if (val[DosuiviProtoTeteDesc.SPT_COMMENT_MODELISTE] > 0) {
            stmt.setString(val[DosuiviProtoTeteDesc.SPT_COMMENT_MODELISTE], sptCommentModeliste);
        }
        if (val[DosuiviProtoTeteDesc.SPT_COMMENT_BUREAU] > 0) {
            stmt.setString(val[DosuiviProtoTeteDesc.SPT_COMMENT_BUREAU], sptCommentBureau);
        }
        if (val[DosuiviProtoTeteDesc.SPT_STATUS] > 0) {
            stmt.setString(val[DosuiviProtoTeteDesc.SPT_STATUS], sptStatus);
        }
        if (val[DosuiviProtoTeteDesc.SPT_PIC_TISSU] > 0) {
            stmt.setObject(val[DosuiviProtoTeteDesc.SPT_PIC_TISSU], sptPicTissu);
        }
        if (val[DosuiviProtoTeteDesc.SPT_PIC_MODELE] > 0) {
            stmt.setObject(val[DosuiviProtoTeteDesc.SPT_PIC_MODELE], sptPicModele);
        }
    }

    /**
     * M�thode g�n�r�e automatiquement permettant de remplir un dataobject �
     * partir des valeurs
     * d'une requ�te http.
     * Les noms des param�tres de la requ�te doivent �tre strictement
     * identique aux noms des attributs du DataObject.
     * Cette m�thode peut �tre compl�t�e afin de prendre en compte d'�ventuels
     * param�tres se trouvant en session.
     * Pour une reg�n�ration �ventuelle, faites attention � ne coder qu'entre
     * les tags de d�but et de fin.
     * Date de cr�ation : (25/05/01 08:03:14)
     *
     * @param request javax.servlet.http.HttpServletRequest
     */
    public DataObject[] setParameters(HttpServletRequest request)
            throws ParameterException, java.text.ParseException {
        String[] params = null;
        String localVal = null;
        int size = 0;
        DosuiviProtoTete[] result = null;
        params = request.getParameterValues("sptModeleCode");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoTete[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoTete();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSptModeleCode((Integer)
                        StrConvertor.convert(localVal, Integer.class));
            }
        }
        params = request.getParameterValues("sptCltAn");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoTete[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoTete();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSptCltAn(localVal);
            }
        }
        params = request.getParameterValues("sptCltSaiCode");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoTete[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoTete();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSptCltSaiCode(localVal);
            }
        }
        params = request.getParameterValues("sptCltCode");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoTete[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoTete();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSptCltCode(localVal);
            }
        }
        params = request.getParameterValues("sptNomModele");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoTete[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoTete();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSptNomModele(localVal);
            }
        }
        params = request.getParameterValues("sptRefNodhos");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoTete[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoTete();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSptRefNodhos(localVal);
            }
        }
        params = request.getParameterValues("sptFaaCode");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoTete[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoTete();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSptFaaCode(localVal);
            }
        }
        params = request.getParameterValues("sptSfaCode");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoTete[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoTete();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSptSfaCode(localVal);
            }
        }
        params = request.getParameterValues("sptQualite");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoTete[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoTete();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSptQualite(localVal);
            }
        }
        params = request.getParameterValues("sptLavage");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoTete[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoTete();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSptLavage(localVal);
            }
        }
        params = request.getParameterValues("sptFouCodeTissu");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoTete[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoTete();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSptFouCodeTissu(localVal);
            }
        }
        params = request.getParameterValues("sptBureauType");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoTete[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoTete();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSptBureauType(localVal);
            }
        }
        params = request.getParameterValues("sptBureauCode");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoTete[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoTete();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSptBureauCode(localVal);
            }
        }
        params = request.getParameterValues("sptFacCode");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoTete[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoTete();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSptFacCode(localVal);
            }
        }
        params = request.getParameterValues("sptDtTransmission");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoTete[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoTete();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSptDtTransmission((Timestamp)
                        StrConvertor.convert(localVal, Timestamp.class));
            }
        }
        params = request.getParameterValues("sptDtEnvFtechBur");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoTete[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoTete();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSptDtEnvFtechBur((Timestamp)
                        StrConvertor.convert(localVal, Timestamp.class));
            }
        }
        params = request.getParameterValues("sptDtEnvCtBur");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoTete[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoTete();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSptDtEnvCtBur((Timestamp)
                        StrConvertor.convert(localVal, Timestamp.class));
            }
        }
        params = request.getParameterValues("sptDtRecepFtechBur");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoTete[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoTete();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSptDtRecepFtechBur((Timestamp)
                        StrConvertor.convert(localVal, Timestamp.class));
            }
        }
        params = request.getParameterValues("sptDtRecepCtBur");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoTete[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoTete();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSptDtRecepCtBur((Timestamp)
                        StrConvertor.convert(localVal, Timestamp.class));
            }
        }
        params = request.getParameterValues("sptEnvCtypeEssaiMat");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoTete[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoTete();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSptEnvCtypeEssaiMat(localVal);
            }
        }
        params = request.getParameterValues("sptPrixFacon");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoTete[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoTete();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSptPrixFacon((Double)
                        StrConvertor.convert(localVal, Double.class));
            }
        }
        params = request.getParameterValues("sptEmpProvisoire");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoTete[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoTete();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSptEmpProvisoire((Double)
                        StrConvertor.convert(localVal, Double.class));
            }
        }
        params = request.getParameterValues("sptRecepDisqPat");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoTete[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoTete();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSptRecepDisqPat((Timestamp)
                        StrConvertor.convert(localVal, Timestamp.class));
            }
        }
        params = request.getParameterValues("sptDtEnvPatronage");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoTete[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoTete();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSptDtEnvPatronage((Timestamp)
                        StrConvertor.convert(localVal, Timestamp.class));
            }
        }
        params = request.getParameterValues("sptDtRecepPat");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoTete[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoTete();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSptDtRecepPat((Timestamp)
                        StrConvertor.convert(localVal, Timestamp.class));
            }
        }
        params = request.getParameterValues("sptDtEnvFtechFac");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoTete[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoTete();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSptDtEnvFtechFac((Timestamp)
                        StrConvertor.convert(localVal, Timestamp.class));
            }
        }
        params = request.getParameterValues("sptDtEnvCtFac");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoTete[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoTete();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSptDtEnvCtFac((Timestamp)
                        StrConvertor.convert(localVal, Timestamp.class));
            }
        }
        params = request.getParameterValues("sptDtRecepFtechFac");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoTete[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoTete();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSptDtRecepFtechFac((Timestamp)
                        StrConvertor.convert(localVal, Timestamp.class));
            }
        }
        params = request.getParameterValues("sptDtRecepCtFac");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoTete[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoTete();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSptDtRecepCtFac((Timestamp)
                        StrConvertor.convert(localVal, Timestamp.class));
            }
        }
        params = request.getParameterValues("sptDdeTeteSerie");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoTete[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoTete();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSptDdeTeteSerie(localVal);
            }
        }
        params = request.getParameterValues("sptTeteSerie");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoTete[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoTete();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSptTeteSerie((Timestamp)
                        StrConvertor.convert(localVal, Timestamp.class));
            }
        }
        params = request.getParameterValues("sptOkAccessoires");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoTete[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoTete();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSptOkAccessoires((Timestamp)
                        StrConvertor.convert(localVal, Timestamp.class));
            }
        }
        params = request.getParameterValues("sptOkColoris");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoTete[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoTete();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSptOkColoris((Timestamp)
                        StrConvertor.convert(localVal, Timestamp.class));
            }
        }
        params = request.getParameterValues("sptEmploiDef");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoTete[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoTete();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSptEmploiDef((Double)
                        StrConvertor.convert(localVal, Double.class));
            }
        }
        params = request.getParameterValues("sptOkProdEntrep");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoTete[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoTete();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSptOkProdEntrep((Timestamp)
                        StrConvertor.convert(localVal, Timestamp.class));
            }
        }
        params = request.getParameterValues("sptOkMatiere");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoTete[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoTete();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSptOkMatiere((Timestamp)
                        StrConvertor.convert(localVal, Timestamp.class));
            }
        }
        params = request.getParameterValues("sptDebutProd");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoTete[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoTete();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSptDebutProd((Timestamp)
                        StrConvertor.convert(localVal, Timestamp.class));
            }
        }
        params = request.getParameterValues("sptValidEchanSource");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoTete[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoTete();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSptValidEchanSource((Timestamp)
                        StrConvertor.convert(localVal, Timestamp.class));
            }
        }
        params = request.getParameterValues("sptCommentAchats");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoTete[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoTete();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSptCommentAchats(localVal);
            }
        }
        params = request.getParameterValues("sptCommentModeliste");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoTete[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoTete();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSptCommentModeliste(localVal);
            }
        }
        params = request.getParameterValues("sptCommentBureau");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoTete[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoTete();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSptCommentBureau(localVal);
            }
        }
        params = request.getParameterValues("sptStatus");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoTete[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoTete();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSptStatus(localVal);
            }
        }
        params = request.getParameterValues("sptPicTissu");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoTete[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoTete();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSptPicTissu(localVal.getBytes());
            }
        }
        params = request.getParameterValues("sptPicModele");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoTete[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoTete();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSptPicModele(localVal.getBytes());
            }
        }
        /************************ INSTRUCTIONS DEVELOPPEMENT SPECIFIQUE*******************/
        /********************** FIN INSTRUCTIONS DEVELOPPEMENT SPECIFIQUE*****************/
        return result;
    }

    /*
     * @see DataObject#addChild(DataObject)
     */
    public void addChild(DataObject doChild) {
    }

    /*
     * @see DataObject#getDescription()
     */
    public IDoDescription getDescription() {
        return description;
    }

    /*
     * @see DataObject#getUpdateCol()
     */
    public int[] getUpdateCol() {
        return updCol;
    }
}
