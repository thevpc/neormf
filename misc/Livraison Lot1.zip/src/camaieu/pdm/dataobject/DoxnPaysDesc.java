package camaieu.pdm.dataobject;

import wg4.fwk.dataobject.IDoDescription;

import java.util.HashMap;

/**
 * /* Description de l'objetDoxnPays correspondant � la table XN_PAYS
 */
public class DoxnPaysDesc implements IDoDescription {
    public static final int PAY_CODE = 0;
    public static final int PAY_NOM = 1;
    public static final int PAY_NOM_INT = 2;
    public static final int PAY_NOM_GPE = 3;
    public static final int PAY_CEE = 4;
    public static final int PAY_NO_CEE = 5;
    public static final int PAY_NO_ORDRE = 6;
    public static final int PAY_DT_CREAT = 7;
    public static final int PAY_DT_MAJ = 8;
    public static final int PAY_UTIL_MAJ = 9;
    public static final int XTX_ID = 10;
    public static final int Z_STATUS = 11;

    public static final String tableName = "XN_PAYS";

    /*
     * Liste des noms de colonnes
     */
    public static final String[] dbColName = new String[]{
        "PAY_CODE", "PAY_NOM", "PAY_NOM_INT", "PAY_NOM_GPE", "PAY_CEE", "PAY_NO_CEE", "PAY_NO_ORDRE", "PAY_DT_CREAT", "PAY_DT_MAJ", "PAY_UTIL_MAJ", "XTX_ID", "Z_STATUS"};
    private static final HashMap colBase;

    static {
        colBase = new HashMap(12);
        colBase.put("PAY_CODE", new Integer(PAY_CODE));
        colBase.put("PAY_NOM", new Integer(PAY_NOM));
        colBase.put("PAY_NOM_INT", new Integer(PAY_NOM_INT));
        colBase.put("PAY_NOM_GPE", new Integer(PAY_NOM_GPE));
        colBase.put("PAY_CEE", new Integer(PAY_CEE));
        colBase.put("PAY_NO_CEE", new Integer(PAY_NO_CEE));
        colBase.put("PAY_NO_ORDRE", new Integer(PAY_NO_ORDRE));
        colBase.put("PAY_DT_CREAT", new Integer(PAY_DT_CREAT));
        colBase.put("PAY_DT_MAJ", new Integer(PAY_DT_MAJ));
        colBase.put("PAY_UTIL_MAJ", new Integer(PAY_UTIL_MAJ));
        colBase.put("XTX_ID", new Integer(XTX_ID));
        colBase.put("Z_STATUS", new Integer(Z_STATUS));
    }

    /*
     * Noms de colonnes de la cl� primaire
     */
    private static final String[] pkColName = new String[]{
        "PAY_CODE"};

    private static final int[] pkColNum = new int[]{0};

    private static final HashMap fkColName = new HashMap(0);

    static {
        fkColName.put("CF_CARTE", new String[]{
            "PAY_CODE"
        });
        fkColName.put("CF_MESSAGE_DIFFUSION", new String[]{
            "PAY_CODE"
        });
        fkColName.put("CF_OPER_COMMER", new String[]{
            "PAY_CODE"
        });
        fkColName.put("CF_REGROUPEMENT_CLIENTS", new String[]{
            "PAY_CODE"
        });
        fkColName.put("CF_TYPE_CARTE", new String[]{
            "PAY_CODE"
        });
        fkColName.put("DT_CMDE_ACHAT_TETE", new String[]{
            "PAY_CODE"
        });
        fkColName.put("XN_ABO_CLI_TETE", new String[]{
            "PAY_CODE"
        });
        fkColName.put("XN_ABO_CLI_TETE", new String[]{
            "PAY_CODE"
        });
        fkColName.put("XN_ABO_CLI_TETE", new String[]{
            "PAY_CODE"
        });
        fkColName.put("XN_ADR_MAIL", new String[]{
            "PAY_CODE"
        });
        fkColName.put("XN_ART", new String[]{
            "PAY_CODE"
        });
        fkColName.put("XN_ART_FOU", new String[]{
            "PAY_CODE"
        });
        fkColName.put("XN_BL_CLI_TETE", new String[]{
            "PAY_CODE"
        });
        fkColName.put("XN_BL_CLI_TETE", new String[]{
            "PAY_CODE"
        });
        fkColName.put("XN_BL_FOUR_TETE", new String[]{
            "PAY_CODE"
        });
        fkColName.put("XN_BUDGET_VENTE", new String[]{
            "PAY_CODE"
        });
        fkColName.put("XN_CLI", new String[]{
            "PAY_CODE"
        });
        fkColName.put("XN_CLI_LIV", new String[]{
            "PAY_CODE"
        });
        fkColName.put("XN_CMDE_CLI_TETE", new String[]{
            "PAY_CODE"
        });
        fkColName.put("XN_CMDE_CLI_TETE", new String[]{
            "PAY_CODE"
        });
        fkColName.put("XN_CMDE_CLI_TETE", new String[]{
            "PAY_CODE"
        });
        fkColName.put("XN_CMDE_FOUR_TETE", new String[]{
            "PAY_CODE"
        });
        fkColName.put("XN_CMDE_FOUR_TETE", new String[]{
            "PAY_CODE"
        });
        fkColName.put("XN_DEC_DOUANE", new String[]{
            "PAY_CODE"
        });
        fkColName.put("XN_DEPOT", new String[]{
            "PAY_CODE"
        });
        fkColName.put("XN_DEVIS_TETE", new String[]{
            "PAY_CODE"
        });
        fkColName.put("XN_EHF_ACHATS", new String[]{
            "PAY_CODE"
        });
        fkColName.put("XN_EHF_VENTES", new String[]{
            "PAY_CODE"
        });
        fkColName.put("XN_FAC_CLI_TETE", new String[]{
            "PAY_CODE"
        });
        fkColName.put("XN_FAC_CLI_TETE", new String[]{
            "PAY_CODE"
        });
        fkColName.put("XN_FAC_FOUR_TETE", new String[]{
            "PAY_CODE"
        });
        fkColName.put("XN_FOUR", new String[]{
            "PAY_CODE"
        });
        fkColName.put("XN_FOUR", new String[]{
            "PAY_CODE"
        });
        fkColName.put("XN_FOUR", new String[]{
            "PAY_CODE"
        });
        fkColName.put("XN_LOT_TETE", new String[]{
            "PAY_CODE"
        });
        fkColName.put("XN_SOCIETE", new String[]{
            "PAY_CODE"
        });
    }


    private static final HashMap fkColNum = new HashMap(0);

    static {
        fkColNum.put("CF_CARTE", new int[]{
            0
        });
        fkColNum.put("CF_MESSAGE_DIFFUSION", new int[]{
            0
        });
        fkColNum.put("CF_OPER_COMMER", new int[]{
            0
        });
        fkColNum.put("CF_REGROUPEMENT_CLIENTS", new int[]{
            0
        });
        fkColNum.put("CF_TYPE_CARTE", new int[]{
            0
        });
        fkColNum.put("DT_CMDE_ACHAT_TETE", new int[]{
            0
        });
        fkColNum.put("XN_ABO_CLI_TETE", new int[]{
            0
        });
        fkColNum.put("XN_ABO_CLI_TETE", new int[]{
            0
        });
        fkColNum.put("XN_ABO_CLI_TETE", new int[]{
            0
        });
        fkColNum.put("XN_ADR_MAIL", new int[]{
            0
        });
        fkColNum.put("XN_ART", new int[]{
            0
        });
        fkColNum.put("XN_ART_FOU", new int[]{
            0
        });
        fkColNum.put("XN_BL_CLI_TETE", new int[]{
            0
        });
        fkColNum.put("XN_BL_CLI_TETE", new int[]{
            0
        });
        fkColNum.put("XN_BL_FOUR_TETE", new int[]{
            0
        });
        fkColNum.put("XN_BUDGET_VENTE", new int[]{
            0
        });
        fkColNum.put("XN_CLI", new int[]{
            0
        });
        fkColNum.put("XN_CLI_LIV", new int[]{
            0
        });
        fkColNum.put("XN_CMDE_CLI_TETE", new int[]{
            0
        });
        fkColNum.put("XN_CMDE_CLI_TETE", new int[]{
            0
        });
        fkColNum.put("XN_CMDE_CLI_TETE", new int[]{
            0
        });
        fkColNum.put("XN_CMDE_FOUR_TETE", new int[]{
            0
        });
        fkColNum.put("XN_CMDE_FOUR_TETE", new int[]{
            0
        });
        fkColNum.put("XN_DEC_DOUANE", new int[]{
            0
        });
        fkColNum.put("XN_DEPOT", new int[]{
            0
        });
        fkColNum.put("XN_DEVIS_TETE", new int[]{
            0
        });
        fkColNum.put("XN_EHF_ACHATS", new int[]{
            0
        });
        fkColNum.put("XN_EHF_VENTES", new int[]{
            0
        });
        fkColNum.put("XN_FAC_CLI_TETE", new int[]{
            0
        });
        fkColNum.put("XN_FAC_CLI_TETE", new int[]{
            0
        });
        fkColNum.put("XN_FAC_FOUR_TETE", new int[]{
            0
        });
        fkColNum.put("XN_FOUR", new int[]{
            0
        });
        fkColNum.put("XN_FOUR", new int[]{
            0
        });
        fkColNum.put("XN_FOUR", new int[]{
            0
        });
        fkColNum.put("XN_LOT_TETE", new int[]{
            0
        });
        fkColNum.put("XN_SOCIETE", new int[]{
            0
        });
    }

    /**
     * @see IDoDescription.getTableName()
     */
    public String getTableName() {
        return tableName;
    }

    /**
     * @see IDoDescription.getDbColName()
     */
    public String[] getDbColName() {
        return dbColName;
    }

    /**
     * @see IDoDescription.getDbColNum()
     */
    public HashMap getDbColNum() {
        return colBase;
    }

    /**
     * @see IDoDescription.getPkColName()
     */
    public String[] getPkColName() {
        return pkColName;
    }

    /**
     * @see IDoDescription.getPkColNum()
     */
    public int[] getPkColNum() {
        return pkColNum;
    }
    /**
     * @see IDoDescription.getPkColNumInsert()
     */
    /**
     * @see IDoDescription.getFkColName()
     */
    public String[] getFkColName(String tableName) {
        return (String[]) fkColName.get(tableName);
    }

    /**
     * @see IDoDescription.getFkColNum()
     */
    public int[] getFkColNum(String tableName) {
        return (int[]) fkColNum.get(tableName);
    }
}
