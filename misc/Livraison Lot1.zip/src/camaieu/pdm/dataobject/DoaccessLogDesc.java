package camaieu.pdm.dataobject;

import wg4.fwk.dataobject.IDoDescription;

import java.util.HashMap;

/**
 * /* Description de l'objetDoaccessLog correspondant � la table ACCESS_LOG
 */
public class DoaccessLogDesc implements IDoDescription {
    public static final int LOG_FOU_CODE = 0;
    public static final int LOG_DATE = 1;

    public static final String tableName = "ACCESS_LOG";

    /*
     * Liste des noms de colonnes
     */
    public static final String[] dbColName = new String[]{
        "LOG_FOU_CODE", "LOG_DATE"};
    private static final HashMap colBase;

    static {
        colBase = new HashMap(2);
        colBase.put("LOG_FOU_CODE", new Integer(LOG_FOU_CODE));
        colBase.put("LOG_DATE", new Integer(LOG_DATE));
    }

    /*
     * Noms de colonnes de la cl� primaire
     */
    private static final String[] pkColName = new String[]{
    };

    private static final int[] pkColNum = new int[]{};

    private static final HashMap fkColName = new HashMap(0);

    private static final HashMap fkColNum = new HashMap(0);

    /**
     * @see IDoDescription.getTableName()
     */
    public String getTableName() {
        return tableName;
    }

    /**
     * @see IDoDescription.getDbColName()
     */
    public String[] getDbColName() {
        return dbColName;
    }

    /**
     * @see IDoDescription.getDbColNum()
     */
    public HashMap getDbColNum() {
        return colBase;
    }

    /**
     * @see IDoDescription.getPkColName()
     */
    public String[] getPkColName() {
        return pkColName;
    }

    /**
     * @see IDoDescription.getPkColNum()
     */
    public int[] getPkColNum() {
        return pkColNum;
    }
    /**
     * @see IDoDescription.getPkColNumInsert()
     */
    /**
     * @see IDoDescription.getFkColName()
     */
    public String[] getFkColName(String tableName) {
        return (String[]) fkColName.get(tableName);
    }

    /**
     * @see IDoDescription.getFkColNum()
     */
    public int[] getFkColNum(String tableName) {
        return (int[]) fkColNum.get(tableName);
    }
}
