package camaieu.pdm.dataobject;

import wg4.fwk.dataobject.IDoDescription;

import java.util.HashMap;

/**
 * /* Description de l'objetDosuiviProtoMap correspondant � la table SUIVI_PROTO_MAP
 */
public class DosuiviProtoMapDesc implements IDoDescription {
    public static final int SPM_SPT_MODELE_CODE = 0;
    public static final int SPM_NO_PROTO = 1;
    public static final int SPM_COMMENTAIRES = 2;
    public static final int SPM_DT_ENV_COMMENT = 3;
    public static final int SPM_DT_RETOUR_DDE = 4;
    public static final int SPM_DT_RECEP_COMMENT = 5;
    public static final int SPM_DT_ENV_PROTO = 6;
    public static final int SPM_DT_RECEP_PROTO = 7;
    public static final int SPM_DT_REUNION_PROD = 8;
    public static final int SPM_DECISION_OK_MAP = 9;
    public static final int SPM_DT_DECISION_OK_MAP = 10;

    public static final String tableName = "SUIVI_PROTO_MAP";

    /*
     * Liste des noms de colonnes
     */
    public static final String[] dbColName = new String[]{
        "SPM_SPT_MODELE_CODE", "SPM_NO_PROTO", "SPM_COMMENTAIRES", "SPM_DT_ENV_COMMENT", "SPM_DT_RETOUR_DDE", "SPM_DT_RECEP_COMMENT", "SPM_DT_ENV_PROTO", "SPM_DT_RECEP_PROTO", "SPM_DT_REUNION_PROD", "SPM_DECISION_OK_MAP", "SPM_DT_DECISION_OK_MAP"};
    private static final HashMap colBase;

    static {
        colBase = new HashMap(11);
        colBase.put("SPM_SPT_MODELE_CODE", new Integer(SPM_SPT_MODELE_CODE));
        colBase.put("SPM_NO_PROTO", new Integer(SPM_NO_PROTO));
        colBase.put("SPM_COMMENTAIRES", new Integer(SPM_COMMENTAIRES));
        colBase.put("SPM_DT_ENV_COMMENT", new Integer(SPM_DT_ENV_COMMENT));
        colBase.put("SPM_DT_RETOUR_DDE", new Integer(SPM_DT_RETOUR_DDE));
        colBase.put("SPM_DT_RECEP_COMMENT", new Integer(SPM_DT_RECEP_COMMENT));
        colBase.put("SPM_DT_ENV_PROTO", new Integer(SPM_DT_ENV_PROTO));
        colBase.put("SPM_DT_RECEP_PROTO", new Integer(SPM_DT_RECEP_PROTO));
        colBase.put("SPM_DT_REUNION_PROD", new Integer(SPM_DT_REUNION_PROD));
        colBase.put("SPM_DECISION_OK_MAP", new Integer(SPM_DECISION_OK_MAP));
        colBase.put("SPM_DT_DECISION_OK_MAP", new Integer(SPM_DT_DECISION_OK_MAP));
    }

    /*
     * Noms de colonnes de la cl� primaire
     */
    private static final String[] pkColName = new String[]{
        "SPM_SPT_MODELE_CODE", "SPM_NO_PROTO"};

    private static final int[] pkColNum = new int[]{0, 1};

    private static final HashMap fkColName = new HashMap(1);

    static {
        fkColName.put("SUIVI_PROTO_TETE", new String[]{
            "SPM_SPT_MODELE_CODE"
        });
    }


    private static final HashMap fkColNum = new HashMap(1);

    static {
        fkColNum.put("SUIVI_PROTO_TETE", new int[]{
            0
        });
    }

    /**
     * @see IDoDescription.getTableName()
     */
    public String getTableName() {
        return tableName;
    }

    /**
     * @see IDoDescription.getDbColName()
     */
    public String[] getDbColName() {
        return dbColName;
    }

    /**
     * @see IDoDescription.getDbColNum()
     */
    public HashMap getDbColNum() {
        return colBase;
    }

    /**
     * @see IDoDescription.getPkColName()
     */
    public String[] getPkColName() {
        return pkColName;
    }

    /**
     * @see IDoDescription.getPkColNum()
     */
    public int[] getPkColNum() {
        return pkColNum;
    }
    /**
     * @see IDoDescription.getPkColNumInsert()
     */
    /**
     * @see IDoDescription.getFkColName()
     */
    public String[] getFkColName(String tableName) {
        return (String[]) fkColName.get(tableName);
    }

    /**
     * @see IDoDescription.getFkColNum()
     */
    public int[] getFkColNum(String tableName) {
        return (int[]) fkColNum.get(tableName);
    }
}
