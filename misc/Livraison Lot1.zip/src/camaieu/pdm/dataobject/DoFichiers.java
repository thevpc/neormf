package camaieu.pdm.dataobject;

import wg4.fwk.dataobject.DataObject;
import wg4.fwk.dataobject.IDoDescription;
import wg4.fwk.dataobject.ParameterException;
import wg4.fwk.dataobject.SqlArg;
import wg4.fwk.mvc.tool.StrConvertor;

import javax.servlet.http.HttpServletRequest;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.HashSet;

public class DoFichiers implements DataObject {

    private static final IDoDescription description = new DoFichiersDesc();
    private transient int persist = PERSIST_UPDATE_INSERT;
    private transient int[] updCol = new int[6];
    private transient String sql;
    private transient Object[] param;

//tables correspondantes
    private static final String[] tableNames = new String[]{"FICHIERS"};
    //variables correspondant � la table FICHIERS
    private String ficChamp = null;
    private Integer ficVersion = null;
    private Integer ficSptModeleCode = null;
    private String ficExtension = null;
    private byte[] ficFichier = null;
    private Timestamp ficDate = null;

    /**
     * Constructeur utilis� par la m�thode setPropertie
     */
    public DoFichiers() {
    }

    /**
     * Constructeur permettant d'initialiser le type de persistance
     */
    public DoFichiers(int persistTyp) {
        persist = persistTyp;
    }

    /**
     * Constructeur permettant d'initialiser le type de persistance
     */
    public DoFichiers(DoFichiers arg) {
        setFicChamp(arg.ficChamp);
        setFicVersion(arg.ficVersion);
        setFicSptModeleCode(arg.ficSptModeleCode);
        setFicExtension(arg.ficExtension);
        setFicFichier(arg.ficFichier);
        setFicDate(arg.ficDate);
    }

    /**
     * Constructeur utilis� par la m�thode retrieve
     */
    public DoFichiers(String newSql, Object[] newParam) {
        sql = newSql;
        param = newParam;
    }

    public int getPersist() {
        return persist;
    }

    public void setPersist(int newPersist) {
        persist = newPersist;
    }

    public void resetUpdate() {
        Arrays.fill(updCol, -1);
    }

    public Object[] getParam() {
        return param;
    }

    public String getSQL() {
        return sql;
    }

    public HashSet getColNotInsertable() {
        return null;
    }

    public String getFicChamp() {
        return ficChamp;
    }

    public Integer getFicVersion() {
        return ficVersion;
    }

    public Integer getFicSptModeleCode() {
        return ficSptModeleCode;
    }

    public String getFicExtension() {
        return ficExtension;
    }

    public byte[] getFicFichier() {
        return ficFichier;
    }

    public Timestamp getFicDate() {
        return ficDate;
    }

    public void setFicChamp(String newFicChamp) {
        ficChamp = newFicChamp;
    }

    public void setFicVersion(Integer newFicVersion) {
        ficVersion = newFicVersion;
    }

    public void setFicSptModeleCode(Integer newFicSptModeleCode) {
        ficSptModeleCode = newFicSptModeleCode;
    }

    public void setFicExtension(String newFicExtension) {
        ficExtension = newFicExtension;
        if (persist > 0)
            updCol[DoFichiersDesc.FIC_EXTENSION] = 1;
    }

    public void setFicFichier(byte[] newFicFichier) {
        ficFichier = newFicFichier;
        if (persist > 0)
            updCol[DoFichiersDesc.FIC_FICHIER] = 1;
    }

    public void setFicDate(Timestamp newFicDate) {
        ficDate = newFicDate;
        if (persist > 0)
            updCol[DoFichiersDesc.FIC_DATE] = 1;
    }

    public Object get(int numCol) {
        if (numCol == DoFichiersDesc.FIC_CHAMP)
            return ficChamp;
        else if (numCol == DoFichiersDesc.FIC_VERSION)
            return ficVersion;
        else if (numCol == DoFichiersDesc.FIC_SPT_MODELE_CODE)
            return ficSptModeleCode;
        else if (numCol == DoFichiersDesc.FIC_EXTENSION)
            return ficExtension;
        else if (numCol == DoFichiersDesc.FIC_FICHIER)
            return ficFichier;
        else if (numCol == DoFichiersDesc.FIC_DATE)
            return ficDate;
        return null;
    }

    public void set(int numCol, Object value) {
        if (numCol == DoFichiersDesc.FIC_CHAMP) {
            ficChamp = (String) value;
        }
        if (numCol == DoFichiersDesc.FIC_VERSION) {
            ficVersion = (Integer) value;
        }
        if (numCol == DoFichiersDesc.FIC_SPT_MODELE_CODE) {
            ficSptModeleCode = (Integer) value;
        }
        if (numCol == DoFichiersDesc.FIC_EXTENSION) {
            ficExtension = (String) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DoFichiersDesc.FIC_FICHIER) {
            ficFichier = (byte[]) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DoFichiersDesc.FIC_DATE) {
            ficDate = (Timestamp) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
    }

    public DataObject setProperty(SqlArg sqlArg) throws SQLException {
        return setProperty(sqlArg, new DoFichiers());
    }

    private DataObject setProperty(SqlArg sqlArg, DoFichiers djo) throws SQLException {
        ResultSet rs = sqlArg.getResultSet();
        int[] val = sqlArg.getVal();
        if (val[DoFichiersDesc.FIC_CHAMP] != -1) {
            djo.ficChamp = rs.getString(val[DoFichiersDesc.FIC_CHAMP]);
        }
        if (val[DoFichiersDesc.FIC_VERSION] != -1) {
            int temp = rs.getInt(val[DoFichiersDesc.FIC_VERSION]);
            if (!rs.wasNull())
                djo.ficVersion = new Integer(temp);
        }
        if (val[DoFichiersDesc.FIC_SPT_MODELE_CODE] != -1) {
            int temp = rs.getInt(val[DoFichiersDesc.FIC_SPT_MODELE_CODE]);
            if (!rs.wasNull())
                djo.ficSptModeleCode = new Integer(temp);
        }
        if (val[DoFichiersDesc.FIC_EXTENSION] != -1) {
            djo.ficExtension = rs.getString(val[DoFichiersDesc.FIC_EXTENSION]);
        }
        if (val[DoFichiersDesc.FIC_FICHIER] != -1) {
        }
        if (val[DoFichiersDesc.FIC_DATE] != -1) {
            djo.ficDate = rs.getTimestamp(val[DoFichiersDesc.FIC_DATE]);
        }
        return djo;
    }

    public void getProperty(SqlArg sqlArg) throws SQLException {
        PreparedStatement stmt = sqlArg.getStmt();
        int[] val = sqlArg.getVal();
        if (val[DoFichiersDesc.FIC_CHAMP] > 0) {
            stmt.setString(val[DoFichiersDesc.FIC_CHAMP], ficChamp);
        }
        if (val[DoFichiersDesc.FIC_VERSION] > 0) {
            if (ficVersion == null)
                stmt.setNull(val[DoFichiersDesc.FIC_VERSION], 3);
            else
                stmt.setInt(val[DoFichiersDesc.FIC_VERSION], ficVersion.intValue());
        }
        if (val[DoFichiersDesc.FIC_SPT_MODELE_CODE] > 0) {
            if (ficSptModeleCode == null)
                stmt.setNull(val[DoFichiersDesc.FIC_SPT_MODELE_CODE], 3);
            else
                stmt.setInt(val[DoFichiersDesc.FIC_SPT_MODELE_CODE], ficSptModeleCode.intValue());
        }
        if (val[DoFichiersDesc.FIC_EXTENSION] > 0) {
            stmt.setString(val[DoFichiersDesc.FIC_EXTENSION], ficExtension);
        }
        if (val[DoFichiersDesc.FIC_FICHIER] > 0) {
            stmt.setObject(val[DoFichiersDesc.FIC_FICHIER], ficFichier);
        }
        if (val[DoFichiersDesc.FIC_DATE] > 0) {
            stmt.setTimestamp(val[DoFichiersDesc.FIC_DATE], ficDate);
        }
    }

    /**
     * M�thode g�n�r�e automatiquement permettant de remplir un dataobject � partir des valeurs
     * d'une requ�te http.
     * Les noms des param�tres de la requ�te doivent �tre strictement identique aux noms des attributs du DataObject.
     * Cette m�thode peut �tre compl�t�e afin de prendre en compte d'�ventuels param�tres se trouvant en session.
     * Pour une reg�n�ration �ventuelle, faites attention � ne coder qu'entre les tags de d�but et de fin.
     * Date de cr�ation : (25/05/01 08:03:14)
     *
     * @param request javax.servlet.http.HttpServletRequest
     */
    public DataObject[] setParameters(HttpServletRequest request)
            throws ParameterException, java.text.ParseException {
        String[] params = null;
        String localVal = null;
        int size = 0;
        DoFichiers[] result = null;
        params = request.getParameterValues("ficChamp");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoFichiers[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoFichiers();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setFicChamp(localVal);
            }
        }
        params = request.getParameterValues("ficVersion");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoFichiers[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoFichiers();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setFicVersion((Integer) StrConvertor.convert(localVal, Integer.class));
            }
        }
        params = request.getParameterValues("ficSptModeleCode");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoFichiers[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoFichiers();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setFicSptModeleCode((Integer) StrConvertor.convert(localVal, Integer.class));
            }
        }
        params = request.getParameterValues("ficExtension");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoFichiers[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoFichiers();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setFicExtension(localVal);
            }
        }
        params = request.getParameterValues("ficFichier");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoFichiers[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoFichiers();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setFicFichier((byte[]) StrConvertor.convert(localVal, byte[].class));
            }
        }
        params = request.getParameterValues("ficDate");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoFichiers[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoFichiers();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setFicDate((Timestamp) StrConvertor.convert(localVal, Timestamp.class));
            }
        }
        /************************ INSTRUCTIONS DEVELOPPEMENT SPECIFIQUE *******************/
        /********************** FIN INSTRUCTIONS DEVELOPPEMENT SPECIFIQUE *****************/
        return result;
    }

    /*
     * @see DataObject#addChild(DataObject)
     */
    public void addChild(DataObject doChild) {
    }

    /*
     * @see DataObject#getDescription()
     */
    public IDoDescription getDescription() {
        return description;
    }

    /*
     * @see DataObject#getUpdateCol()
     */
    public int[] getUpdateCol() {
        return updCol;
    }

}
