package camaieu.pdm.dataobject;

import camaieu.webform.RecordEditorHelper;

import java.sql.Timestamp;

/**
 * User: taha
 * Date: 21 juil. 2004
 * Time: 09:32:35
 */
public class MergedDoSuivi {
    private DosuiviProtoTete dosuiviProtoTete;
    private DosuiviProtoMap dosuiviProtoMap;
    private DosuiviProtoProd dosuiviProtoProd;
    private DoNodhosProperties doNodhosProperties;
    private Timestamp nearestDate;
    private DoFichiers[] fichiers;
    private RecordEditorHelper recordEditorHelper;

    public MergedDoSuivi(DosuiviProtoTete dosuiviProtoTete, DosuiviProtoMap dosuiviProtoMap, DosuiviProtoProd dosuiviProtoProd) {
        this(dosuiviProtoTete, dosuiviProtoMap, dosuiviProtoProd, null);
    }

    public MergedDoSuivi(DosuiviProtoTete dosuiviProtoTete, DosuiviProtoMap dosuiviProtoMap, DosuiviProtoProd dosuiviProtoProd, DoNodhosProperties doNodhosProperties) {
        this.dosuiviProtoTete = dosuiviProtoTete;
        this.dosuiviProtoMap = dosuiviProtoMap;
        this.dosuiviProtoProd = dosuiviProtoProd;
        this.doNodhosProperties = doNodhosProperties;
    }

    public DosuiviProtoTete getDosuiviProtoTete() {
        return dosuiviProtoTete;
    }

    public void setDosuiviProtoTete(DosuiviProtoTete dosuiviProtoTete) {
        this.dosuiviProtoTete = dosuiviProtoTete;
    }

    public DosuiviProtoMap getDosuiviProtoMap() {
        return dosuiviProtoMap;
    }

    public void setDosuiviProtoMap(DosuiviProtoMap dosuiviProtoMap) {
        this.dosuiviProtoMap = dosuiviProtoMap;
    }

    public DosuiviProtoProd getDosuiviProtoProd() {
        return dosuiviProtoProd;
    }

    public void setDosuiviProtoProd(DosuiviProtoProd dosuiviProtoProd) {
        this.dosuiviProtoProd = dosuiviProtoProd;
    }

    public DoNodhosProperties getDoNodhosProperties() {
        return doNodhosProperties;
    }

    public void setDoNodhosProperties(DoNodhosProperties doNodhosProperties) {
        this.doNodhosProperties = doNodhosProperties;
    }

    public Timestamp getNearestDate() {
        return nearestDate;
    }

    public void setNearestDate(Timestamp nearestDate) {
        this.nearestDate = nearestDate;
    }

    public DoFichiers[] getFichiers() {
        return fichiers;
    }

    public void setFichiers(DoFichiers[] fichiers) {
        this.fichiers = fichiers;
    }

    public RecordEditorHelper getRecordEditorHelper() {
        if (recordEditorHelper == null) {
            recordEditorHelper = new RecordEditorHelper();
        }
        return recordEditorHelper;
    }

    public void setRecordEditorHelper(RecordEditorHelper helper) {
        if (helper != null) {
            recordEditorHelper = helper;
        }
    }

    public static class DoNodhosProperties {
        private Integer catNoCmde;
        private String catTypeCmde;
        private Integer cflCftNoCmde;
        private String faconNegoce;
        private Timestamp cftDtCommande;
        private Timestamp cftDtConfirme;
        private Timestamp catDtPrevLiv;
        private Timestamp cflDtPrevLiv;
        private Timestamp dateDebutProd;
        private Integer delValeur;

        public DoNodhosProperties() {
        }

        public Timestamp getCflDtPrevLiv() {
            return cflDtPrevLiv;
        }

        public void setCflDtPrevLiv(Timestamp cflDtPrevLiv) {
            this.cflDtPrevLiv = cflDtPrevLiv;
        }

        public Timestamp getCatDtPrevLiv() {
            return catDtPrevLiv;
        }

        public void setCatDtPrevLiv(Timestamp catDtPrevLiv) {
            this.catDtPrevLiv = catDtPrevLiv;
        }

        public Integer getCatNoCmde() {
            return catNoCmde;
        }

        public void setCatNoCmde(Integer catNoCmde) {
            this.catNoCmde = catNoCmde;
        }

        public String getCatTypeCmde() {
            return catTypeCmde;
        }

        public void setCatTypeCmde(String catTypeCmde) {
            this.catTypeCmde = catTypeCmde;
        }

        public Integer getCflCftNoCmde() {
            return cflCftNoCmde;
        }

        public void setCflCftNoCmde(Integer cflCftNoCmde) {
            this.cflCftNoCmde = cflCftNoCmde;
        }

        public Timestamp getCftDtConfirme() {
            return cftDtConfirme;
        }

        public void setCftDtConfirme(Timestamp cftDtConfirme) {
            this.cftDtConfirme = cftDtConfirme;
        }

        public String getFaconNegoce() {
            return faconNegoce;
        }

        public void setFaconNegoce(String faconNegoce) {
            this.faconNegoce = faconNegoce;
        }

        public Timestamp getDateDebutProd() {
            return dateDebutProd;
        }

        public void setDateDebutProd(Timestamp dateDebutProd) {
            this.dateDebutProd = dateDebutProd;
        }

        public Integer getDelValeur() {
            return delValeur;
        }

        public void setDelValeur(Integer delValeur) {
            this.delValeur = delValeur;
        }

        public Timestamp getCftDtCommande() {
            return cftDtCommande;
        }

        public void setCftDtCommande(Timestamp cftDtCommande) {
            this.cftDtCommande = cftDtCommande;
        }
    }
}
