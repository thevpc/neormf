package camaieu.pdm.dataobject;



/**
 * <p>Title: PDM</p>
 * <p>Description: Product for Management of Prodection</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: XVision S.A.</p>
 *
 * @author Anouar Boughzala -Aba-
 * @version 1.0
 */


public class MergedDoStatistique {
    private DosuiviProtoTete dosuiviProtoTete;
    private DoStatistique doStatistique;


    /**
     * @param dosuiviProtoTete
     */
    public MergedDoStatistique(DosuiviProtoTete dosuiviProtoTete) {
        this.dosuiviProtoTete = dosuiviProtoTete;
    }

//      /**
//       *
//       * @param dosuiviProtoTete
//       * @param dosuiviProtoMap
//       * @param dosuiviProtoProd
//       */
//      public MergedDoStatistique(DosuiviProtoTete dosuiviProtoTete, DosuiviProtoMap dosuiviProtoMap,DosuiviProtoProd dosuiviProtoProd) {
//        this.dosuiviProtoTete = dosuiviProtoTete;
//        this.dosuiviProtoMap = dosuiviProtoMap;
//        this.dosuiviProtoProd = dosuiviProtoProd;
//    }
    /**
     * @param dosuiviProtoTete
     * @param doStatistique
     */
    public MergedDoStatistique(DosuiviProtoTete dosuiviProtoTete, DoStatistique doStatistique) {
        this.dosuiviProtoTete = dosuiviProtoTete;
        this.doStatistique = doStatistique;
    }

    public DosuiviProtoTete getDosuiviProtoTete() {
        return dosuiviProtoTete;
    }

    public void setDosuiviProtoTete(DosuiviProtoTete dosuiviProtoTete) {
        this.dosuiviProtoTete = dosuiviProtoTete;
    }


    public DoStatistique getDoStatistique() {
        return doStatistique;
    }

    public void setDoStatistique(DoStatistique doStatistique) {
        this.doStatistique = doStatistique;
    }

    /**
     * <p>Title: PDM</p>
     * <p>Description: Product for Management of Prodection</p>
     * <p>Copyright: Copyright (c) 2004</p>
     * <p>Company: XVision S.A.</p>
     *
     * @author Anouar Boughzala -Aba-
     * @version 1.0
     */
    public static class DoStatistique {
        public DoStatistique() {
        }

        private Integer totalModels;
        private Integer refusedModels;
        private Integer remainTovalidate;
        private Integer oKMap;
        private Integer oKProd;
        private Integer objective;
        private Integer advancement;
        String country;

        //    setter
        public void setTotalModels(Integer totalModels) {
            this.totalModels = totalModels;
        }

        public void setRefusedModels(Integer refusedModels) {
            this.refusedModels = refusedModels;
        }

        public void setRemainTovalidate(Integer remainTovalidate) {
            this.remainTovalidate = remainTovalidate;
        }

        public void setOKMap(Integer oKMap) {
            this.oKMap = oKMap;
        }

        public void setOKProd(Integer oKProd) {
            this.oKProd = oKProd;
        }

        public void setObjective(Integer objective) {
            this.objective = objective;
        }

        public void setAdvancement(Integer advancement) {
            this.advancement = advancement;
        }

        public void setCountry(String country) {
            this.country = country;
        }

        //geter
        public Integer getTotalModels() {
            return totalModels;
        }

        public Integer getRefusedModels() {
            return refusedModels;
        }

        public Integer getRemainTovalidate() {
            return remainTovalidate;
        }

        public Integer getOKMap() {
            return oKMap;
        }

        public Integer getOKProd() {
            return oKProd;
        }

        public Integer getObjective() {
            return objective;
        }

        public Integer getAdvancement() {
            return advancement;
        }

        public String getCountry() {
            return country;
        }


    }
}

