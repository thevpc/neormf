package camaieu.pdm.dataobject;

import wg4.fwk.dataobject.DataObject;
import wg4.fwk.dataobject.IDoDescription;
import wg4.fwk.dataobject.ParameterException;
import wg4.fwk.dataobject.SqlArg;
import wg4.fwk.mvc.tool.StrConvertor;

import javax.servlet.http.HttpServletRequest;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.HashSet;

public class DoAlertes implements DataObject {

    private static final IDoDescription description = new DoAlertesDesc();
    private transient int persist = PERSIST_UPDATE_INSERT;
    private transient int[] updCol = new int[7];
    private transient String sql;
    private transient Object[] param;

//tables correspondantes
    private static final String[] tableNames = new String[]{"ALERTES"};
    //variables correspondant � la table ALERTES
    private Integer aleSptModeleCode = null;
    private String aleOrigine = null;
    private String aleChamp = null;
    private String aleDestinataire = null;
    private String aleEnvoyee = null;
    private String aleAncienne = null;
    private Timestamp aleDate = null;

    /**
     * Constructeur utilis� par la m�thode setPropertie
     */
    public DoAlertes() {
    }

    /**
     * Constructeur permettant d'initialiser le type de persistance
     */
    public DoAlertes(int persistTyp) {
        persist = persistTyp;
    }

    /**
     * Constructeur permettant d'initialiser le type de persistance
     */
    public DoAlertes(DoAlertes arg) {
        setAleSptModeleCode(arg.aleSptModeleCode);
        setAleOrigine(arg.aleOrigine);
        setAleChamp(arg.aleChamp);
        setAleDestinataire(arg.aleDestinataire);
        setAleEnvoyee(arg.aleEnvoyee);
        setAleAncienne(arg.aleAncienne);
        setAleDate(arg.aleDate);
    }

    /**
     * Constructeur utilis� par la m�thode retrieve
     */
    public DoAlertes(String newSql, Object[] newParam) {
        sql = newSql;
        param = newParam;
    }

    public int getPersist() {
        return persist;
    }

    public void setPersist(int newPersist) {
        persist = newPersist;
    }

    public void resetUpdate() {
        Arrays.fill(updCol, -1);
    }

    public Object[] getParam() {
        return param;
    }

    public String getSQL() {
        return sql;
    }

    public HashSet getColNotInsertable() {
        return null;
    }

    public Integer getAleSptModeleCode() {
        return aleSptModeleCode;
    }

    public String getAleOrigine() {
        return aleOrigine;
    }

    public String getAleChamp() {
        return aleChamp;
    }

    public String getAleDestinataire() {
        return aleDestinataire;
    }

    public String getAleEnvoyee() {
        return aleEnvoyee;
    }

    public String getAleAncienne() {
        return aleAncienne;
    }

    public Timestamp getAleDate() {
        return aleDate;
    }

    public void setAleSptModeleCode(Integer newAleSptModeleCode) {
        aleSptModeleCode = newAleSptModeleCode;
        if (persist > 0)
            updCol[DoAlertesDesc.ALE_SPT_MODELE_CODE] = 1;
    }

    public void setAleOrigine(String newAleOrigine) {
        aleOrigine = newAleOrigine;
        if (persist > 0)
            updCol[DoAlertesDesc.ALE_ORIGINE] = 1;
    }

    public void setAleChamp(String newAleChamp) {
        aleChamp = newAleChamp;
        if (persist > 0)
            updCol[DoAlertesDesc.ALE_CHAMP] = 1;
    }

    public void setAleDestinataire(String newAleDestinataire) {
        aleDestinataire = newAleDestinataire;
        if (persist > 0)
            updCol[DoAlertesDesc.ALE_DESTINATAIRE] = 1;
    }

    public void setAleEnvoyee(String newAleEnvoyee) {
        aleEnvoyee = newAleEnvoyee;
        if (persist > 0)
            updCol[DoAlertesDesc.ALE_ENVOYEE] = 1;
    }

    public void setAleAncienne(String newAleAncienne) {
        aleAncienne = newAleAncienne;
        if (persist > 0)
            updCol[DoAlertesDesc.ALE_ANCIENNE] = 1;
    }

    public void setAleDate(Timestamp newAleDate) {
        aleDate = newAleDate;
        if (persist > 0)
            updCol[DoAlertesDesc.ALE_DATE] = 1;
    }

    public Object get(int numCol) {
        if (numCol == DoAlertesDesc.ALE_SPT_MODELE_CODE)
            return aleSptModeleCode;
        else if (numCol == DoAlertesDesc.ALE_ORIGINE)
            return aleOrigine;
        else if (numCol == DoAlertesDesc.ALE_CHAMP)
            return aleChamp;
        else if (numCol == DoAlertesDesc.ALE_DESTINATAIRE)
            return aleDestinataire;
        else if (numCol == DoAlertesDesc.ALE_ENVOYEE)
            return aleEnvoyee;
        else if (numCol == DoAlertesDesc.ALE_ANCIENNE)
            return aleAncienne;
        else if (numCol == DoAlertesDesc.ALE_DATE)
            return aleDate;
        return null;
    }

    public void set(int numCol, Object value) {
        if (numCol == DoAlertesDesc.ALE_SPT_MODELE_CODE) {
            aleSptModeleCode = (Integer) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DoAlertesDesc.ALE_ORIGINE) {
            aleOrigine = (String) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DoAlertesDesc.ALE_CHAMP) {
            aleChamp = (String) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DoAlertesDesc.ALE_DESTINATAIRE) {
            aleDestinataire = (String) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DoAlertesDesc.ALE_ENVOYEE) {
            aleEnvoyee = (String) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DoAlertesDesc.ALE_ANCIENNE) {
            aleAncienne = (String) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DoAlertesDesc.ALE_DATE) {
            aleDate = (Timestamp) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
    }

    public DataObject setProperty(SqlArg sqlArg) throws SQLException {
        return setProperty(sqlArg, new DoAlertes());
    }

    private DataObject setProperty(SqlArg sqlArg, DoAlertes djo) throws SQLException {
        ResultSet rs = sqlArg.getResultSet();
        int[] val = sqlArg.getVal();
        if (val[DoAlertesDesc.ALE_SPT_MODELE_CODE] != -1) {
            int temp = rs.getInt(val[DoAlertesDesc.ALE_SPT_MODELE_CODE]);
            if (!rs.wasNull())
                djo.aleSptModeleCode = new Integer(temp);
        }
        if (val[DoAlertesDesc.ALE_ORIGINE] != -1) {
            djo.aleOrigine = rs.getString(val[DoAlertesDesc.ALE_ORIGINE]);
        }
        if (val[DoAlertesDesc.ALE_CHAMP] != -1) {
            djo.aleChamp = rs.getString(val[DoAlertesDesc.ALE_CHAMP]);
        }
        if (val[DoAlertesDesc.ALE_DESTINATAIRE] != -1) {
            djo.aleDestinataire = rs.getString(val[DoAlertesDesc.ALE_DESTINATAIRE]);
        }
        if (val[DoAlertesDesc.ALE_ENVOYEE] != -1) {
            djo.aleEnvoyee = rs.getString(val[DoAlertesDesc.ALE_ENVOYEE]);
        }
        if (val[DoAlertesDesc.ALE_ANCIENNE] != -1) {
            djo.aleAncienne = rs.getString(val[DoAlertesDesc.ALE_ANCIENNE]);
        }
        if (val[DoAlertesDesc.ALE_DATE] != -1) {
            djo.aleDate = rs.getTimestamp(val[DoAlertesDesc.ALE_DATE]);
        }
        return djo;
    }

    public void getProperty(SqlArg sqlArg) throws SQLException {
        PreparedStatement stmt = sqlArg.getStmt();
        int[] val = sqlArg.getVal();
        if (val[DoAlertesDesc.ALE_SPT_MODELE_CODE] > 0) {
            if (aleSptModeleCode == null)
                stmt.setNull(val[DoAlertesDesc.ALE_SPT_MODELE_CODE], 3);
            else
                stmt.setInt(val[DoAlertesDesc.ALE_SPT_MODELE_CODE], aleSptModeleCode.intValue());
        }
        if (val[DoAlertesDesc.ALE_ORIGINE] > 0) {
            stmt.setString(val[DoAlertesDesc.ALE_ORIGINE], aleOrigine);
        }
        if (val[DoAlertesDesc.ALE_CHAMP] > 0) {
            stmt.setString(val[DoAlertesDesc.ALE_CHAMP], aleChamp);
        }
        if (val[DoAlertesDesc.ALE_DESTINATAIRE] > 0) {
            stmt.setString(val[DoAlertesDesc.ALE_DESTINATAIRE], aleDestinataire);
        }
        if (val[DoAlertesDesc.ALE_ENVOYEE] > 0) {
            stmt.setString(val[DoAlertesDesc.ALE_ENVOYEE], aleEnvoyee);
        }
        if (val[DoAlertesDesc.ALE_ANCIENNE] > 0) {
            stmt.setString(val[DoAlertesDesc.ALE_ANCIENNE], aleAncienne);
        }
        if (val[DoAlertesDesc.ALE_DATE] > 0) {
            stmt.setTimestamp(val[DoAlertesDesc.ALE_DATE], aleDate);
        }
    }

    /**
     * M�thode g�n�r�e automatiquement permettant de remplir un dataobject � partir des valeurs
     * d'une requ�te http.
     * Les noms des param�tres de la requ�te doivent �tre strictement identique aux noms des attributs du DataObject.
     * Cette m�thode peut �tre compl�t�e afin de prendre en compte d'�ventuels param�tres se trouvant en session.
     * Pour une reg�n�ration �ventuelle, faites attention � ne coder qu'entre les tags de d�but et de fin.
     * Date de cr�ation : (25/05/01 08:03:14)
     *
     * @param request javax.servlet.http.HttpServletRequest
     */
    public DataObject[] setParameters(HttpServletRequest request)
            throws ParameterException, java.text.ParseException {
        String[] params = null;
        String localVal = null;
        int size = 0;
        DoAlertes[] result = null;
        params = request.getParameterValues("aleSptModeleCode");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoAlertes[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoAlertes();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setAleSptModeleCode((Integer) StrConvertor.convert(localVal, Integer.class));
            }
        }
        params = request.getParameterValues("aleOrigine");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoAlertes[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoAlertes();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setAleOrigine(localVal);
            }
        }
        params = request.getParameterValues("aleChamp");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoAlertes[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoAlertes();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setAleChamp(localVal);
            }
        }
        params = request.getParameterValues("aleDestinataire");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoAlertes[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoAlertes();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setAleDestinataire(localVal);
            }
        }
        params = request.getParameterValues("aleEnvoyee");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoAlertes[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoAlertes();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setAleEnvoyee(localVal);
            }
        }
        params = request.getParameterValues("aleAncienne");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoAlertes[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoAlertes();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setAleAncienne(localVal);
            }
        }
        params = request.getParameterValues("aleDate");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoAlertes[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoAlertes();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setAleDate((Timestamp) StrConvertor.convert(localVal, Timestamp.class));
            }
        }
        /************************ INSTRUCTIONS DEVELOPPEMENT SPECIFIQUE *******************/
        /********************** FIN INSTRUCTIONS DEVELOPPEMENT SPECIFIQUE *****************/
        return result;
    }

    /*
     * @see DataObject#addChild(DataObject)
     */
    public void addChild(DataObject doChild) {
    }

    /*
     * @see DataObject#getDescription()
     */
    public IDoDescription getDescription() {
        return description;
    }

    /*
     * @see DataObject#getUpdateCol()
     */
    public int[] getUpdateCol() {
        return updCol;
    }

}
