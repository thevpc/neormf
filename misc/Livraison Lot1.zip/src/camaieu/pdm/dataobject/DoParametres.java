package camaieu.pdm.dataobject;

import wg4.fwk.dataobject.DataObject;
import wg4.fwk.dataobject.IDoDescription;
import wg4.fwk.dataobject.ParameterException;
import wg4.fwk.dataobject.SqlArg;

import javax.servlet.http.HttpServletRequest;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.HashSet;

public class DoParametres implements DataObject {

    private static final IDoDescription description = new DoParametresDesc();
    private transient int persist = PERSIST_UPDATE_INSERT;
    private transient int[] updCol = new int[5];
    private transient String sql;
    private transient Object[] param;

//tables correspondantes
    private static final String[] tableNames = new String[]{"PARAMETRES"};
    //variables correspondant � la table PARAMETRES
    private String parNomChamp = null;
    private String parRolCode = null;
    private String parFaaCode = null;
    private String parModification = null;
    private String parVisible = null;

    /**
     * Constructeur utilis� par la m�thode setPropertie
     */
    public DoParametres() {
    }

    /**
     * Constructeur permettant d'initialiser le type de persistance
     */
    public DoParametres(int persistTyp) {
        persist = persistTyp;
    }

    /**
     * Constructeur permettant d'initialiser le type de persistance
     */
    public DoParametres(DoParametres arg) {
        setParNomChamp(arg.parNomChamp);
        setParRolCode(arg.parRolCode);
        setParFaaCode(arg.parFaaCode);
        setParModification(arg.parModification);
        setParVisible(arg.parVisible);
    }

    /**
     * Constructeur utilis� par la m�thode retrieve
     */
    public DoParametres(String newSql, Object[] newParam) {
        sql = newSql;
        param = newParam;
    }

    public int getPersist() {
        return persist;
    }

    public void setPersist(int newPersist) {
        persist = newPersist;
    }

    public void resetUpdate() {
        Arrays.fill(updCol, -1);
    }

    public Object[] getParam() {
        return param;
    }

    public String getSQL() {
        return sql;
    }

    public HashSet getColNotInsertable() {
        return null;
    }

    public String getParNomChamp() {
        return parNomChamp;
    }

    public String getParRolCode() {
        return parRolCode;
    }

    public String getParFaaCode() {
        return parFaaCode;
    }

    public String getParModification() {
        return parModification;
    }

    public String getParVisible() {
        return parVisible;
    }

    public void setParNomChamp(String newParNomChamp) {
        parNomChamp = newParNomChamp;
    }

    public void setParRolCode(String newParRolCode) {
        parRolCode = newParRolCode;
    }

    public void setParFaaCode(String newParFaaCode) {
        parFaaCode = newParFaaCode;
    }

    public void setParModification(String newParModification) {
        parModification = newParModification;
        if (persist > 0)
            updCol[DoParametresDesc.PAR_MODIFICATION] = 1;
    }

    public void setParVisible(String newParVisible) {
        parVisible = newParVisible;
        if (persist > 0)
            updCol[DoParametresDesc.PAR_VISIBLE] = 1;
    }

    public Object get(int numCol) {
        if (numCol == DoParametresDesc.PAR_NOM_CHAMP)
            return parNomChamp;
        else if (numCol == DoParametresDesc.PAR_ROL_CODE)
            return parRolCode;
        else if (numCol == DoParametresDesc.PAR_FAA_CODE)
            return parFaaCode;
        else if (numCol == DoParametresDesc.PAR_MODIFICATION)
            return parModification;
        else if (numCol == DoParametresDesc.PAR_VISIBLE)
            return parVisible;
        return null;
    }

    public void set(int numCol, Object value) {
        if (numCol == DoParametresDesc.PAR_NOM_CHAMP) {
            parNomChamp = (String) value;
        }
        if (numCol == DoParametresDesc.PAR_ROL_CODE) {
            parRolCode = (String) value;
        }
        if (numCol == DoParametresDesc.PAR_FAA_CODE) {
            parFaaCode = (String) value;
        }
        if (numCol == DoParametresDesc.PAR_MODIFICATION) {
            parModification = (String) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DoParametresDesc.PAR_VISIBLE) {
            parVisible = (String) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
    }

    public DataObject setProperty(SqlArg sqlArg) throws SQLException {
        return setProperty(sqlArg, new DoParametres());
    }

    private DataObject setProperty(SqlArg sqlArg, DoParametres djo) throws SQLException {
        ResultSet rs = sqlArg.getResultSet();
        int[] val = sqlArg.getVal();
        if (val[DoParametresDesc.PAR_NOM_CHAMP] != -1) {
            djo.parNomChamp = rs.getString(val[DoParametresDesc.PAR_NOM_CHAMP]);
        }
        if (val[DoParametresDesc.PAR_ROL_CODE] != -1) {
            djo.parRolCode = rs.getString(val[DoParametresDesc.PAR_ROL_CODE]);
        }
        if (val[DoParametresDesc.PAR_FAA_CODE] != -1) {
            djo.parFaaCode = rs.getString(val[DoParametresDesc.PAR_FAA_CODE]);
        }
        if (val[DoParametresDesc.PAR_MODIFICATION] != -1) {
            djo.parModification = rs.getString(val[DoParametresDesc.PAR_MODIFICATION]);
        }
        if (val[DoParametresDesc.PAR_VISIBLE] != -1) {
            djo.parVisible = rs.getString(val[DoParametresDesc.PAR_VISIBLE]);
        }
        return djo;
    }

    public void getProperty(SqlArg sqlArg) throws SQLException {
        PreparedStatement stmt = sqlArg.getStmt();
        int[] val = sqlArg.getVal();
        if (val[DoParametresDesc.PAR_NOM_CHAMP] > 0) {
            stmt.setString(val[DoParametresDesc.PAR_NOM_CHAMP], parNomChamp);
        }
        if (val[DoParametresDesc.PAR_ROL_CODE] > 0) {
            stmt.setString(val[DoParametresDesc.PAR_ROL_CODE], parRolCode);
        }
        if (val[DoParametresDesc.PAR_FAA_CODE] > 0) {
            stmt.setString(val[DoParametresDesc.PAR_FAA_CODE], parFaaCode);
        }
        if (val[DoParametresDesc.PAR_MODIFICATION] > 0) {
            stmt.setString(val[DoParametresDesc.PAR_MODIFICATION], parModification);
        }
        if (val[DoParametresDesc.PAR_VISIBLE] > 0) {
            stmt.setString(val[DoParametresDesc.PAR_VISIBLE], parVisible);
        }
    }

    /**
     * M�thode g�n�r�e automatiquement permettant de remplir un dataobject � partir des valeurs
     * d'une requ�te http.
     * Les noms des param�tres de la requ�te doivent �tre strictement identique aux noms des attributs du DataObject.
     * Cette m�thode peut �tre compl�t�e afin de prendre en compte d'�ventuels param�tres se trouvant en session.
     * Pour une reg�n�ration �ventuelle, faites attention � ne coder qu'entre les tags de d�but et de fin.
     * Date de cr�ation : (25/05/01 08:03:14)
     *
     * @param request javax.servlet.http.HttpServletRequest
     */
    public DataObject[] setParameters(HttpServletRequest request)
            throws ParameterException, java.text.ParseException {
        String[] params = null;
        String localVal = null;
        int size = 0;
        DoParametres[] result = null;
        params = request.getParameterValues("parNomChamp");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoParametres[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoParametres();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setParNomChamp(localVal);
            }
        }
        params = request.getParameterValues("parRolCode");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoParametres[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoParametres();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setParRolCode(localVal);
            }
        }
        params = request.getParameterValues("parFaaCode");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoParametres[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoParametres();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setParFaaCode(localVal);
            }
        }
        params = request.getParameterValues("parModification");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoParametres[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoParametres();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setParModification(localVal);
            }
        }
        params = request.getParameterValues("parVisible");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoParametres[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoParametres();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setParVisible(localVal);
            }
        }
        /************************ INSTRUCTIONS DEVELOPPEMENT SPECIFIQUE *******************/
        /********************** FIN INSTRUCTIONS DEVELOPPEMENT SPECIFIQUE *****************/
        return result;
    }

    /*
     * @see DataObject#addChild(DataObject)
     */
    public void addChild(DataObject doChild) {
    }

    /*
     * @see DataObject#getDescription()
     */
    public IDoDescription getDescription() {
        return description;
    }

    /*
     * @see DataObject#getUpdateCol()
     */
    public int[] getUpdateCol() {
        return updCol;
    }

}
