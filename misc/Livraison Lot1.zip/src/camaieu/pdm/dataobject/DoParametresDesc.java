package camaieu.pdm.dataobject;

import wg4.fwk.dataobject.IDoDescription;

import java.util.HashMap;

/**
 * /* Description de l'objetDoParametres correspondant � la table PARAMETRES
 */
public class DoParametresDesc implements IDoDescription {
    public static final int PAR_NOM_CHAMP = 0;
    public static final int PAR_ROL_CODE = 1;
    public static final int PAR_FAA_CODE = 2;
    public static final int PAR_MODIFICATION = 3;
    public static final int PAR_VISIBLE = 4;

    public static final String tableName = "PARAMETRES";

    /*
     * Liste des noms de colonnes
     */
    public static final String[] dbColName = new String[]{
        "PAR_NOM_CHAMP", "PAR_ROL_CODE", "PAR_FAA_CODE", "PAR_MODIFICATION", "PAR_VISIBLE"};
    private static final HashMap colBase;

    static {
        colBase = new HashMap(5);
        colBase.put("PAR_NOM_CHAMP", new Integer(PAR_NOM_CHAMP));
        colBase.put("PAR_ROL_CODE", new Integer(PAR_ROL_CODE));
        colBase.put("PAR_FAA_CODE", new Integer(PAR_FAA_CODE));
        colBase.put("PAR_MODIFICATION", new Integer(PAR_MODIFICATION));
        colBase.put("PAR_VISIBLE", new Integer(PAR_VISIBLE));
    }

    /*
     * Noms de colonnes de la cl� primaire
     */
    private static final String[] pkColName = new String[]{
        "PAR_ROL_CODE", "PAR_NOM_CHAMP", "PAR_FAA_CODE"};

    private static final int[] pkColNum = new int[]{1, 0, 2};

    private static final HashMap fkColName = new HashMap(0);

    private static final HashMap fkColNum = new HashMap(0);

    /**
     * @see IDoDescription.getTableName()
     */
    public String getTableName() {
        return tableName;
    }

    /**
     * @see IDoDescription.getDbColName()
     */
    public String[] getDbColName() {
        return dbColName;
    }

    /**
     * @see IDoDescription.getDbColNum()
     */
    public HashMap getDbColNum() {
        return colBase;
    }

    /**
     * @see IDoDescription.getPkColName()
     */
    public String[] getPkColName() {
        return pkColName;
    }

    /**
     * @see IDoDescription.getPkColNum()
     */
    public int[] getPkColNum() {
        return pkColNum;
    }
    /**
     * @see IDoDescription.getPkColNumInsert()
     */
    /**
     * @see IDoDescription.getFkColName()
     */
    public String[] getFkColName(String tableName) {
        return (String[]) fkColName.get(tableName);
    }

    /**
     * @see IDoDescription.getFkColNum()
     */
    public int[] getFkColNum(String tableName) {
        return (int[]) fkColNum.get(tableName);
    }
}
