package camaieu.pdm.dataobject;

import wg4.fwk.dataobject.IDoDescription;

import java.util.HashMap;

/**
 * /* Description de l'objetDoutilisateurFamille correspondant � la table UTILISATEUR_FAMILLE
 */
public class DoutilisateurFamilleDesc implements IDoDescription {
    public static final int UF_UI_UTI_CODE = 0;
    public static final int UF_FAA_CODE = 1;

    public static final String tableName = "UTILISATEUR_FAMILLE";

    /*
     * Liste des noms de colonnes
     */
    public static final String[] dbColName = new String[]{
        "UF_UI_UTI_CODE", "UF_FAA_CODE"};
    private static final HashMap colBase;

    static {
        colBase = new HashMap(2);
        colBase.put("UF_UI_UTI_CODE", new Integer(UF_UI_UTI_CODE));
        colBase.put("UF_FAA_CODE", new Integer(UF_FAA_CODE));
    }

    /*
     * Noms de colonnes de la cl� primaire
     */
    private static final String[] pkColName = new String[]{
        "UF_UI_UTI_CODE", "UF_FAA_CODE"};

    private static final int[] pkColNum = new int[]{0, 1};

    private static final HashMap fkColName = new HashMap(1);

    static {
        fkColName.put("UTILISATEUR_INTERNE", new String[]{
            "UF_UI_UTI_CODE"
        });
    }


    private static final HashMap fkColNum = new HashMap(1);

    static {
        fkColNum.put("UTILISATEUR_INTERNE", new int[]{
            0
        });
    }

    /**
     * @see IDoDescription.getTableName()
     */
    public String getTableName() {
        return tableName;
    }

    /**
     * @see IDoDescription.getDbColName()
     */
    public String[] getDbColName() {
        return dbColName;
    }

    /**
     * @see IDoDescription.getDbColNum()
     */
    public HashMap getDbColNum() {
        return colBase;
    }

    /**
     * @see IDoDescription.getPkColName()
     */
    public String[] getPkColName() {
        return pkColName;
    }

    /**
     * @see IDoDescription.getPkColNum()
     */
    public int[] getPkColNum() {
        return pkColNum;
    }
    /**
     * @see IDoDescription.getPkColNumInsert()
     */
    /**
     * @see IDoDescription.getFkColName()
     */
    public String[] getFkColName(String tableName) {
        return (String[]) fkColName.get(tableName);
    }

    /**
     * @see IDoDescription.getFkColNum()
     */
    public int[] getFkColNum(String tableName) {
        return (int[]) fkColNum.get(tableName);
    }
}
