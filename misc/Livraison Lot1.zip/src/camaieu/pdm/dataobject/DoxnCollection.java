package camaieu.pdm.dataobject;

import wg4.fwk.dataobject.DataObject;
import wg4.fwk.dataobject.IDoDescription;
import wg4.fwk.dataobject.ParameterException;
import wg4.fwk.dataobject.SqlArg;
import wg4.fwk.mvc.tool.StrConvertor;

import javax.servlet.http.HttpServletRequest;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.HashSet;

public class DoxnCollection implements DataObject {

    private static final IDoDescription description = new DoxnCollectionDesc();
    private transient int persist = PERSIST_UPDATE_INSERT;
    private transient int[] updCol = new int[11];
    private transient String sql;
    private transient Object[] param;

//tables correspondantes
    private static final String[] tableNames = new String[]{"XN_COLLECTION"};
    //variables correspondant � la table XN_COLLECTION
    private String cltCode = null;
    private String cltLib = null;
    private Timestamp cltDtDeb = null;
    private Timestamp cltDtFin = null;
    private String cltSaiCode = null;
    private String cltAn = null;
    private Timestamp cltDtCreat = null;
    private Timestamp cltDtMaj = null;
    private String cltUtilMaj = null;
    private Integer xtxId = null;
    private String zStatus = null;

    /**
     * Constructeur utilis� par la m�thode setPropertie
     */
    public DoxnCollection() {
    }

    /**
     * Constructeur permettant d'initialiser le type de persistance
     */
    public DoxnCollection(int persistTyp) {
        persist = persistTyp;
    }

    /**
     * Constructeur permettant d'initialiser le type de persistance
     */
    public DoxnCollection(DoxnCollection arg) {
        setCltCode(arg.cltCode);
        setCltLib(arg.cltLib);
        setCltDtDeb(arg.cltDtDeb);
        setCltDtFin(arg.cltDtFin);
        setCltSaiCode(arg.cltSaiCode);
        setCltAn(arg.cltAn);
        setCltDtCreat(arg.cltDtCreat);
        setCltDtMaj(arg.cltDtMaj);
        setCltUtilMaj(arg.cltUtilMaj);
        setXtxId(arg.xtxId);
        setZStatus(arg.zStatus);
    }

    /**
     * Constructeur utilis� par la m�thode retrieve
     */
    public DoxnCollection(String newSql, Object[] newParam) {
        sql = newSql;
        param = newParam;
    }

    public int getPersist() {
        return persist;
    }

    public void setPersist(int newPersist) {
        persist = newPersist;
    }

    public void resetUpdate() {
        Arrays.fill(updCol, -1);
    }

    public Object[] getParam() {
        return param;
    }

    public String getSQL() {
        return sql;
    }

    public HashSet getColNotInsertable() {
        return null;
    }

    public String getCltCode() {
        return cltCode;
    }

    public String getCltLib() {
        return cltLib;
    }

    public Timestamp getCltDtDeb() {
        return cltDtDeb;
    }

    public Timestamp getCltDtFin() {
        return cltDtFin;
    }

    public String getCltSaiCode() {
        return cltSaiCode;
    }

    public String getCltAn() {
        return cltAn;
    }

    public Timestamp getCltDtCreat() {
        return cltDtCreat;
    }

    public Timestamp getCltDtMaj() {
        return cltDtMaj;
    }

    public String getCltUtilMaj() {
        return cltUtilMaj;
    }

    public Integer getXtxId() {
        return xtxId;
    }

    public String getZStatus() {
        return zStatus;
    }

    public void setCltCode(String newCltCode) {
        cltCode = newCltCode;
    }

    public void setCltLib(String newCltLib) {
        cltLib = newCltLib;
        if (persist > 0)
            updCol[DoxnCollectionDesc.CLT_LIB] = 1;
    }

    public void setCltDtDeb(Timestamp newCltDtDeb) {
        cltDtDeb = newCltDtDeb;
        if (persist > 0)
            updCol[DoxnCollectionDesc.CLT_DT_DEB] = 1;
    }

    public void setCltDtFin(Timestamp newCltDtFin) {
        cltDtFin = newCltDtFin;
        if (persist > 0)
            updCol[DoxnCollectionDesc.CLT_DT_FIN] = 1;
    }

    public void setCltSaiCode(String newCltSaiCode) {
        cltSaiCode = newCltSaiCode;
    }

    public void setCltAn(String newCltAn) {
        cltAn = newCltAn;
    }

    public void setCltDtCreat(Timestamp newCltDtCreat) {
        cltDtCreat = newCltDtCreat;
        if (persist > 0)
            updCol[DoxnCollectionDesc.CLT_DT_CREAT] = 1;
    }

    public void setCltDtMaj(Timestamp newCltDtMaj) {
        cltDtMaj = newCltDtMaj;
        if (persist > 0)
            updCol[DoxnCollectionDesc.CLT_DT_MAJ] = 1;
    }

    public void setCltUtilMaj(String newCltUtilMaj) {
        cltUtilMaj = newCltUtilMaj;
        if (persist > 0)
            updCol[DoxnCollectionDesc.CLT_UTIL_MAJ] = 1;
    }

    public void setXtxId(Integer newXtxId) {
        xtxId = newXtxId;
        if (persist > 0)
            updCol[DoxnCollectionDesc.XTX_ID] = 1;
    }

    public void setZStatus(String newZStatus) {
        zStatus = newZStatus;
        if (persist > 0)
            updCol[DoxnCollectionDesc.Z_STATUS] = 1;
    }

    public Object get(int numCol) {
        if (numCol == DoxnCollectionDesc.CLT_CODE)
            return cltCode;
        else if (numCol == DoxnCollectionDesc.CLT_LIB)
            return cltLib;
        else if (numCol == DoxnCollectionDesc.CLT_DT_DEB)
            return cltDtDeb;
        else if (numCol == DoxnCollectionDesc.CLT_DT_FIN)
            return cltDtFin;
        else if (numCol == DoxnCollectionDesc.CLT_SAI_CODE)
            return cltSaiCode;
        else if (numCol == DoxnCollectionDesc.CLT_AN)
            return cltAn;
        else if (numCol == DoxnCollectionDesc.CLT_DT_CREAT)
            return cltDtCreat;
        else if (numCol == DoxnCollectionDesc.CLT_DT_MAJ)
            return cltDtMaj;
        else if (numCol == DoxnCollectionDesc.CLT_UTIL_MAJ)
            return cltUtilMaj;
        else if (numCol == DoxnCollectionDesc.XTX_ID)
            return xtxId;
        else if (numCol == DoxnCollectionDesc.Z_STATUS)
            return zStatus;
        return null;
    }

    public void set(int numCol, Object value) {
        if (numCol == DoxnCollectionDesc.CLT_CODE) {
            cltCode = (String) value;
        }
        if (numCol == DoxnCollectionDesc.CLT_LIB) {
            cltLib = (String) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DoxnCollectionDesc.CLT_DT_DEB) {
            cltDtDeb = (Timestamp) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DoxnCollectionDesc.CLT_DT_FIN) {
            cltDtFin = (Timestamp) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DoxnCollectionDesc.CLT_SAI_CODE) {
            cltSaiCode = (String) value;
        }
        if (numCol == DoxnCollectionDesc.CLT_AN) {
            cltAn = (String) value;
        }
        if (numCol == DoxnCollectionDesc.CLT_DT_CREAT) {
            cltDtCreat = (Timestamp) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DoxnCollectionDesc.CLT_DT_MAJ) {
            cltDtMaj = (Timestamp) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DoxnCollectionDesc.CLT_UTIL_MAJ) {
            cltUtilMaj = (String) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DoxnCollectionDesc.XTX_ID) {
            xtxId = (Integer) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DoxnCollectionDesc.Z_STATUS) {
            zStatus = (String) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
    }

    public DataObject setProperty(SqlArg sqlArg) throws SQLException {
        return setProperty(sqlArg, new DoxnCollection());
    }

    private DataObject setProperty(SqlArg sqlArg, DoxnCollection djo) throws SQLException {
        ResultSet rs = sqlArg.getResultSet();
        int[] val = sqlArg.getVal();
        if (val[DoxnCollectionDesc.CLT_CODE] != -1) {
            djo.cltCode = rs.getString(val[DoxnCollectionDesc.CLT_CODE]);
        }
        if (val[DoxnCollectionDesc.CLT_LIB] != -1) {
            djo.cltLib = rs.getString(val[DoxnCollectionDesc.CLT_LIB]);
        }
        if (val[DoxnCollectionDesc.CLT_DT_DEB] != -1) {
            djo.cltDtDeb = rs.getTimestamp(val[DoxnCollectionDesc.CLT_DT_DEB]);
        }
        if (val[DoxnCollectionDesc.CLT_DT_FIN] != -1) {
            djo.cltDtFin = rs.getTimestamp(val[DoxnCollectionDesc.CLT_DT_FIN]);
        }
        if (val[DoxnCollectionDesc.CLT_SAI_CODE] != -1) {
            djo.cltSaiCode = rs.getString(val[DoxnCollectionDesc.CLT_SAI_CODE]);
        }
        if (val[DoxnCollectionDesc.CLT_AN] != -1) {
            djo.cltAn = rs.getString(val[DoxnCollectionDesc.CLT_AN]);
        }
        if (val[DoxnCollectionDesc.CLT_DT_CREAT] != -1) {
            djo.cltDtCreat = rs.getTimestamp(val[DoxnCollectionDesc.CLT_DT_CREAT]);
        }
        if (val[DoxnCollectionDesc.CLT_DT_MAJ] != -1) {
            djo.cltDtMaj = rs.getTimestamp(val[DoxnCollectionDesc.CLT_DT_MAJ]);
        }
        if (val[DoxnCollectionDesc.CLT_UTIL_MAJ] != -1) {
            djo.cltUtilMaj = rs.getString(val[DoxnCollectionDesc.CLT_UTIL_MAJ]);
        }
        if (val[DoxnCollectionDesc.XTX_ID] != -1) {
            int temp = rs.getInt(val[DoxnCollectionDesc.XTX_ID]);
            if (!rs.wasNull())
                djo.xtxId = new Integer(temp);
        }
        if (val[DoxnCollectionDesc.Z_STATUS] != -1) {
            djo.zStatus = rs.getString(val[DoxnCollectionDesc.Z_STATUS]);
        }
        return djo;
    }

    public void getProperty(SqlArg sqlArg) throws SQLException {
        PreparedStatement stmt = sqlArg.getStmt();
        int[] val = sqlArg.getVal();
        if (val[DoxnCollectionDesc.CLT_CODE] > 0) {
            stmt.setString(val[DoxnCollectionDesc.CLT_CODE], cltCode);
        }
        if (val[DoxnCollectionDesc.CLT_LIB] > 0) {
            stmt.setString(val[DoxnCollectionDesc.CLT_LIB], cltLib);
        }
        if (val[DoxnCollectionDesc.CLT_DT_DEB] > 0) {
            stmt.setTimestamp(val[DoxnCollectionDesc.CLT_DT_DEB], cltDtDeb);
        }
        if (val[DoxnCollectionDesc.CLT_DT_FIN] > 0) {
            stmt.setTimestamp(val[DoxnCollectionDesc.CLT_DT_FIN], cltDtFin);
        }
        if (val[DoxnCollectionDesc.CLT_SAI_CODE] > 0) {
            stmt.setString(val[DoxnCollectionDesc.CLT_SAI_CODE], cltSaiCode);
        }
        if (val[DoxnCollectionDesc.CLT_AN] > 0) {
            stmt.setString(val[DoxnCollectionDesc.CLT_AN], cltAn);
        }
        if (val[DoxnCollectionDesc.CLT_DT_CREAT] > 0) {
            stmt.setTimestamp(val[DoxnCollectionDesc.CLT_DT_CREAT], cltDtCreat);
        }
        if (val[DoxnCollectionDesc.CLT_DT_MAJ] > 0) {
            stmt.setTimestamp(val[DoxnCollectionDesc.CLT_DT_MAJ], cltDtMaj);
        }
        if (val[DoxnCollectionDesc.CLT_UTIL_MAJ] > 0) {
            stmt.setString(val[DoxnCollectionDesc.CLT_UTIL_MAJ], cltUtilMaj);
        }
        if (val[DoxnCollectionDesc.XTX_ID] > 0) {
            if (xtxId == null)
                stmt.setNull(val[DoxnCollectionDesc.XTX_ID], 3);
            else
                stmt.setInt(val[DoxnCollectionDesc.XTX_ID], xtxId.intValue());
        }
        if (val[DoxnCollectionDesc.Z_STATUS] > 0) {
            stmt.setString(val[DoxnCollectionDesc.Z_STATUS], zStatus);
        }
    }

    /**
     * M�thode g�n�r�e automatiquement permettant de remplir un dataobject � partir des valeurs
     * d'une requ�te http.
     * Les noms des param�tres de la requ�te doivent �tre strictement identique aux noms des attributs du DataObject.
     * Cette m�thode peut �tre compl�t�e afin de prendre en compte d'�ventuels param�tres se trouvant en session.
     * Pour une reg�n�ration �ventuelle, faites attention � ne coder qu'entre les tags de d�but et de fin.
     * Date de cr�ation : (25/05/01 08:03:14)
     *
     * @param request javax.servlet.http.HttpServletRequest
     */
    public DataObject[] setParameters(HttpServletRequest request)
            throws ParameterException, java.text.ParseException {
        String[] params = null;
        String localVal = null;
        int size = 0;
        DoxnCollection[] result = null;
        params = request.getParameterValues("cltCode");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoxnCollection[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoxnCollection();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setCltCode(localVal);
            }
        }
        params = request.getParameterValues("cltLib");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoxnCollection[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoxnCollection();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setCltLib(localVal);
            }
        }
        params = request.getParameterValues("cltDtDeb");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoxnCollection[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoxnCollection();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setCltDtDeb((Timestamp) StrConvertor.convert(localVal, Timestamp.class));
            }
        }
        params = request.getParameterValues("cltDtFin");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoxnCollection[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoxnCollection();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setCltDtFin((Timestamp) StrConvertor.convert(localVal, Timestamp.class));
            }
        }
        params = request.getParameterValues("cltSaiCode");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoxnCollection[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoxnCollection();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setCltSaiCode(localVal);
            }
        }
        params = request.getParameterValues("cltAn");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoxnCollection[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoxnCollection();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setCltAn(localVal);
            }
        }
        params = request.getParameterValues("cltDtCreat");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoxnCollection[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoxnCollection();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setCltDtCreat((Timestamp) StrConvertor.convert(localVal, Timestamp.class));
            }
        }
        params = request.getParameterValues("cltDtMaj");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoxnCollection[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoxnCollection();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setCltDtMaj((Timestamp) StrConvertor.convert(localVal, Timestamp.class));
            }
        }
        params = request.getParameterValues("cltUtilMaj");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoxnCollection[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoxnCollection();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setCltUtilMaj(localVal);
            }
        }
        params = request.getParameterValues("xtxId");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoxnCollection[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoxnCollection();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setXtxId((Integer) StrConvertor.convert(localVal, Integer.class));
            }
        }
        params = request.getParameterValues("zStatus");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoxnCollection[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoxnCollection();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setZStatus(localVal);
            }
        }
        /************************ INSTRUCTIONS DEVELOPPEMENT SPECIFIQUE *******************/
        /********************** FIN INSTRUCTIONS DEVELOPPEMENT SPECIFIQUE *****************/
        return result;
    }

    /*
     * @see DataObject#addChild(DataObject)
     */
    public void addChild(DataObject doChild) {
    }

    /*
     * @see DataObject#getDescription()
     */
    public IDoDescription getDescription() {
        return description;
    }

    /*
     * @see DataObject#getUpdateCol()
     */
    public int[] getUpdateCol() {
        return updCol;
    }

}
