package camaieu.pdm.dataobject;

import wg4.fwk.dataobject.IDoDescription;

import java.util.HashMap;

/**
 * /* Description de l'objetDoAlertes correspondant � la table ALERTES
 */
public class DoAlertesDesc implements IDoDescription {
    public static final int ALE_SPT_MODELE_CODE = 0;
    public static final int ALE_ORIGINE = 1;
    public static final int ALE_CHAMP = 2;
    public static final int ALE_DESTINATAIRE = 3;
    public static final int ALE_ENVOYEE = 4;
    public static final int ALE_ANCIENNE = 5;
    public static final int ALE_DATE = 6;

    public static final String tableName = "ALERTES";

    /*
     * Liste des noms de colonnes
     */
    public static final String[] dbColName = new String[]{
        "ALE_SPT_MODELE_CODE", "ALE_ORIGINE", "ALE_CHAMP", "ALE_DESTINATAIRE", "ALE_ENVOYEE", "ALE_ANCIENNE", "ALE_DATE"};
    private static final HashMap colBase;

    static {
        colBase = new HashMap(7);
        colBase.put("ALE_SPT_MODELE_CODE", new Integer(ALE_SPT_MODELE_CODE));
        colBase.put("ALE_ORIGINE", new Integer(ALE_ORIGINE));
        colBase.put("ALE_CHAMP", new Integer(ALE_CHAMP));
        colBase.put("ALE_DESTINATAIRE", new Integer(ALE_DESTINATAIRE));
        colBase.put("ALE_ENVOYEE", new Integer(ALE_ENVOYEE));
        colBase.put("ALE_ANCIENNE", new Integer(ALE_ANCIENNE));
        colBase.put("ALE_DATE", new Integer(ALE_DATE));
    }

    /*
     * Noms de colonnes de la cl� primaire
     */
    private static final String[] pkColName = new String[]{
    };

    private static final int[] pkColNum = new int[]{};

    private static final HashMap fkColName = new HashMap(1);

    static {
        fkColName.put("SUIVI_PROTO_TETE", new String[]{
            "ALE_SPT_MODELE_CODE"
        });
    }


    private static final HashMap fkColNum = new HashMap(1);

    static {
        fkColNum.put("SUIVI_PROTO_TETE", new int[]{
            0
        });
    }

    /**
     * @see IDoDescription.getTableName()
     */
    public String getTableName() {
        return tableName;
    }

    /**
     * @see IDoDescription.getDbColName()
     */
    public String[] getDbColName() {
        return dbColName;
    }

    /**
     * @see IDoDescription.getDbColNum()
     */
    public HashMap getDbColNum() {
        return colBase;
    }

    /**
     * @see IDoDescription.getPkColName()
     */
    public String[] getPkColName() {
        return pkColName;
    }

    /**
     * @see IDoDescription.getPkColNum()
     */
    public int[] getPkColNum() {
        return pkColNum;
    }
    /**
     * @see IDoDescription.getPkColNumInsert()
     */
    /**
     * @see IDoDescription.getFkColName()
     */
    public String[] getFkColName(String tableName) {
        return (String[]) fkColName.get(tableName);
    }

    /**
     * @see IDoDescription.getFkColNum()
     */
    public int[] getFkColNum(String tableName) {
        return (int[]) fkColNum.get(tableName);
    }
}
