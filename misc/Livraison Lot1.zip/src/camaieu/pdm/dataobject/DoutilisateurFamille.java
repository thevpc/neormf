package camaieu.pdm.dataobject;

import wg4.fwk.dataobject.DataObject;
import wg4.fwk.dataobject.IDoDescription;
import wg4.fwk.dataobject.ParameterException;
import wg4.fwk.dataobject.SqlArg;

import javax.servlet.http.HttpServletRequest;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.HashSet;

public class DoutilisateurFamille implements DataObject {

    private static final IDoDescription description = new DoutilisateurFamilleDesc();
    private transient int persist = PERSIST_UPDATE_INSERT;
    private transient int[] updCol = new int[2];
    private transient String sql;
    private transient Object[] param;

//tables correspondantes
    private static final String[] tableNames = new String[]{"UTILISATEUR_FAMILLE"};
    //variables correspondant � la table UTILISATEUR_FAMILLE
    private String ufUiUtiCode = null;
    private String ufFaaCode = null;

    /**
     * Constructeur utilis� par la m�thode setPropertie
     */
    public DoutilisateurFamille() {
    }

    /**
     * Constructeur permettant d'initialiser le type de persistance
     */
    public DoutilisateurFamille(int persistTyp) {
        persist = persistTyp;
    }

    /**
     * Constructeur permettant d'initialiser le type de persistance
     */
    public DoutilisateurFamille(DoutilisateurFamille arg) {
        setUfUiUtiCode(arg.ufUiUtiCode);
        setUfFaaCode(arg.ufFaaCode);
    }

    /**
     * Constructeur utilis� par la m�thode retrieve
     */
    public DoutilisateurFamille(String newSql, Object[] newParam) {
        sql = newSql;
        param = newParam;
    }

    public int getPersist() {
        return persist;
    }

    public void setPersist(int newPersist) {
        persist = newPersist;
    }

    public void resetUpdate() {
        Arrays.fill(updCol, -1);
    }

    public Object[] getParam() {
        return param;
    }

    public String getSQL() {
        return sql;
    }

    public HashSet getColNotInsertable() {
        return null;
    }

    public String getUfUiUtiCode() {
        return ufUiUtiCode;
    }

    public String getUfFaaCode() {
        return ufFaaCode;
    }

    public void setUfUiUtiCode(String newUfUiUtiCode) {
        ufUiUtiCode = newUfUiUtiCode;
    }

    public void setUfFaaCode(String newUfFaaCode) {
        ufFaaCode = newUfFaaCode;
    }

    public Object get(int numCol) {
        if (numCol == DoutilisateurFamilleDesc.UF_UI_UTI_CODE)
            return ufUiUtiCode;
        else if (numCol == DoutilisateurFamilleDesc.UF_FAA_CODE)
            return ufFaaCode;
        return null;
    }

    public void set(int numCol, Object value) {
        if (numCol == DoutilisateurFamilleDesc.UF_UI_UTI_CODE) {
            ufUiUtiCode = (String) value;
        }
        if (numCol == DoutilisateurFamilleDesc.UF_FAA_CODE) {
            ufFaaCode = (String) value;
        }
    }

    public DataObject setProperty(SqlArg sqlArg) throws SQLException {
        return setProperty(sqlArg, new DoutilisateurFamille());
    }

    private DataObject setProperty(SqlArg sqlArg, DoutilisateurFamille djo) throws SQLException {
        ResultSet rs = sqlArg.getResultSet();
        int[] val = sqlArg.getVal();
        if (val[DoutilisateurFamilleDesc.UF_UI_UTI_CODE] != -1) {
            djo.ufUiUtiCode = rs.getString(val[DoutilisateurFamilleDesc.UF_UI_UTI_CODE]);
        }
        if (val[DoutilisateurFamilleDesc.UF_FAA_CODE] != -1) {
            djo.ufFaaCode = rs.getString(val[DoutilisateurFamilleDesc.UF_FAA_CODE]);
        }
        return djo;
    }

    public void getProperty(SqlArg sqlArg) throws SQLException {
        PreparedStatement stmt = sqlArg.getStmt();
        int[] val = sqlArg.getVal();
        if (val[DoutilisateurFamilleDesc.UF_UI_UTI_CODE] > 0) {
            stmt.setString(val[DoutilisateurFamilleDesc.UF_UI_UTI_CODE], ufUiUtiCode);
        }
        if (val[DoutilisateurFamilleDesc.UF_FAA_CODE] > 0) {
            stmt.setString(val[DoutilisateurFamilleDesc.UF_FAA_CODE], ufFaaCode);
        }
    }

    /**
     * M�thode g�n�r�e automatiquement permettant de remplir un dataobject � partir des valeurs
     * d'une requ�te http.
     * Les noms des param�tres de la requ�te doivent �tre strictement identique aux noms des attributs du DataObject.
     * Cette m�thode peut �tre compl�t�e afin de prendre en compte d'�ventuels param�tres se trouvant en session.
     * Pour une reg�n�ration �ventuelle, faites attention � ne coder qu'entre les tags de d�but et de fin.
     * Date de cr�ation : (25/05/01 08:03:14)
     *
     * @param request javax.servlet.http.HttpServletRequest
     */
    public DataObject[] setParameters(HttpServletRequest request)
            throws ParameterException, java.text.ParseException {
        String[] params = null;
        String localVal = null;
        int size = 0;
        DoutilisateurFamille[] result = null;
        params = request.getParameterValues("ufUiUtiCode");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoutilisateurFamille[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoutilisateurFamille();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setUfUiUtiCode(localVal);
            }
        }
        params = request.getParameterValues("ufFaaCode");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoutilisateurFamille[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoutilisateurFamille();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setUfFaaCode(localVal);
            }
        }
        /************************ INSTRUCTIONS DEVELOPPEMENT SPECIFIQUE *******************/
        /********************** FIN INSTRUCTIONS DEVELOPPEMENT SPECIFIQUE *****************/
        return result;
    }

    /*
     * @see DataObject#addChild(DataObject)
     */
    public void addChild(DataObject doChild) {
    }

    /*
     * @see DataObject#getDescription()
     */
    public IDoDescription getDescription() {
        return description;
    }

    /*
     * @see DataObject#getUpdateCol()
     */
    public int[] getUpdateCol() {
        return updCol;
    }

}
