package camaieu.pdm.dataobject;

import wg4.fwk.dataobject.DataObject;
import wg4.fwk.dataobject.IDoDescription;
import wg4.fwk.dataobject.ParameterException;
import wg4.fwk.dataobject.SqlArg;
import wg4.fwk.mvc.tool.StrConvertor;

import javax.servlet.http.HttpServletRequest;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.HashSet;

public class DoactionLog implements DataObject {

    private static final IDoDescription description = new DoactionLogDesc();
    private transient int persist = PERSIST_UPDATE_INSERT;
    private transient int[] updCol = new int[5];
    private transient String sql;
    private transient Object[] param;

//tables correspondantes
    private static final String[] tableNames = new String[]{"ACTION_LOG"};
    //variables correspondant � la table ACTION_LOG
    private String actFouCode = null;
    private String actFicChamp = null;
    private Integer actFicVersion = null;
    private Integer actFicSptModeleCode = null;
    private Timestamp actDate = null;

    /**
     * Constructeur utilis� par la m�thode setPropertie
     */
    public DoactionLog() {
    }

    /**
     * Constructeur permettant d'initialiser le type de persistance
     */
    public DoactionLog(int persistTyp) {
        persist = persistTyp;
    }

    /**
     * Constructeur permettant d'initialiser le type de persistance
     */
    public DoactionLog(DoactionLog arg) {
        setActFouCode(arg.actFouCode);
        setActFicChamp(arg.actFicChamp);
        setActFicVersion(arg.actFicVersion);
        setActFicSptModeleCode(arg.actFicSptModeleCode);
        setActDate(arg.actDate);
    }

    /**
     * Constructeur utilis� par la m�thode retrieve
     */
    public DoactionLog(String newSql, Object[] newParam) {
        sql = newSql;
        param = newParam;
    }

    public int getPersist() {
        return persist;
    }

    public void setPersist(int newPersist) {
        persist = newPersist;
    }

    public void resetUpdate() {
        Arrays.fill(updCol, -1);
    }

    public Object[] getParam() {
        return param;
    }

    public String getSQL() {
        return sql;
    }

    public HashSet getColNotInsertable() {
        return null;
    }

    public String getActFouCode() {
        return actFouCode;
    }

    public String getActFicChamp() {
        return actFicChamp;
    }

    public Integer getActFicVersion() {
        return actFicVersion;
    }

    public Integer getActFicSptModeleCode() {
        return actFicSptModeleCode;
    }

    public Timestamp getActDate() {
        return actDate;
    }

    public void setActFouCode(String newActFouCode) {
        actFouCode = newActFouCode;
        if (persist > 0)
            updCol[DoactionLogDesc.ACT_FOU_CODE] = 1;
    }

    public void setActFicChamp(String newActFicChamp) {
        actFicChamp = newActFicChamp;
        if (persist > 0)
            updCol[DoactionLogDesc.ACT_FIC_CHAMP] = 1;
    }

    public void setActFicVersion(Integer newActFicVersion) {
        actFicVersion = newActFicVersion;
        if (persist > 0)
            updCol[DoactionLogDesc.ACT_FIC_VERSION] = 1;
    }

    public void setActFicSptModeleCode(Integer newActFicSptModeleCode) {
        actFicSptModeleCode = newActFicSptModeleCode;
        if (persist > 0)
            updCol[DoactionLogDesc.ACT_FIC_SPT_MODELE_CODE] = 1;
    }

    public void setActDate(Timestamp newActDate) {
        actDate = newActDate;
        if (persist > 0)
            updCol[DoactionLogDesc.ACT_DATE] = 1;
    }

    public Object get(int numCol) {
        if (numCol == DoactionLogDesc.ACT_FOU_CODE)
            return actFouCode;
        else if (numCol == DoactionLogDesc.ACT_FIC_CHAMP)
            return actFicChamp;
        else if (numCol == DoactionLogDesc.ACT_FIC_VERSION)
            return actFicVersion;
        else if (numCol == DoactionLogDesc.ACT_FIC_SPT_MODELE_CODE)
            return actFicSptModeleCode;
        else if (numCol == DoactionLogDesc.ACT_DATE)
            return actDate;
        return null;
    }

    public void set(int numCol, Object value) {
        if (numCol == DoactionLogDesc.ACT_FOU_CODE) {
            actFouCode = (String) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DoactionLogDesc.ACT_FIC_CHAMP) {
            actFicChamp = (String) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DoactionLogDesc.ACT_FIC_VERSION) {
            actFicVersion = (Integer) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DoactionLogDesc.ACT_FIC_SPT_MODELE_CODE) {
            actFicSptModeleCode = (Integer) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DoactionLogDesc.ACT_DATE) {
            actDate = (Timestamp) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
    }

    public DataObject setProperty(SqlArg sqlArg) throws SQLException {
        return setProperty(sqlArg, new DoactionLog());
    }

    private DataObject setProperty(SqlArg sqlArg, DoactionLog djo) throws SQLException {
        ResultSet rs = sqlArg.getResultSet();
        int[] val = sqlArg.getVal();
        if (val[DoactionLogDesc.ACT_FOU_CODE] != -1) {
            djo.actFouCode = rs.getString(val[DoactionLogDesc.ACT_FOU_CODE]);
        }
        if (val[DoactionLogDesc.ACT_FIC_CHAMP] != -1) {
            djo.actFicChamp = rs.getString(val[DoactionLogDesc.ACT_FIC_CHAMP]);
        }
        if (val[DoactionLogDesc.ACT_FIC_VERSION] != -1) {
            int temp = rs.getInt(val[DoactionLogDesc.ACT_FIC_VERSION]);
            if (!rs.wasNull())
                djo.actFicVersion = new Integer(temp);
        }
        if (val[DoactionLogDesc.ACT_FIC_SPT_MODELE_CODE] != -1) {
            int temp = rs.getInt(val[DoactionLogDesc.ACT_FIC_SPT_MODELE_CODE]);
            if (!rs.wasNull())
                djo.actFicSptModeleCode = new Integer(temp);
        }
        if (val[DoactionLogDesc.ACT_DATE] != -1) {
            djo.actDate = rs.getTimestamp(val[DoactionLogDesc.ACT_DATE]);
        }
        return djo;
    }

    public void getProperty(SqlArg sqlArg) throws SQLException {
        PreparedStatement stmt = sqlArg.getStmt();
        int[] val = sqlArg.getVal();
        if (val[DoactionLogDesc.ACT_FOU_CODE] > 0) {
            stmt.setString(val[DoactionLogDesc.ACT_FOU_CODE], actFouCode);
        }
        if (val[DoactionLogDesc.ACT_FIC_CHAMP] > 0) {
            stmt.setString(val[DoactionLogDesc.ACT_FIC_CHAMP], actFicChamp);
        }
        if (val[DoactionLogDesc.ACT_FIC_VERSION] > 0) {
            if (actFicVersion == null)
                stmt.setNull(val[DoactionLogDesc.ACT_FIC_VERSION], 3);
            else
                stmt.setInt(val[DoactionLogDesc.ACT_FIC_VERSION], actFicVersion.intValue());
        }
        if (val[DoactionLogDesc.ACT_FIC_SPT_MODELE_CODE] > 0) {
            if (actFicSptModeleCode == null)
                stmt.setNull(val[DoactionLogDesc.ACT_FIC_SPT_MODELE_CODE], 3);
            else
                stmt.setInt(val[DoactionLogDesc.ACT_FIC_SPT_MODELE_CODE], actFicSptModeleCode.intValue());
        }
        if (val[DoactionLogDesc.ACT_DATE] > 0) {
            stmt.setTimestamp(val[DoactionLogDesc.ACT_DATE], actDate);
        }
    }

    /**
     * M�thode g�n�r�e automatiquement permettant de remplir un dataobject � partir des valeurs
     * d'une requ�te http.
     * Les noms des param�tres de la requ�te doivent �tre strictement identique aux noms des attributs du DataObject.
     * Cette m�thode peut �tre compl�t�e afin de prendre en compte d'�ventuels param�tres se trouvant en session.
     * Pour une reg�n�ration �ventuelle, faites attention � ne coder qu'entre les tags de d�but et de fin.
     * Date de cr�ation : (25/05/01 08:03:14)
     *
     * @param request javax.servlet.http.HttpServletRequest
     */
    public DataObject[] setParameters(HttpServletRequest request)
            throws ParameterException, java.text.ParseException {
        String[] params = null;
        String localVal = null;
        int size = 0;
        DoactionLog[] result = null;
        params = request.getParameterValues("actFouCode");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoactionLog[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoactionLog();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setActFouCode(localVal);
            }
        }
        params = request.getParameterValues("actFicChamp");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoactionLog[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoactionLog();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setActFicChamp(localVal);
            }
        }
        params = request.getParameterValues("actFicVersion");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoactionLog[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoactionLog();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setActFicVersion((Integer) StrConvertor.convert(localVal, Integer.class));
            }
        }
        params = request.getParameterValues("actFicSptModeleCode");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoactionLog[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoactionLog();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setActFicSptModeleCode((Integer) StrConvertor.convert(localVal, Integer.class));
            }
        }
        params = request.getParameterValues("actDate");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoactionLog[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoactionLog();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setActDate((Timestamp) StrConvertor.convert(localVal, Timestamp.class));
            }
        }
        /************************ INSTRUCTIONS DEVELOPPEMENT SPECIFIQUE *******************/
        /********************** FIN INSTRUCTIONS DEVELOPPEMENT SPECIFIQUE *****************/
        return result;
    }

    /*
     * @see DataObject#addChild(DataObject)
     */
    public void addChild(DataObject doChild) {
    }

    /*
     * @see DataObject#getDescription()
     */
    public IDoDescription getDescription() {
        return description;
    }

    /*
     * @see DataObject#getUpdateCol()
     */
    public int[] getUpdateCol() {
        return updCol;
    }

}
