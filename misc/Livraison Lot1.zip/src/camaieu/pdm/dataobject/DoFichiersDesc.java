package camaieu.pdm.dataobject;

import wg4.fwk.dataobject.IDoDescription;

import java.util.HashMap;

/**
 * /* Description de l'objetDoFichiers correspondant � la table FICHIERS
 */
public class DoFichiersDesc implements IDoDescription {
    public static final int FIC_CHAMP = 0;
    public static final int FIC_VERSION = 1;
    public static final int FIC_SPT_MODELE_CODE = 2;
    public static final int FIC_EXTENSION = 3;
    public static final int FIC_FICHIER = 4;
    public static final int FIC_DATE = 5;

    public static final String tableName = "FICHIERS";

    /*
     * Liste des noms de colonnes
     */
    public static final String[] dbColName = new String[]{
        "FIC_CHAMP", "FIC_VERSION", "FIC_SPT_MODELE_CODE", "FIC_EXTENSION", "FIC_FICHIER", "FIC_DATE"};
    private static final HashMap colBase;

    static {
        colBase = new HashMap(6);
        colBase.put("FIC_CHAMP", new Integer(FIC_CHAMP));
        colBase.put("FIC_VERSION", new Integer(FIC_VERSION));
        colBase.put("FIC_SPT_MODELE_CODE", new Integer(FIC_SPT_MODELE_CODE));
        colBase.put("FIC_EXTENSION", new Integer(FIC_EXTENSION));
        colBase.put("FIC_FICHIER", new Integer(FIC_FICHIER));
        colBase.put("FIC_DATE", new Integer(FIC_DATE));
    }

    /*
     * Noms de colonnes de la cl� primaire
     */
    private static final String[] pkColName = new String[]{
        "FIC_VERSION", "FIC_SPT_MODELE_CODE", "FIC_CHAMP"};

    private static final int[] pkColNum = new int[]{1, 2, 0};

    private static final HashMap fkColName = new HashMap(1);

    static {
        fkColName.put("SUIVI_PROTO_TETE", new String[]{
            "FIC_SPT_MODELE_CODE"
        });
    }

    static {
        fkColName.put("ACTION_LOG", new String[]{
            "FIC_CHAMP", "FIC_VERSION", "FIC_SPT_MODELE_CODE"
        });
    }


    private static final HashMap fkColNum = new HashMap(1);

    static {
        fkColNum.put("SUIVI_PROTO_TETE", new int[]{
            2
        });
    }

    static {
        fkColNum.put("ACTION_LOG", new int[]{
            0, 1, 2
        });
    }

    /**
     * @see IDoDescription.getTableName()
     */
    public String getTableName() {
        return tableName;
    }

    /**
     * @see IDoDescription.getDbColName()
     */
    public String[] getDbColName() {
        return dbColName;
    }

    /**
     * @see IDoDescription.getDbColNum()
     */
    public HashMap getDbColNum() {
        return colBase;
    }

    /**
     * @see IDoDescription.getPkColName()
     */
    public String[] getPkColName() {
        return pkColName;
    }

    /**
     * @see IDoDescription.getPkColNum()
     */
    public int[] getPkColNum() {
        return pkColNum;
    }
    /**
     * @see IDoDescription.getPkColNumInsert()
     */
    /**
     * @see IDoDescription.getFkColName()
     */
    public String[] getFkColName(String tableName) {
        return (String[]) fkColName.get(tableName);
    }

    /**
     * @see IDoDescription.getFkColNum()
     */
    public int[] getFkColNum(String tableName) {
        return (int[]) fkColNum.get(tableName);
    }
}
