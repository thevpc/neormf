package camaieu.pdm.dataobject;

import wg4.fwk.dataobject.DataObject;
import wg4.fwk.dataobject.IDoDescription;
import wg4.fwk.dataobject.ParameterException;
import wg4.fwk.dataobject.SqlArg;
import wg4.fwk.mvc.tool.StrConvertor;

import javax.servlet.http.HttpServletRequest;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.HashSet;

public class DosuiviProtoMap implements DataObject {

    private static final IDoDescription description = new DosuiviProtoMapDesc();
    private transient int persist = PERSIST_UPDATE_INSERT;
    private transient int[] updCol = new int[11];
    private transient String sql;
    private transient Object[] param;

//tables correspondantes
    private static final String[] tableNames = new String[]{"SUIVI_PROTO_MAP"};
    //variables correspondant � la table SUIVI_PROTO_MAP
    private Integer spmSptModeleCode = null;
    private Integer spmNoProto = null;
    private byte[] spmCommentaires = null;
    private Timestamp spmDtEnvComment = null;
    private Timestamp spmDtRetourDde = null;
    private Timestamp spmDtRecepComment = null;
    private Timestamp spmDtEnvProto = null;
    private Timestamp spmDtRecepProto = null;
    private Timestamp spmDtReunionProd = null;
    private String spmDecisionOkMap = null;
    private Timestamp spmDtDecisionOkMap = null;

    /**
     * Constructeur utilis� par la m�thode setPropertie
     */
    public DosuiviProtoMap() {
    }

    /**
     * Constructeur permettant d'initialiser le type de persistance
     */
    public DosuiviProtoMap(int persistTyp) {
        persist = persistTyp;
    }

    /**
     * Constructeur permettant d'initialiser le type de persistance
     */
    public DosuiviProtoMap(DosuiviProtoMap arg) {
        setSpmSptModeleCode(arg.spmSptModeleCode);
        setSpmNoProto(arg.spmNoProto);
        setSpmCommentaires(arg.spmCommentaires);
        setSpmDtEnvComment(arg.spmDtEnvComment);
        setSpmDtRetourDde(arg.spmDtRetourDde);
        setSpmDtRecepComment(arg.spmDtRecepComment);
        setSpmDtEnvProto(arg.spmDtEnvProto);
        setSpmDtRecepProto(arg.spmDtRecepProto);
        setSpmDtReunionProd(arg.spmDtReunionProd);
        setSpmDecisionOkMap(arg.spmDecisionOkMap);
        setSpmDtDecisionOkMap(arg.spmDtDecisionOkMap);
    }

    /**
     * Constructeur utilis� par la m�thode retrieve
     */
    public DosuiviProtoMap(String newSql, Object[] newParam) {
        sql = newSql;
        param = newParam;
    }

    public int getPersist() {
        return persist;
    }

    public void setPersist(int newPersist) {
        persist = newPersist;
    }

    public void resetUpdate() {
        Arrays.fill(updCol, -1);
    }

    public Object[] getParam() {
        return param;
    }

    public String getSQL() {
        return sql;
    }

    public HashSet getColNotInsertable() {
        return null;
    }

    public Integer getSpmSptModeleCode() {
        return spmSptModeleCode;
    }

    public Integer getSpmNoProto() {
        return spmNoProto;
    }

    public byte[] getSpmCommentaires() {
        return spmCommentaires;
    }

    public Timestamp getSpmDtEnvComment() {
        return spmDtEnvComment;
    }

    public Timestamp getSpmDtRetourDde() {
        return spmDtRetourDde;
    }

    public Timestamp getSpmDtRecepComment() {
        return spmDtRecepComment;
    }

    public Timestamp getSpmDtEnvProto() {
        return spmDtEnvProto;
    }

    public Timestamp getSpmDtRecepProto() {
        return spmDtRecepProto;
    }

    public Timestamp getSpmDtReunionProd() {
        return spmDtReunionProd;
    }

    public String getSpmDecisionOkMap() {
        return spmDecisionOkMap;
    }

    public Timestamp getSpmDtDecisionOkMap() {
        return spmDtDecisionOkMap;
    }

    public void setSpmSptModeleCode(Integer newSpmSptModeleCode) {
        spmSptModeleCode = newSpmSptModeleCode;
    }

    public void setSpmNoProto(Integer newSpmNoProto) {
        spmNoProto = newSpmNoProto;
    }

    public void setSpmCommentaires(byte[] newSpmCommentaires) {
        spmCommentaires = newSpmCommentaires;
        if (persist > 0)
            updCol[DosuiviProtoMapDesc.SPM_COMMENTAIRES] = 1;
    }

    public void setSpmDtEnvComment(Timestamp newSpmDtEnvComment) {
        spmDtEnvComment = newSpmDtEnvComment;
        if (persist > 0)
            updCol[DosuiviProtoMapDesc.SPM_DT_ENV_COMMENT] = 1;
    }

    public void setSpmDtRetourDde(Timestamp newSpmDtRetourDde) {
        spmDtRetourDde = newSpmDtRetourDde;
        if (persist > 0)
            updCol[DosuiviProtoMapDesc.SPM_DT_RETOUR_DDE] = 1;
    }

    public void setSpmDtRecepComment(Timestamp newSpmDtRecepComment) {
        spmDtRecepComment = newSpmDtRecepComment;
        if (persist > 0)
            updCol[DosuiviProtoMapDesc.SPM_DT_RECEP_COMMENT] = 1;
    }

    public void setSpmDtEnvProto(Timestamp newSpmDtEnvProto) {
        spmDtEnvProto = newSpmDtEnvProto;
        if (persist > 0)
            updCol[DosuiviProtoMapDesc.SPM_DT_ENV_PROTO] = 1;
    }

    public void setSpmDtRecepProto(Timestamp newSpmDtRecepProto) {
        spmDtRecepProto = newSpmDtRecepProto;
        if (persist > 0)
            updCol[DosuiviProtoMapDesc.SPM_DT_RECEP_PROTO] = 1;
    }

    public void setSpmDtReunionProd(Timestamp newSpmDtReunionProd) {
        spmDtReunionProd = newSpmDtReunionProd;
        if (persist > 0)
            updCol[DosuiviProtoMapDesc.SPM_DT_REUNION_PROD] = 1;
    }

    public void setSpmDecisionOkMap(String newSpmDecisionOkMap) {
        spmDecisionOkMap = newSpmDecisionOkMap;
        if (persist > 0)
            updCol[DosuiviProtoMapDesc.SPM_DECISION_OK_MAP] = 1;
    }

    public void setSpmDtDecisionOkMap(Timestamp newSpmDtDecisionOkMap) {
        spmDtDecisionOkMap = newSpmDtDecisionOkMap;
        if (persist > 0)
            updCol[DosuiviProtoMapDesc.SPM_DT_DECISION_OK_MAP] = 1;
    }

    public Object get(int numCol) {
        if (numCol == DosuiviProtoMapDesc.SPM_SPT_MODELE_CODE)
            return spmSptModeleCode;
        else if (numCol == DosuiviProtoMapDesc.SPM_NO_PROTO)
            return spmNoProto;
        else if (numCol == DosuiviProtoMapDesc.SPM_COMMENTAIRES)
            return spmCommentaires;
        else if (numCol == DosuiviProtoMapDesc.SPM_DT_ENV_COMMENT)
            return spmDtEnvComment;
        else if (numCol == DosuiviProtoMapDesc.SPM_DT_RETOUR_DDE)
            return spmDtRetourDde;
        else if (numCol == DosuiviProtoMapDesc.SPM_DT_RECEP_COMMENT)
            return spmDtRecepComment;
        else if (numCol == DosuiviProtoMapDesc.SPM_DT_ENV_PROTO)
            return spmDtEnvProto;
        else if (numCol == DosuiviProtoMapDesc.SPM_DT_RECEP_PROTO)
            return spmDtRecepProto;
        else if (numCol == DosuiviProtoMapDesc.SPM_DT_REUNION_PROD)
            return spmDtReunionProd;
        else if (numCol == DosuiviProtoMapDesc.SPM_DECISION_OK_MAP)
            return spmDecisionOkMap;
        else if (numCol == DosuiviProtoMapDesc.SPM_DT_DECISION_OK_MAP)
            return spmDtDecisionOkMap;
        return null;
    }

    public void set(int numCol, Object value) {
        if (numCol == DosuiviProtoMapDesc.SPM_SPT_MODELE_CODE) {
            spmSptModeleCode = (Integer) value;
        }
        if (numCol == DosuiviProtoMapDesc.SPM_NO_PROTO) {
            spmNoProto = (Integer) value;
        }
        if (numCol == DosuiviProtoMapDesc.SPM_COMMENTAIRES) {
            spmCommentaires = (byte[]) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoMapDesc.SPM_DT_ENV_COMMENT) {
            spmDtEnvComment = (Timestamp) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoMapDesc.SPM_DT_RETOUR_DDE) {
            spmDtRetourDde = (Timestamp) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoMapDesc.SPM_DT_RECEP_COMMENT) {
            spmDtRecepComment = (Timestamp) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoMapDesc.SPM_DT_ENV_PROTO) {
            spmDtEnvProto = (Timestamp) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoMapDesc.SPM_DT_RECEP_PROTO) {
            spmDtRecepProto = (Timestamp) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoMapDesc.SPM_DT_REUNION_PROD) {
            spmDtReunionProd = (Timestamp) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoMapDesc.SPM_DECISION_OK_MAP) {
            spmDecisionOkMap = (String) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoMapDesc.SPM_DT_DECISION_OK_MAP) {
            spmDtDecisionOkMap = (Timestamp) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
    }

    public DataObject setProperty(SqlArg sqlArg) throws SQLException {
        return setProperty(sqlArg, new DosuiviProtoMap());
    }

    private DataObject setProperty(SqlArg sqlArg, DosuiviProtoMap djo) throws SQLException {
        ResultSet rs = sqlArg.getResultSet();
        int[] val = sqlArg.getVal();
        if (val[DosuiviProtoMapDesc.SPM_SPT_MODELE_CODE] != -1) {
            int temp = rs.getInt(val[DosuiviProtoMapDesc.SPM_SPT_MODELE_CODE]);
            if (!rs.wasNull())
                djo.spmSptModeleCode = new Integer(temp);
        }
        if (val[DosuiviProtoMapDesc.SPM_NO_PROTO] != -1) {
            int temp = rs.getInt(val[DosuiviProtoMapDesc.SPM_NO_PROTO]);
            if (!rs.wasNull())
                djo.spmNoProto = new Integer(temp);
        }
        if (val[DosuiviProtoMapDesc.SPM_COMMENTAIRES] != -1) {
        }
        if (val[DosuiviProtoMapDesc.SPM_DT_ENV_COMMENT] != -1) {
            djo.spmDtEnvComment = rs.getTimestamp(val[DosuiviProtoMapDesc.SPM_DT_ENV_COMMENT]);
        }
        if (val[DosuiviProtoMapDesc.SPM_DT_RETOUR_DDE] != -1) {
            djo.spmDtRetourDde = rs.getTimestamp(val[DosuiviProtoMapDesc.SPM_DT_RETOUR_DDE]);
        }
        if (val[DosuiviProtoMapDesc.SPM_DT_RECEP_COMMENT] != -1) {
            djo.spmDtRecepComment = rs.getTimestamp(val[DosuiviProtoMapDesc.SPM_DT_RECEP_COMMENT]);
        }
        if (val[DosuiviProtoMapDesc.SPM_DT_ENV_PROTO] != -1) {
            djo.spmDtEnvProto = rs.getTimestamp(val[DosuiviProtoMapDesc.SPM_DT_ENV_PROTO]);
        }
        if (val[DosuiviProtoMapDesc.SPM_DT_RECEP_PROTO] != -1) {
            djo.spmDtRecepProto = rs.getTimestamp(val[DosuiviProtoMapDesc.SPM_DT_RECEP_PROTO]);
        }
        if (val[DosuiviProtoMapDesc.SPM_DT_REUNION_PROD] != -1) {
            djo.spmDtReunionProd = rs.getTimestamp(val[DosuiviProtoMapDesc.SPM_DT_REUNION_PROD]);
        }
        if (val[DosuiviProtoMapDesc.SPM_DECISION_OK_MAP] != -1) {
            djo.spmDecisionOkMap = rs.getString(val[DosuiviProtoMapDesc.SPM_DECISION_OK_MAP]);
        }
        if (val[DosuiviProtoMapDesc.SPM_DT_DECISION_OK_MAP] != -1) {
            djo.spmDtDecisionOkMap = rs.getTimestamp(val[DosuiviProtoMapDesc.SPM_DT_DECISION_OK_MAP]);
        }
        return djo;
    }

    public void getProperty(SqlArg sqlArg) throws SQLException {
        PreparedStatement stmt = sqlArg.getStmt();
        int[] val = sqlArg.getVal();
        if (val[DosuiviProtoMapDesc.SPM_SPT_MODELE_CODE] > 0) {
            if (spmSptModeleCode == null)
                stmt.setNull(val[DosuiviProtoMapDesc.SPM_SPT_MODELE_CODE], 3);
            else
                stmt.setInt(val[DosuiviProtoMapDesc.SPM_SPT_MODELE_CODE], spmSptModeleCode.intValue());
        }
        if (val[DosuiviProtoMapDesc.SPM_NO_PROTO] > 0) {
            if (spmNoProto == null)
                stmt.setNull(val[DosuiviProtoMapDesc.SPM_NO_PROTO], 3);
            else
                stmt.setInt(val[DosuiviProtoMapDesc.SPM_NO_PROTO], spmNoProto.intValue());
        }
        if (val[DosuiviProtoMapDesc.SPM_COMMENTAIRES] > 0) {
            stmt.setObject(val[DosuiviProtoMapDesc.SPM_COMMENTAIRES], spmCommentaires);
        }
        if (val[DosuiviProtoMapDesc.SPM_DT_ENV_COMMENT] > 0) {
            stmt.setTimestamp(val[DosuiviProtoMapDesc.SPM_DT_ENV_COMMENT], spmDtEnvComment);
        }
        if (val[DosuiviProtoMapDesc.SPM_DT_RETOUR_DDE] > 0) {
            stmt.setTimestamp(val[DosuiviProtoMapDesc.SPM_DT_RETOUR_DDE], spmDtRetourDde);
        }
        if (val[DosuiviProtoMapDesc.SPM_DT_RECEP_COMMENT] > 0) {
            stmt.setTimestamp(val[DosuiviProtoMapDesc.SPM_DT_RECEP_COMMENT], spmDtRecepComment);
        }
        if (val[DosuiviProtoMapDesc.SPM_DT_ENV_PROTO] > 0) {
            stmt.setTimestamp(val[DosuiviProtoMapDesc.SPM_DT_ENV_PROTO], spmDtEnvProto);
        }
        if (val[DosuiviProtoMapDesc.SPM_DT_RECEP_PROTO] > 0) {
            stmt.setTimestamp(val[DosuiviProtoMapDesc.SPM_DT_RECEP_PROTO], spmDtRecepProto);
        }
        if (val[DosuiviProtoMapDesc.SPM_DT_REUNION_PROD] > 0) {
            stmt.setTimestamp(val[DosuiviProtoMapDesc.SPM_DT_REUNION_PROD], spmDtReunionProd);
        }
        if (val[DosuiviProtoMapDesc.SPM_DECISION_OK_MAP] > 0) {
            stmt.setString(val[DosuiviProtoMapDesc.SPM_DECISION_OK_MAP], spmDecisionOkMap);
        }
        if (val[DosuiviProtoMapDesc.SPM_DT_DECISION_OK_MAP] > 0) {
            stmt.setTimestamp(val[DosuiviProtoMapDesc.SPM_DT_DECISION_OK_MAP], spmDtDecisionOkMap);
        }
    }

    /**
     * M�thode g�n�r�e automatiquement permettant de remplir un dataobject � partir des valeurs
     * d'une requ�te http.
     * Les noms des param�tres de la requ�te doivent �tre strictement identique aux noms des attributs du DataObject.
     * Cette m�thode peut �tre compl�t�e afin de prendre en compte d'�ventuels param�tres se trouvant en session.
     * Pour une reg�n�ration �ventuelle, faites attention � ne coder qu'entre les tags de d�but et de fin.
     * Date de cr�ation : (25/05/01 08:03:14)
     *
     * @param request javax.servlet.http.HttpServletRequest
     */
    public DataObject[] setParameters(HttpServletRequest request)
            throws ParameterException, java.text.ParseException {
        String[] params = null;
        String localVal = null;
        int size = 0;
        DosuiviProtoMap[] result = null;
        params = request.getParameterValues("spmSptModeleCode");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoMap[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoMap();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSpmSptModeleCode((Integer) StrConvertor.convert(localVal, Integer.class));
            }
        }
        params = request.getParameterValues("spmNoProto");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoMap[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoMap();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSpmNoProto((Integer) StrConvertor.convert(localVal, Integer.class));
            }
        }
        params = request.getParameterValues("spmCommentaires");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoMap[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoMap();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSpmCommentaires((byte[]) StrConvertor.convert(localVal, byte[].class));
            }
        }
        params = request.getParameterValues("spmDtEnvComment");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoMap[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoMap();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSpmDtEnvComment((Timestamp) StrConvertor.convert(localVal, Timestamp.class));
            }
        }
        params = request.getParameterValues("spmDtRetourDde");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoMap[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoMap();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSpmDtRetourDde((Timestamp) StrConvertor.convert(localVal, Timestamp.class));
            }
        }
        params = request.getParameterValues("spmDtRecepComment");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoMap[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoMap();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSpmDtRecepComment((Timestamp) StrConvertor.convert(localVal, Timestamp.class));
            }
        }
        params = request.getParameterValues("spmDtEnvProto");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoMap[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoMap();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSpmDtEnvProto((Timestamp) StrConvertor.convert(localVal, Timestamp.class));
            }
        }
        params = request.getParameterValues("spmDtRecepProto");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoMap[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoMap();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSpmDtRecepProto((Timestamp) StrConvertor.convert(localVal, Timestamp.class));
            }
        }
        params = request.getParameterValues("spmDtReunionProd");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoMap[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoMap();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSpmDtReunionProd((Timestamp) StrConvertor.convert(localVal, Timestamp.class));
            }
        }
        params = request.getParameterValues("spmDecisionOkMap");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoMap[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoMap();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSpmDecisionOkMap(localVal);
            }
        }
        params = request.getParameterValues("spmDtDecisionOkMap");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoMap[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoMap();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSpmDtDecisionOkMap((Timestamp) StrConvertor.convert(localVal, Timestamp.class));
            }
        }
        /************************ INSTRUCTIONS DEVELOPPEMENT SPECIFIQUE *******************/
        /********************** FIN INSTRUCTIONS DEVELOPPEMENT SPECIFIQUE *****************/
        return result;
    }

    /*
     * @see DataObject#addChild(DataObject)
     */
    public void addChild(DataObject doChild) {
    }

    /*
     * @see DataObject#getDescription()
     */
    public IDoDescription getDescription() {
        return description;
    }

    /*
     * @see DataObject#getUpdateCol()
     */
    public int[] getUpdateCol() {
        return updCol;
    }

}
