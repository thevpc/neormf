package camaieu.pdm.dataobject;

import wg4.fwk.dataobject.IDoDescription;

import java.util.HashMap;

/**
 * /* Description de l'objetDoxnCollection correspondant � la table XN_COLLECTION
 */
public class DoxnCollectionDesc implements IDoDescription {
    public static final int CLT_CODE = 0;
    public static final int CLT_LIB = 1;
    public static final int CLT_DT_DEB = 2;
    public static final int CLT_DT_FIN = 3;
    public static final int CLT_SAI_CODE = 4;
    public static final int CLT_AN = 5;
    public static final int CLT_DT_CREAT = 6;
    public static final int CLT_DT_MAJ = 7;
    public static final int CLT_UTIL_MAJ = 8;
    public static final int XTX_ID = 9;
    public static final int Z_STATUS = 10;

    public static final String tableName = "XN_COLLECTION";

    /*
     * Liste des noms de colonnes
     */
    public static final String[] dbColName = new String[]{
        "CLT_CODE", "CLT_LIB", "CLT_DT_DEB", "CLT_DT_FIN", "CLT_SAI_CODE", "CLT_AN", "CLT_DT_CREAT", "CLT_DT_MAJ", "CLT_UTIL_MAJ", "XTX_ID", "Z_STATUS"};
    private static final HashMap colBase;

    static {
        colBase = new HashMap(11);
        colBase.put("CLT_CODE", new Integer(CLT_CODE));
        colBase.put("CLT_LIB", new Integer(CLT_LIB));
        colBase.put("CLT_DT_DEB", new Integer(CLT_DT_DEB));
        colBase.put("CLT_DT_FIN", new Integer(CLT_DT_FIN));
        colBase.put("CLT_SAI_CODE", new Integer(CLT_SAI_CODE));
        colBase.put("CLT_AN", new Integer(CLT_AN));
        colBase.put("CLT_DT_CREAT", new Integer(CLT_DT_CREAT));
        colBase.put("CLT_DT_MAJ", new Integer(CLT_DT_MAJ));
        colBase.put("CLT_UTIL_MAJ", new Integer(CLT_UTIL_MAJ));
        colBase.put("XTX_ID", new Integer(XTX_ID));
        colBase.put("Z_STATUS", new Integer(Z_STATUS));
    }

    /*
     * Noms de colonnes de la cl� primaire
     */
    private static final String[] pkColName = new String[]{
        "CLT_SAI_CODE", "CLT_CODE", "CLT_AN"};

    private static final int[] pkColNum = new int[]{4, 0, 5};

    private static final HashMap fkColName = new HashMap(1);

    static {
        fkColName.put("XN_SAISON", new String[]{
            "CLT_SAI_CODE"
        });
    }

    static {
        fkColName.put("DT_CMDE_ACHAT_MC", new String[]{
            "CLT_AN", "CLT_SAI_CODE", "CLT_CODE"
        });
        fkColName.put("XN_COLLECTION_MOD_COULEUR", new String[]{
            "CLT_AN"
        });
        fkColName.put("XN_COLLECTION_MOD_COULEUR", new String[]{
            "CLT_SAI_CODE"
        });
        fkColName.put("XN_COLLECTION_MOD_COULEUR", new String[]{
            "CLT_CODE"
        });
    }


    private static final HashMap fkColNum = new HashMap(1);

    static {
        fkColNum.put("XN_SAISON", new int[]{
            4
        });
    }

    static {
        fkColNum.put("DT_CMDE_ACHAT_MC", new int[]{
            5, 4, 0
        });
        fkColNum.put("XN_COLLECTION_MOD_COULEUR", new int[]{
            5
        });
        fkColNum.put("XN_COLLECTION_MOD_COULEUR", new int[]{
            4
        });
        fkColNum.put("XN_COLLECTION_MOD_COULEUR", new int[]{
            0
        });
    }

    /**
     * @see IDoDescription.getTableName()
     */
    public String getTableName() {
        return tableName;
    }

    /**
     * @see IDoDescription.getDbColName()
     */
    public String[] getDbColName() {
        return dbColName;
    }

    /**
     * @see IDoDescription.getDbColNum()
     */
    public HashMap getDbColNum() {
        return colBase;
    }

    /**
     * @see IDoDescription.getPkColName()
     */
    public String[] getPkColName() {
        return pkColName;
    }

    /**
     * @see IDoDescription.getPkColNum()
     */
    public int[] getPkColNum() {
        return pkColNum;
    }
    /**
     * @see IDoDescription.getPkColNumInsert()
     */
    /**
     * @see IDoDescription.getFkColName()
     */
    public String[] getFkColName(String tableName) {
        return (String[]) fkColName.get(tableName);
    }

    /**
     * @see IDoDescription.getFkColNum()
     */
    public int[] getFkColNum(String tableName) {
        return (int[]) fkColNum.get(tableName);
    }
}
