package camaieu.pdm.dataobject;

import wg4.fwk.dataobject.DataObject;
import wg4.fwk.dataobject.IDoDescription;
import wg4.fwk.dataobject.ParameterException;
import wg4.fwk.dataobject.SqlArg;
import wg4.fwk.mvc.tool.StrConvertor;

import javax.servlet.http.HttpServletRequest;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.HashSet;

public class DosuiviProtoProd implements DataObject {

    private static final IDoDescription description = new DosuiviProtoProdDesc();
    private transient int persist = PERSIST_UPDATE_INSERT;
    private transient int[] updCol = new int[10];
    private transient String sql;
    private transient Object[] param;

//tables correspondantes
    private static final String[] tableNames = new String[]{"SUIVI_PROTO_PROD"};
    //variables correspondant � la table SUIVI_PROTO_PROD
    private Integer sppSptModeleCode = null;
    private Integer sppNoProto = null;
    private byte[] sppCommentaires = null;
    private Timestamp sppDtEnvComment = null;
    private Timestamp sppDtRecepComment = null;
    private Timestamp sppDtRetourDde = null;
    private Timestamp sppDtEnvProto = null;
    private Timestamp sppDtRecepProto = null;
    private Timestamp sppDtDecOkProd = null;
    private String sppDecOkProd = null;

    /**
     * Constructeur utilis� par la m�thode setPropertie
     */
    public DosuiviProtoProd() {
    }

    /**
     * Constructeur permettant d'initialiser le type de persistance
     */
    public DosuiviProtoProd(int persistTyp) {
        persist = persistTyp;
    }

    /**
     * Constructeur permettant d'initialiser le type de persistance
     */
    public DosuiviProtoProd(DosuiviProtoProd arg) {
        setSppSptModeleCode(arg.sppSptModeleCode);
        setSppNoProto(arg.sppNoProto);
        setSppCommentaires(arg.sppCommentaires);
        setSppDtEnvComment(arg.sppDtEnvComment);
        setSppDtRecepComment(arg.sppDtRecepComment);
        setSppDtRetourDde(arg.sppDtRetourDde);
        setSppDtEnvProto(arg.sppDtEnvProto);
        setSppDtRecepProto(arg.sppDtRecepProto);
        setSppDtDecOkProd(arg.sppDtDecOkProd);
        setSppDecOkProd(arg.sppDecOkProd);
    }

    /**
     * Constructeur utilis� par la m�thode retrieve
     */
    public DosuiviProtoProd(String newSql, Object[] newParam) {
        sql = newSql;
        param = newParam;
    }

    public int getPersist() {
        return persist;
    }

    public void setPersist(int newPersist) {
        persist = newPersist;
    }

    public void resetUpdate() {
        Arrays.fill(updCol, -1);
    }

    public Object[] getParam() {
        return param;
    }

    public String getSQL() {
        return sql;
    }

    public HashSet getColNotInsertable() {
        return null;
    }

    public Integer getSppSptModeleCode() {
        return sppSptModeleCode;
    }

    public Integer getSppNoProto() {
        return sppNoProto;
    }

    public byte[] getSppCommentaires() {
        return sppCommentaires;
    }

    public Timestamp getSppDtEnvComment() {
        return sppDtEnvComment;
    }

    public Timestamp getSppDtRecepComment() {
        return sppDtRecepComment;
    }

    public Timestamp getSppDtRetourDde() {
        return sppDtRetourDde;
    }

    public Timestamp getSppDtEnvProto() {
        return sppDtEnvProto;
    }

    public Timestamp getSppDtRecepProto() {
        return sppDtRecepProto;
    }

    public Timestamp getSppDtDecOkProd() {
        return sppDtDecOkProd;
    }

    public String getSppDecOkProd() {
        return sppDecOkProd;
    }

    public void setSppSptModeleCode(Integer newSppSptModeleCode) {
        sppSptModeleCode = newSppSptModeleCode;
    }

    public void setSppNoProto(Integer newSppNoProto) {
        sppNoProto = newSppNoProto;
    }

    public void setSppCommentaires(byte[] newSppCommentaires) {
        sppCommentaires = newSppCommentaires;
        if (persist > 0)
            updCol[DosuiviProtoProdDesc.SPP_COMMENTAIRES] = 1;
    }

    public void setSppDtEnvComment(Timestamp newSppDtEnvComment) {
        sppDtEnvComment = newSppDtEnvComment;
        if (persist > 0)
            updCol[DosuiviProtoProdDesc.SPP_DT_ENV_COMMENT] = 1;
    }

    public void setSppDtRecepComment(Timestamp newSppDtRecepComment) {
        sppDtRecepComment = newSppDtRecepComment;
        if (persist > 0)
            updCol[DosuiviProtoProdDesc.SPP_DT_RECEP_COMMENT] = 1;
    }

    public void setSppDtRetourDde(Timestamp newSppDtRetourDde) {
        sppDtRetourDde = newSppDtRetourDde;
        if (persist > 0)
            updCol[DosuiviProtoProdDesc.SPP_DT_RETOUR_DDE] = 1;
    }

    public void setSppDtEnvProto(Timestamp newSppDtEnvProto) {
        sppDtEnvProto = newSppDtEnvProto;
        if (persist > 0)
            updCol[DosuiviProtoProdDesc.SPP_DT_ENV_PROTO] = 1;
    }

    public void setSppDtRecepProto(Timestamp newSppDtRecepProto) {
        sppDtRecepProto = newSppDtRecepProto;
        if (persist > 0)
            updCol[DosuiviProtoProdDesc.SPP_DT_RECEP_PROTO] = 1;
    }

    public void setSppDtDecOkProd(Timestamp newSppDtDecOkProd) {
        sppDtDecOkProd = newSppDtDecOkProd;
        if (persist > 0)
            updCol[DosuiviProtoProdDesc.SPP_DT_DEC_OK_PROD] = 1;
    }

    public void setSppDecOkProd(String newSppDecOkProd) {
        sppDecOkProd = newSppDecOkProd;
        if (persist > 0)
            updCol[DosuiviProtoProdDesc.SPP_DEC_OK_PROD] = 1;
    }

    public Object get(int numCol) {
        if (numCol == DosuiviProtoProdDesc.SPP_SPT_MODELE_CODE)
            return sppSptModeleCode;
        else if (numCol == DosuiviProtoProdDesc.SPP_NO_PROTO)
            return sppNoProto;
        else if (numCol == DosuiviProtoProdDesc.SPP_COMMENTAIRES)
            return sppCommentaires;
        else if (numCol == DosuiviProtoProdDesc.SPP_DT_ENV_COMMENT)
            return sppDtEnvComment;
        else if (numCol == DosuiviProtoProdDesc.SPP_DT_RECEP_COMMENT)
            return sppDtRecepComment;
        else if (numCol == DosuiviProtoProdDesc.SPP_DT_RETOUR_DDE)
            return sppDtRetourDde;
        else if (numCol == DosuiviProtoProdDesc.SPP_DT_ENV_PROTO)
            return sppDtEnvProto;
        else if (numCol == DosuiviProtoProdDesc.SPP_DT_RECEP_PROTO)
            return sppDtRecepProto;
        else if (numCol == DosuiviProtoProdDesc.SPP_DT_DEC_OK_PROD)
            return sppDtDecOkProd;
        else if (numCol == DosuiviProtoProdDesc.SPP_DEC_OK_PROD)
            return sppDecOkProd;
        return null;
    }

    public void set(int numCol, Object value) {
        if (numCol == DosuiviProtoProdDesc.SPP_SPT_MODELE_CODE) {
            sppSptModeleCode = (Integer) value;
        }
        if (numCol == DosuiviProtoProdDesc.SPP_NO_PROTO) {
            sppNoProto = (Integer) value;
        }
        if (numCol == DosuiviProtoProdDesc.SPP_COMMENTAIRES) {
            sppCommentaires = (byte[]) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoProdDesc.SPP_DT_ENV_COMMENT) {
            sppDtEnvComment = (Timestamp) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoProdDesc.SPP_DT_RECEP_COMMENT) {
            sppDtRecepComment = (Timestamp) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoProdDesc.SPP_DT_RETOUR_DDE) {
            sppDtRetourDde = (Timestamp) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoProdDesc.SPP_DT_ENV_PROTO) {
            sppDtEnvProto = (Timestamp) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoProdDesc.SPP_DT_RECEP_PROTO) {
            sppDtRecepProto = (Timestamp) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoProdDesc.SPP_DT_DEC_OK_PROD) {
            sppDtDecOkProd = (Timestamp) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
        if (numCol == DosuiviProtoProdDesc.SPP_DEC_OK_PROD) {
            sppDecOkProd = (String) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
    }

    public DataObject setProperty(SqlArg sqlArg) throws SQLException {
        return setProperty(sqlArg, new DosuiviProtoProd());
    }

    private DataObject setProperty(SqlArg sqlArg, DosuiviProtoProd djo) throws SQLException {
        ResultSet rs = sqlArg.getResultSet();
        int[] val = sqlArg.getVal();
        if (val[DosuiviProtoProdDesc.SPP_SPT_MODELE_CODE] != -1) {
            int temp = rs.getInt(val[DosuiviProtoProdDesc.SPP_SPT_MODELE_CODE]);
            if (!rs.wasNull())
                djo.sppSptModeleCode = new Integer(temp);
        }
        if (val[DosuiviProtoProdDesc.SPP_NO_PROTO] != -1) {
            int temp = rs.getInt(val[DosuiviProtoProdDesc.SPP_NO_PROTO]);
            if (!rs.wasNull())
                djo.sppNoProto = new Integer(temp);
        }
        if (val[DosuiviProtoProdDesc.SPP_COMMENTAIRES] != -1) {
        }
        if (val[DosuiviProtoProdDesc.SPP_DT_ENV_COMMENT] != -1) {
            djo.sppDtEnvComment = rs.getTimestamp(val[DosuiviProtoProdDesc.SPP_DT_ENV_COMMENT]);
        }
        if (val[DosuiviProtoProdDesc.SPP_DT_RECEP_COMMENT] != -1) {
            djo.sppDtRecepComment = rs.getTimestamp(val[DosuiviProtoProdDesc.SPP_DT_RECEP_COMMENT]);
        }
        if (val[DosuiviProtoProdDesc.SPP_DT_RETOUR_DDE] != -1) {
            djo.sppDtRetourDde = rs.getTimestamp(val[DosuiviProtoProdDesc.SPP_DT_RETOUR_DDE]);
        }
        if (val[DosuiviProtoProdDesc.SPP_DT_ENV_PROTO] != -1) {
            djo.sppDtEnvProto = rs.getTimestamp(val[DosuiviProtoProdDesc.SPP_DT_ENV_PROTO]);
        }
        if (val[DosuiviProtoProdDesc.SPP_DT_RECEP_PROTO] != -1) {
            djo.sppDtRecepProto = rs.getTimestamp(val[DosuiviProtoProdDesc.SPP_DT_RECEP_PROTO]);
        }
        if (val[DosuiviProtoProdDesc.SPP_DT_DEC_OK_PROD] != -1) {
            djo.sppDtDecOkProd = rs.getTimestamp(val[DosuiviProtoProdDesc.SPP_DT_DEC_OK_PROD]);
        }
        if (val[DosuiviProtoProdDesc.SPP_DEC_OK_PROD] != -1) {
            djo.sppDecOkProd = rs.getString(val[DosuiviProtoProdDesc.SPP_DEC_OK_PROD]);
        }
        return djo;
    }

    public void getProperty(SqlArg sqlArg) throws SQLException {
        PreparedStatement stmt = sqlArg.getStmt();
        int[] val = sqlArg.getVal();
        if (val[DosuiviProtoProdDesc.SPP_SPT_MODELE_CODE] > 0) {
            if (sppSptModeleCode == null)
                stmt.setNull(val[DosuiviProtoProdDesc.SPP_SPT_MODELE_CODE], 3);
            else
                stmt.setInt(val[DosuiviProtoProdDesc.SPP_SPT_MODELE_CODE], sppSptModeleCode.intValue());
        }
        if (val[DosuiviProtoProdDesc.SPP_NO_PROTO] > 0) {
            if (sppNoProto == null)
                stmt.setNull(val[DosuiviProtoProdDesc.SPP_NO_PROTO], 3);
            else
                stmt.setInt(val[DosuiviProtoProdDesc.SPP_NO_PROTO], sppNoProto.intValue());
        }
        if (val[DosuiviProtoProdDesc.SPP_COMMENTAIRES] > 0) {
            stmt.setObject(val[DosuiviProtoProdDesc.SPP_COMMENTAIRES], sppCommentaires);
        }
        if (val[DosuiviProtoProdDesc.SPP_DT_ENV_COMMENT] > 0) {
            stmt.setTimestamp(val[DosuiviProtoProdDesc.SPP_DT_ENV_COMMENT], sppDtEnvComment);
        }
        if (val[DosuiviProtoProdDesc.SPP_DT_RECEP_COMMENT] > 0) {
            stmt.setTimestamp(val[DosuiviProtoProdDesc.SPP_DT_RECEP_COMMENT], sppDtRecepComment);
        }
        if (val[DosuiviProtoProdDesc.SPP_DT_RETOUR_DDE] > 0) {
            stmt.setTimestamp(val[DosuiviProtoProdDesc.SPP_DT_RETOUR_DDE], sppDtRetourDde);
        }
        if (val[DosuiviProtoProdDesc.SPP_DT_ENV_PROTO] > 0) {
            stmt.setTimestamp(val[DosuiviProtoProdDesc.SPP_DT_ENV_PROTO], sppDtEnvProto);
        }
        if (val[DosuiviProtoProdDesc.SPP_DT_RECEP_PROTO] > 0) {
            stmt.setTimestamp(val[DosuiviProtoProdDesc.SPP_DT_RECEP_PROTO], sppDtRecepProto);
        }
        if (val[DosuiviProtoProdDesc.SPP_DT_DEC_OK_PROD] > 0) {
            stmt.setTimestamp(val[DosuiviProtoProdDesc.SPP_DT_DEC_OK_PROD], sppDtDecOkProd);
        }
        if (val[DosuiviProtoProdDesc.SPP_DEC_OK_PROD] > 0) {
            stmt.setString(val[DosuiviProtoProdDesc.SPP_DEC_OK_PROD], sppDecOkProd);
        }
    }

    /**
     * M�thode g�n�r�e automatiquement permettant de remplir un dataobject � partir des valeurs
     * d'une requ�te http.
     * Les noms des param�tres de la requ�te doivent �tre strictement identique aux noms des attributs du DataObject.
     * Cette m�thode peut �tre compl�t�e afin de prendre en compte d'�ventuels param�tres se trouvant en session.
     * Pour une reg�n�ration �ventuelle, faites attention � ne coder qu'entre les tags de d�but et de fin.
     * Date de cr�ation : (25/05/01 08:03:14)
     *
     * @param request javax.servlet.http.HttpServletRequest
     */
    public DataObject[] setParameters(HttpServletRequest request)
            throws ParameterException, java.text.ParseException {
        String[] params = null;
        String localVal = null;
        int size = 0;
        DosuiviProtoProd[] result = null;
        params = request.getParameterValues("sppSptModeleCode");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoProd[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoProd();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSppSptModeleCode((Integer) StrConvertor.convert(localVal, Integer.class));
            }
        }
        params = request.getParameterValues("sppNoProto");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoProd[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoProd();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSppNoProto((Integer) StrConvertor.convert(localVal, Integer.class));
            }
        }
        params = request.getParameterValues("sppCommentaires");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoProd[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoProd();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSppCommentaires((byte[]) StrConvertor.convert(localVal, byte[].class));
            }
        }
        params = request.getParameterValues("sppDtEnvComment");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoProd[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoProd();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSppDtEnvComment((Timestamp) StrConvertor.convert(localVal, Timestamp.class));
            }
        }
        params = request.getParameterValues("sppDtRecepComment");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoProd[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoProd();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSppDtRecepComment((Timestamp) StrConvertor.convert(localVal, Timestamp.class));
            }
        }
        params = request.getParameterValues("sppDtRetourDde");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoProd[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoProd();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSppDtRetourDde((Timestamp) StrConvertor.convert(localVal, Timestamp.class));
            }
        }
        params = request.getParameterValues("sppDtEnvProto");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoProd[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoProd();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSppDtEnvProto((Timestamp) StrConvertor.convert(localVal, Timestamp.class));
            }
        }
        params = request.getParameterValues("sppDtRecepProto");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoProd[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoProd();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSppDtRecepProto((Timestamp) StrConvertor.convert(localVal, Timestamp.class));
            }
        }
        params = request.getParameterValues("sppDtDecOkProd");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoProd[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoProd();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSppDtDecOkProd((Timestamp) StrConvertor.convert(localVal, Timestamp.class));
            }
        }
        params = request.getParameterValues("sppDecOkProd");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DosuiviProtoProd[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DosuiviProtoProd();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setSppDecOkProd(localVal);
            }
        }
        /************************ INSTRUCTIONS DEVELOPPEMENT SPECIFIQUE *******************/
        /********************** FIN INSTRUCTIONS DEVELOPPEMENT SPECIFIQUE *****************/
        return result;
    }

    /*
     * @see DataObject#addChild(DataObject)
     */
    public void addChild(DataObject doChild) {
    }

    /*
     * @see DataObject#getDescription()
     */
    public IDoDescription getDescription() {
        return description;
    }

    /*
     * @see DataObject#getUpdateCol()
     */
    public int[] getUpdateCol() {
        return updCol;
    }

}
