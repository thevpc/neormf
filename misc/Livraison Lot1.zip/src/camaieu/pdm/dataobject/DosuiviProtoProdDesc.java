package camaieu.pdm.dataobject;

import wg4.fwk.dataobject.IDoDescription;

import java.util.HashMap;

/**
 * /* Description de l'objetDosuiviProtoProd correspondant � la table SUIVI_PROTO_PROD
 */
public class DosuiviProtoProdDesc implements IDoDescription {
    public static final int SPP_SPT_MODELE_CODE = 0;
    public static final int SPP_NO_PROTO = 1;
    public static final int SPP_COMMENTAIRES = 2;
    public static final int SPP_DT_ENV_COMMENT = 3;
    public static final int SPP_DT_RECEP_COMMENT = 4;
    public static final int SPP_DT_RETOUR_DDE = 5;
    public static final int SPP_DT_ENV_PROTO = 6;
    public static final int SPP_DT_RECEP_PROTO = 7;
    public static final int SPP_DT_DEC_OK_PROD = 8;
    public static final int SPP_DEC_OK_PROD = 9;

    public static final String tableName = "SUIVI_PROTO_PROD";

    /*
     * Liste des noms de colonnes
     */
    public static final String[] dbColName = new String[]{
        "SPP_SPT_MODELE_CODE", "SPP_NO_PROTO", "SPP_COMMENTAIRES", "SPP_DT_ENV_COMMENT", "SPP_DT_RECEP_COMMENT", "SPP_DT_RETOUR_DDE", "SPP_DT_ENV_PROTO", "SPP_DT_RECEP_PROTO", "SPP_DT_DEC_OK_PROD", "SPP_DEC_OK_PROD"};
    private static final HashMap colBase;

    static {
        colBase = new HashMap(10);
        colBase.put("SPP_SPT_MODELE_CODE", new Integer(SPP_SPT_MODELE_CODE));
        colBase.put("SPP_NO_PROTO", new Integer(SPP_NO_PROTO));
        colBase.put("SPP_COMMENTAIRES", new Integer(SPP_COMMENTAIRES));
        colBase.put("SPP_DT_ENV_COMMENT", new Integer(SPP_DT_ENV_COMMENT));
        colBase.put("SPP_DT_RECEP_COMMENT", new Integer(SPP_DT_RECEP_COMMENT));
        colBase.put("SPP_DT_RETOUR_DDE", new Integer(SPP_DT_RETOUR_DDE));
        colBase.put("SPP_DT_ENV_PROTO", new Integer(SPP_DT_ENV_PROTO));
        colBase.put("SPP_DT_RECEP_PROTO", new Integer(SPP_DT_RECEP_PROTO));
        colBase.put("SPP_DT_DEC_OK_PROD", new Integer(SPP_DT_DEC_OK_PROD));
        colBase.put("SPP_DEC_OK_PROD", new Integer(SPP_DEC_OK_PROD));
    }

    /*
     * Noms de colonnes de la cl� primaire
     */
    private static final String[] pkColName = new String[]{
        "SPP_SPT_MODELE_CODE", "SPP_NO_PROTO"};

    private static final int[] pkColNum = new int[]{0, 1};

    private static final HashMap fkColName = new HashMap(1);

    static {
        fkColName.put("SUIVI_PROTO_TETE", new String[]{
            "SPP_SPT_MODELE_CODE"
        });
    }


    private static final HashMap fkColNum = new HashMap(1);

    static {
        fkColNum.put("SUIVI_PROTO_TETE", new int[]{
            0
        });
    }

    /**
     * @see IDoDescription.getTableName()
     */
    public String getTableName() {
        return tableName;
    }

    /**
     * @see IDoDescription.getDbColName()
     */
    public String[] getDbColName() {
        return dbColName;
    }

    /**
     * @see IDoDescription.getDbColNum()
     */
    public HashMap getDbColNum() {
        return colBase;
    }

    /**
     * @see IDoDescription.getPkColName()
     */
    public String[] getPkColName() {
        return pkColName;
    }

    /**
     * @see IDoDescription.getPkColNum()
     */
    public int[] getPkColNum() {
        return pkColNum;
    }
    /**
     * @see IDoDescription.getPkColNumInsert()
     */
    /**
     * @see IDoDescription.getFkColName()
     */
    public String[] getFkColName(String tableName) {
        return (String[]) fkColName.get(tableName);
    }

    /**
     * @see IDoDescription.getFkColNum()
     */
    public int[] getFkColNum(String tableName) {
        return (int[]) fkColNum.get(tableName);
    }
}
