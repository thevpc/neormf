package camaieu.pdm.dataobject;

import wg4.fwk.dataobject.DataObject;
import wg4.fwk.dataobject.IDoDescription;
import wg4.fwk.dataobject.ParameterException;
import wg4.fwk.dataobject.SqlArg;
import wg4.fwk.mvc.tool.StrConvertor;

import javax.servlet.http.HttpServletRequest;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.HashSet;

public class DoDelais implements DataObject {

    private static final IDoDescription description = new DoDelaisDesc();
    private transient int persist = PERSIST_UPDATE_INSERT;
    private transient int[] updCol = new int[2];
    private transient String sql;
    private transient Object[] param;

//tables correspondantes
    private static final String[] tableNames = new String[]{"DELAIS"};
    //variables correspondant � la table DELAIS
    private String delPayCode = null;
    private Integer delValeur = null;

    /**
     * Constructeur utilis� par la m�thode setPropertie
     */
    public DoDelais() {
    }

    /**
     * Constructeur permettant d'initialiser le type de persistance
     */
    public DoDelais(int persistTyp) {
        persist = persistTyp;
    }

    /**
     * Constructeur permettant d'initialiser le type de persistance
     */
    public DoDelais(DoDelais arg) {
        setDelPayCode(arg.delPayCode);
        setDelValeur(arg.delValeur);
    }

    /**
     * Constructeur utilis� par la m�thode retrieve
     */
    public DoDelais(String newSql, Object[] newParam) {
        sql = newSql;
        param = newParam;
    }

    public int getPersist() {
        return persist;
    }

    public void setPersist(int newPersist) {
        persist = newPersist;
    }

    public void resetUpdate() {
        Arrays.fill(updCol, -1);
    }

    public Object[] getParam() {
        return param;
    }

    public String getSQL() {
        return sql;
    }

    public HashSet getColNotInsertable() {
        return null;
    }

    public String getDelPayCode() {
        return delPayCode;
    }

    public Integer getDelValeur() {
        return delValeur;
    }

    public void setDelPayCode(String newDelPayCode) {
        delPayCode = newDelPayCode;
    }

    public void setDelValeur(Integer newDelValeur) {
        delValeur = newDelValeur;
        if (persist > 0)
            updCol[DoDelaisDesc.DEL_VALEUR] = 1;
    }

    public Object get(int numCol) {
        if (numCol == DoDelaisDesc.DEL_PAY_CODE)
            return delPayCode;
        else if (numCol == DoDelaisDesc.DEL_VALEUR)
            return delValeur;
        return null;
    }

    public void set(int numCol, Object value) {
        if (numCol == DoDelaisDesc.DEL_PAY_CODE) {
            delPayCode = (String) value;
        }
        if (numCol == DoDelaisDesc.DEL_VALEUR) {
            delValeur = (Integer) value;
            if (persist > 0)
                updCol[numCol] = 1;
        }
    }

    public DataObject setProperty(SqlArg sqlArg) throws SQLException {
        return setProperty(sqlArg, new DoDelais());
    }

    private DataObject setProperty(SqlArg sqlArg, DoDelais djo) throws SQLException {
        ResultSet rs = sqlArg.getResultSet();
        int[] val = sqlArg.getVal();
        if (val[DoDelaisDesc.DEL_PAY_CODE] != -1) {
            djo.delPayCode = rs.getString(val[DoDelaisDesc.DEL_PAY_CODE]);
        }
        if (val[DoDelaisDesc.DEL_VALEUR] != -1) {
            int temp = rs.getInt(val[DoDelaisDesc.DEL_VALEUR]);
            if (!rs.wasNull())
                djo.delValeur = new Integer(temp);
        }
        return djo;
    }

    public void getProperty(SqlArg sqlArg) throws SQLException {
        PreparedStatement stmt = sqlArg.getStmt();
        int[] val = sqlArg.getVal();
        if (val[DoDelaisDesc.DEL_PAY_CODE] > 0) {
            stmt.setString(val[DoDelaisDesc.DEL_PAY_CODE], delPayCode);
        }
        if (val[DoDelaisDesc.DEL_VALEUR] > 0) {
            if (delValeur == null)
                stmt.setNull(val[DoDelaisDesc.DEL_VALEUR], 3);
            else
                stmt.setInt(val[DoDelaisDesc.DEL_VALEUR], delValeur.intValue());
        }
    }

    /**
     * M�thode g�n�r�e automatiquement permettant de remplir un dataobject � partir des valeurs
     * d'une requ�te http.
     * Les noms des param�tres de la requ�te doivent �tre strictement identique aux noms des attributs du DataObject.
     * Cette m�thode peut �tre compl�t�e afin de prendre en compte d'�ventuels param�tres se trouvant en session.
     * Pour une reg�n�ration �ventuelle, faites attention � ne coder qu'entre les tags de d�but et de fin.
     * Date de cr�ation : (25/05/01 08:03:14)
     *
     * @param request javax.servlet.http.HttpServletRequest
     */
    public DataObject[] setParameters(HttpServletRequest request)
            throws ParameterException, java.text.ParseException {
        String[] params = null;
        String localVal = null;
        int size = 0;
        DoDelais[] result = null;
        params = request.getParameterValues("delPayCode");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoDelais[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoDelais();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setDelPayCode(localVal);
            }
        }
        params = request.getParameterValues("delValeur");
        if (params != null) {
            if (result == null) {
                size = params.length;
                result = new DoDelais[size];
                for (int i = 0; i < size; i++) {
                    result[i] = new DoDelais();
                }
            }
            for (int i = 0; i < size; i++) {
                if (params.length == 1)
                    localVal = params[0];
                else
                    localVal = params[i];
                result[i].setDelValeur((Integer) StrConvertor.convert(localVal, Integer.class));
            }
        }
        /************************ INSTRUCTIONS DEVELOPPEMENT SPECIFIQUE *******************/
        /********************** FIN INSTRUCTIONS DEVELOPPEMENT SPECIFIQUE *****************/
        return result;
    }

    /*
     * @see DataObject#addChild(DataObject)
     */
    public void addChild(DataObject doChild) {
    }

    /*
     * @see DataObject#getDescription()
     */
    public IDoDescription getDescription() {
        return description;
    }

    /*
     * @see DataObject#getUpdateCol()
     */
    public int[] getUpdateCol() {
        return updCol;
    }

}
