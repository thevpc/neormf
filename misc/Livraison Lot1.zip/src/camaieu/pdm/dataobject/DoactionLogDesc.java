package camaieu.pdm.dataobject;

import wg4.fwk.dataobject.IDoDescription;

import java.util.HashMap;

/**
 * /* Description de l'objetDoactionLog correspondant � la table ACTION_LOG
 */
public class DoactionLogDesc implements IDoDescription {
    public static final int ACT_FOU_CODE = 0;
    public static final int ACT_FIC_CHAMP = 1;
    public static final int ACT_FIC_VERSION = 2;
    public static final int ACT_FIC_SPT_MODELE_CODE = 3;
    public static final int ACT_DATE = 4;

    public static final String tableName = "ACTION_LOG";

    /*
     * Liste des noms de colonnes
     */
    public static final String[] dbColName = new String[]{
        "ACT_FOU_CODE", "ACT_FIC_CHAMP", "ACT_FIC_VERSION", "ACT_FIC_SPT_MODELE_CODE", "ACT_DATE"};
    private static final HashMap colBase;

    static {
        colBase = new HashMap(5);
        colBase.put("ACT_FOU_CODE", new Integer(ACT_FOU_CODE));
        colBase.put("ACT_FIC_CHAMP", new Integer(ACT_FIC_CHAMP));
        colBase.put("ACT_FIC_VERSION", new Integer(ACT_FIC_VERSION));
        colBase.put("ACT_FIC_SPT_MODELE_CODE", new Integer(ACT_FIC_SPT_MODELE_CODE));
        colBase.put("ACT_DATE", new Integer(ACT_DATE));
    }

    /*
     * Noms de colonnes de la cl� primaire
     */
    private static final String[] pkColName = new String[]{
    };

    private static final int[] pkColNum = new int[]{};

    private static final HashMap fkColName = new HashMap(1);

    static {
        fkColName.put("FICHIERS", new String[]{
            "ACT_FIC_CHAMP", "ACT_FIC_VERSION", "ACT_FIC_SPT_MODELE_CODE"
        });
    }


    private static final HashMap fkColNum = new HashMap(1);

    static {
        fkColNum.put("FICHIERS", new int[]{
            1, 2, 3
        });
    }

    /**
     * @see IDoDescription.getTableName()
     */
    public String getTableName() {
        return tableName;
    }

    /**
     * @see IDoDescription.getDbColName()
     */
    public String[] getDbColName() {
        return dbColName;
    }

    /**
     * @see IDoDescription.getDbColNum()
     */
    public HashMap getDbColNum() {
        return colBase;
    }

    /**
     * @see IDoDescription.getPkColName()
     */
    public String[] getPkColName() {
        return pkColName;
    }

    /**
     * @see IDoDescription.getPkColNum()
     */
    public int[] getPkColNum() {
        return pkColNum;
    }
    /**
     * @see IDoDescription.getPkColNumInsert()
     */
    /**
     * @see IDoDescription.getFkColName()
     */
    public String[] getFkColName(String tableName) {
        return (String[]) fkColName.get(tableName);
    }

    /**
     * @see IDoDescription.getFkColNum()
     */
    public int[] getFkColNum(String tableName) {
        return (int[]) fkColNum.get(tableName);
    }
}
