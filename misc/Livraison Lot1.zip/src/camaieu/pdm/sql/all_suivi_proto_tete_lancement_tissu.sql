------------------------------------------
-- @author taha BEN SALAH (ADD'IT Tunisie)
-- @creation_date 01/08/2004
------------------------------------------
------------------------------------
----Lancement commande de tissu
------------------------------------
-- COMMANDE COMPOSANT NON LIVREE
select
	max(cas_dt_even)
from
	dt_cmde_achat_hist hist1,
	dt_cmde_achat_tete
where
	cas_eve_code = 'EX'
	and cas_cat_dep_code = cat_dep_code
	and cas_cat_dep_soc_code = cat_dep_soc_code
	and cas_cat_no_cmde = cat_no_cmde
	and cas_cat_no_version = cat_no_version
	and cat_mod_code = ?
	and (select count(1) from dt_cmde_achat_hist hist2 where hist2.cas_eve_code = 'ALA'
	                                                    and hist2.cas_dt_even > hist1.cas_dt_even
	                                                    and hist2.cas_cat_no_cmde = cat_no_cmde
	                                                    and hist2.cas_cat_dep_code = cat_dep_code
	                                                    and hist2.cas_cat_dep_soc_code = cat_dep_soc_code
	                                                    and cas_cat_no_version = cat_no_version) = 0
order by cas_dt_even desc
