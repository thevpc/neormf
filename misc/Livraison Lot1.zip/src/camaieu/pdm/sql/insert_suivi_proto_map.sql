insert into suivi_proto_map (SPM_SPT_MODELE_CODE,SPM_NO_PROTO) values(?,?)
