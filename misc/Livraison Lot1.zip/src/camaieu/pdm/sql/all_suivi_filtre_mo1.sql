------------------------------------------
-- @author taha BEN SALAH (ADD'IT Tunisie)
-- @creation_date 01/08/2004
------------------------------------------
SPT_DT_ENV_FTECH_BUR is NULL or SPT_DT_ENV_CT_BUR is NULL