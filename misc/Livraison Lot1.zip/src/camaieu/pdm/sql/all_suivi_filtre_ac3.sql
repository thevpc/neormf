------------------------------------------
-- @author taha BEN SALAH (ADD'IT Tunisie)
-- @creation_date 01/08/2004
------------------------------------------
SPM_DT_RECEP_PROTO is NULL OR SPP_DT_RECEP_PROTO is NULL