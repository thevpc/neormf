------------------------------------------
-- @author taha BEN SALAH (ADD'IT Tunisie)
-- @creation_date 01/08/2004
------------------------------------------
(SPM_DECISION_OK_MAP is NULL AND (SPT_DT_ENV_FTECH_BUR is NULL OR SPT_DT_ENV_CT_BUR is NULL)) OR (SPP_DEC_OK_PROD is NULL AND (SPT_DT_ENV_FTECH_FAC is NULL OR SPT_DT_ENV_CT_FAC is NULL or SPT_DT_ENV_PATRONAGE is NULL))