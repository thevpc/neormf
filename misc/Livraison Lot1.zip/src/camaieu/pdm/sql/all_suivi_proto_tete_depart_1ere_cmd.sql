------------------------------------------
-- @author taha BEN SALAH (ADD'IT Tunisie)
-- @creation_date 01/08/2004
------------------------------------------
select
	cam_art_code, cat_no_cmde, cat_dt_depart1
from
	dt_cmde_achat_tete cat, dt_cmde_achat_mc cam, xn_modele mod
where
	mod.mod_code = ? and
	cam.cam_art_var1 <> '-' and
	cam.cam_art_code = mod.mod_code and
	cam.cam_cat_dep_code = cat.cat_dep_code and
	cam.cam_cat_dep_soc_code = cat.cat_dep_soc_code and
	cam.cam_cat_no_cmde = cat.cat_no_cmde and
	cam.cam_cat_no_version = cat.cat_no_version and
	cat_no_cmde = (select min(cam2.cam_cat_no_cmde) from dt_cmde_achat_mc cam2 where cam2.cam_art_code = cam.cam_art_code)
order by CAT_DT_CMDE