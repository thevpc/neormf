------------------------------------------
-- @author taha BEN SALAH (ADD'IT Tunisie)
-- @creation_date 01/08/2004
------------------------------------------
SPM_DECISION_OK_MAP is NULL