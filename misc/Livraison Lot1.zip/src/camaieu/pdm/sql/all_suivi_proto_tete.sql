------------------------------------------
-- @author taha BEN SALAH (ADD'IT Tunisie)
-- @creation_date 01/08/2004
------------------------------------------
---
--- Tous les enregistrements de type suivi
---
SELECT
    SPT_MODELE_CODE,
    SPT_REF_NODHOS,
    SPT_NOM_MODELE,
    SPT_FAA_CODE ,
    SPT_CLT_CODE,
    SPT_QUALITE ,
    SPT_BUREAU_CODE ,
    SPT_FAC_CODE ,
    SPT_FOU_CODE_TISSU ,
    SPT_LAVAGE ,
    SPT_BUREAU_TYPE,
    SPT_DT_TRANSMISSION ,
    SPT_ENV_CTYPE_ESSAI_MAT,
    SPT_DT_ENV_FTECH_BUR ,
    SPT_DT_ENV_CT_BUR ,
    SPT_DT_RECEP_FTECH_BUR ,
    SPT_DT_RECEP_CT_BUR ,
    SPT_PRIX_FACON ,
    SPT_EMP_PROVISOIRE,
    SPT_DT_ENV_FTECH_FAC,
    SPT_DT_ENV_CT_FAC ,
    SPT_RECEP_DISQ_PAT,
    SPT_DT_ENV_PATRONAGE,
    SPT_COMMENT_ACHATS,
    SPT_COMMENT_MODELISTE,
    SPT_COMMENT_BUREAU,
    SPT_CLT_AN,
    SPT_CLT_SAI_CODE,
    SPT_DT_RECEP_FTECH_FAC ,
    SPT_DT_RECEP_CT_FAC ,
    SPT_DDE_TETE_SERIE ,
    SPT_TETE_SERIE ,
    SPT_OK_ACCESSOIRES ,
    SPT_OK_COLORIS ,
    SPT_EMPLOI_DEF ,
    SPT_OK_PROD_ENTREP ,
    SPT_OK_MATIERE ,
    SPT_VALID_ECHAN_SOURCE,
    SPP_DT_RETOUR_DDE ,
    SPP_DT_RECEP_PROTO ,
    SPP_DT_DEC_OK_PROD,
    SPP_NO_PROTO,
    SPP_DT_ENV_PROTO,
    SPP_DEC_OK_PROD,
    SPM_DT_ENV_COMMENT ,
    SPM_DT_RECEP_COMMENT ,
    SPM_DT_ENV_PROTO
    SPM_DT_RETOUR_DDE,
    SPM_NO_PROTO,
    SPM_DT_RECEP_PROTO,
    SPM_DT_REUNION_PROD,
    SPM_DECISION_OK_MAP ,
    SPM_DT_DECISION_OK_MAP
FROM SUIVI_PROTO_TETE , SUIVI_PROTO_MAP,SUIVI_PROTO_PROD
where
SPT_MODELE_CODE=SPP_SPT_MODELE_CODE (+)  and
SPT_MODELE_CODE=SPM_SPT_MODELE_CODE (+) and
SPT_STATUS='O' and
nvl(SPM_NO_PROTO,-9999) = nvl((select max(SPM_NO_PROTO) from suivi_proto_map where spm_spt_modele_code=spt_modele_code),-9999)
and nvl(SPP_NO_PROTO,-9999) =nvl((select max(SPP_NO_PROTO) from suivi_proto_prod where spp_spt_modele_code=spt_modele_code), -9999)