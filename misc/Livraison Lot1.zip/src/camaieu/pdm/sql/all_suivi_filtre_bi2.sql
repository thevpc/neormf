------------------------------------------
-- @author taha BEN SALAH (ADD'IT Tunisie)
-- @creation_date 01/08/2004
------------------------------------------
(SPM_DT_ENV_COMMENT IS NULL AND SPM_NO_PROTO > 1 AND SPM_DECISION_OK_MAP is NULL) OR (SPP_DT_ENV_COMMENT IS NULL AND SPP_NO_PROTO > 1 AND SPP_DEC_OK_PROD is NULL)