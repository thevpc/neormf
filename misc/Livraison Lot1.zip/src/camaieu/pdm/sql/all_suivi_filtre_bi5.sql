------------------------------------------
-- @author taha BEN SALAH (ADD'IT Tunisie)
-- @creation_date 01/08/2004
------------------------------------------
SPP_DEC_OK_PROD = 'A'