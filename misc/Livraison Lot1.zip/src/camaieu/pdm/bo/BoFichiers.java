package camaieu.pdm.bo;

import camaieu.common.BoEasyAncestorBean;
import camaieu.common.Bug;
import camaieu.common.IOUtils;
import camaieu.pdm.common.PDMBusinessConstants;
import camaieu.pdm.common.PDMUtils;
import camaieu.pdm.dataobject.DoFichiers;
import wg4.bean.ancestor.TechniqueException;
import wg4.fwk.dataobject.DataObject;

import java.io.File;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;

/**
 * @author tijani Souissi (ADD'IT Tunisie)
 * @creation_date date 21/01/2004
 * @last_modification_date 28/07/2004
 * @last_modification_date 28/07/2004
 * @status pour validation
 */
public class BoFichiers extends BoEasyAncestorBean {
    /**
     *
     */
    public BoFichiers() {
        super(DoFichiers.class, PDMBusinessConstants.DATASOURCE_PDM);

    }

    /**
     * liste de fichiers
     *
     * @param modele
     * @param version
     * @return
     */
    public DoFichiers[] getModeleFiles(Integer modele, Integer version) {
        try {
            StringBuffer w = new StringBuffer("Select FIC_CHAMP,FIC_VERSION,FIC_SPT_MODELE_CODE,FIC_EXTENSION,FIC_DATE from FICHIERS where 1=1");
            ArrayList p = new ArrayList();

            if (modele != null) {
                w.append(" AND fic_spt_modele_code=?");
                p.add(modele);
            }
            if (modele != null) {
                w.append(" AND fic_version=?");
                p.add(version);
            }
            DataObject[][] all = (DataObject[][]) retrieve(getDefaultDatasourceName(),
                    w.toString(),
                    p.toArray(),
                    new Class[]{DoFichiers.class});
            return (DoFichiers[]) all[0];

        } catch (TechniqueException e) {
            throw new Bug(e);

        }
    }

    /**
     * liste des mod�les de ficheirs
     *
     * @param modele
     * @return
     */
    public DoFichiers[] getModeleFiles(String modele) {
        try {
            DoFichiers[] all = (DoFichiers[]) retrieveAll(getDefaultDatasourceName(),
                    new String[]{"FIC_CHAMP", "FIC_VERSION", "FIC_SPT_MODELE_CODE", "FIC_EXTENSION", "FIC_DATE"}, null, "FIC_SPT_MODELE_CODE=" + modele, null);
            return all;

        } catch (TechniqueException e) {
            throw new Bug(e);

        }
    }

    /**
     * chargement d'un fichier
     *
     * @param ficchamp
     * @param ficversion
     * @param ficmodeleid
     * @return
     * @throws TechniqueException
     */
    public DoFichiers loadFichier(String ficchamp, int ficversion, int ficmodeleid) throws TechniqueException {
        String q = "select FIC_FICHIER,FIC_EXTENSION,FIC_DATE from FICHIERS where FIC_CHAMP=? and FIC_VERSION=? and FIC_SPT_MODELE_CODE=?";
        try {
            PreparedStatement ps = getConnection().prepareStatement(q);
            ps.setString(1, ficchamp);
            ps.setInt(2, ficversion);
            ps.setInt(3, ficmodeleid);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                DoFichiers doFichiers = new DoFichiers();
                doFichiers.setFicChamp(ficchamp);
                doFichiers.setFicFichier(rs.getBytes(1));
                doFichiers.setFicExtension(rs.getString(2));
                doFichiers.setFicSptModeleCode(new Integer(ficmodeleid));
                doFichiers.setFicVersion(new Integer(ficversion));
                doFichiers.setFicDate(rs.getTimestamp(3));
                return doFichiers;
            }
            return null;
        } catch (SQLException e) {
            throw new Bug(e);
        }
    }

    public int getLastVersion(String modele, String ficChamp) {
        DoFichiers[] files = getModeleFiles(modele);
        int max = 0;
        for (int i = 0; i < files.length; i++) {
            if (files[i].getFicVersion().intValue() > max && files[i].getFicChamp().equals(ficChamp)) {
                max = files[i].getFicVersion().intValue();
            }
        }
        return max;
    }

    public void doUploadFiles(File ftech,
                              File bmens,
                              File patronnage,
                              File nomenclature,
                              Integer modeleid) throws SQLException, IOException, TechniqueException {
        Date d = new Date(System.currentTimeMillis());
        uploadFile(ftech, "SPT_FICHE_TECHNIQUE", modeleid, d);
        uploadFile(bmens, "SPT_BAREME_MENSU", modeleid, d);
        uploadFile(patronnage, "SPT_PATRONAGE", modeleid, d);
        uploadFile(nomenclature, "SPT_NOMENCLATURE", modeleid, d);


    }

    /**
     * enregistrement d'un fichier
     *
     * @param f
     * @param ch
     * @param modelecode
     * @param date
     * @throws SQLException
     * @throws IOException
     * @throws TechniqueException
     */
    private void uploadFile(File f, String ch, Integer modelecode, Date date) throws SQLException, IOException, TechniqueException {

        String q = " insert into  FICHIERS " +
                " (FIC_CHAMP,FIC_VERSION,FIC_SPT_MODELE_CODE,FIC_EXTENSION,FIC_FICHIER,FIC_DATE) " +
                " values (?,?,?,?,?,?) ";
        Connection c = null;
        try {
            c = getConnection();
            if (f != null) {
                String ext = IOUtils.getFileExtension(f).toLowerCase();
                PreparedStatement ps = getConnection().prepareStatement(q);
                ps.setString(1, ch); //fic_champ
                BoFichiers ff = new BoFichiers();
                ps.setInt(2, ff.getLastVersion(modelecode.toString(), ch) + 1); //version
                ps.setInt(3, modelecode.intValue()); //modele code
                ps.setString(4, ext); //fic_extension
                PDMUtils.populateBlob(ps, 5, f);
                ps.setDate(6, date);
                ps.executeUpdate();
                ps.close();
            }
        } finally {
            if (c != null) {
                c.close();
            }
        }

    }

    public void deleteFile(String champ, Integer version, Integer modele) throws SQLException, IOException, TechniqueException {
        DoFichiers fichier = new DoFichiers();
        fichier.setFicChamp(champ);
        fichier.setFicVersion(version);
        fichier.setFicSptModeleCode(modele);
        fichier.setPersist(DataObject.PERSIST_DELETE);
        try {
            persist(getDefaultDatasourceName(), new DataObject[]{fichier}, true);
        } catch (TechniqueException e) {
        }
    }
}
