package camaieu.pdm.bo;

import camaieu.common.BoEasyAncestorBean;
import camaieu.common.Bug;
import camaieu.pdm.common.MapParametres;
import camaieu.pdm.common.PDMBusinessConstants;
import camaieu.pdm.dataobject.DoParametres;
import wg4.bean.ancestor.TechniqueException;

import java.util.HashMap;

/**
 * @author tijani Souissi (ADD'IT Tunisie)
 * @creation_date date 21/01/2004
 * @last_modification_date 28/07/2004
 * @last_modification_date 28/07/2004
 * @status pour validation
 */
public class BoParametres extends BoEasyAncestorBean {

    /**
     *
     */
    public BoParametres() {
        super(DoParametres.class, PDMBusinessConstants.DATASOURCE_PDM);

    }

    /**
     * liste de param�tres
     *
     * @return
     */
    public MapParametres getAllParametres() {
        try {
            DoParametres[] all = (DoParametres[]) retrieveAll(getDefaultDatasourceName(),
                    null, null, null, null);
            return new MapParametres(all);
        } catch (TechniqueException e) {
            throw new Bug(e);

        }
    }

    /**
     * liste de param�tres
     *
     * @return
     */
    public HashMap getParametres() {

        try {
            DoParametres[] all = (DoParametres[]) retrieveAll(getDefaultDatasourceName(),
                    null, null, null, null);

            HashMap hashMap = new HashMap();
            // chargement de la table Parametres dans un tableau en m�moire
            Integer temp = PDMBusinessConstants.DROIT_NULL;
            for (int i = 0; i < all.length; i++) {
                if ("O".equals(all[i].getParModification())) {
                    temp = PDMBusinessConstants.DROIT_MODIF_Ok;
                } else {
                    if ("O".equals(all[i].getParVisible())) {
                        temp = PDMBusinessConstants.DROIT_VISIBLE_Ok;
                    } else {
                        temp = PDMBusinessConstants.DROIT_NULL;
                    }
                }
                hashMap.put(all[i].getParRolCode() + all[i].getParFaaCode() + all[i].getParNomChamp(), temp);
            }


            return hashMap;

        } catch (TechniqueException e) {
            throw new Bug(e);

        }
    }

}