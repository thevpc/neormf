package camaieu.pdm.bo;

import camaieu.common.BoEasyAncestorBean;
import camaieu.common.Bug;
import camaieu.pdm.common.PDMBusinessConstants;
import camaieu.pdm.dataobject.DoDelais;
import wg4.bean.ancestor.TechniqueException;

import java.util.HashMap;

/**
 * @author tijani Souissi (ADD'IT Tunisie)
 * @creation_date date 21/01/2004
 * @last_modification_date 28/07/2004
 * @last_modification_date 28/07/2004
 * @status pour validation
 */
public class BoDelais extends BoEasyAncestorBean {
    public BoDelais() {
        super(DoDelais.class, PDMBusinessConstants.DATASOURCE_PDM);
    }

    /**
     * liste des delais
     *
     * @return
     */
    public HashMap getAllDelais() {
        try {
            DoDelais[] all = (DoDelais[]) retrieveAll(getDefaultDatasourceName(),
                    new String[]{"del_pay_code", "del_valeur"}, null, null, null);
            HashMap hashMap = new HashMap();
            // chargement de la table Xn_Four dans un tableau en m�moire
            for (int i = 0; i < all.length; i++) {
                hashMap.put(all[i].getDelPayCode(), all[i]);
            }
            return hashMap;

        } catch (TechniqueException e) {
            throw new Bug(e);

        }

    }
}


