package camaieu.pdm.bo;

import camaieu.common.BoEasyAncestorBean;
import camaieu.common.Bug;
import camaieu.pdm.common.MapXnFamArt;
import camaieu.pdm.common.PDMBusinessConstants;
import camaieu.pdm.dataobject.DoxnFamArt;
import wg4.bean.ancestor.TechniqueException;

/**
 * @author tijani Souissi (ADD'IT Tunisie)
 * @creation_date date 21/01/2004
 * @last_modification_date 28/07/2004
 * @last_modification_date 28/07/2004
 * @status pour validation
 */
public class BoxnFamArt extends BoEasyAncestorBean {
    /**
     *
     */
    public BoxnFamArt() {
        super(DoxnFamArt.class, PDMBusinessConstants.DATASOURCE_DTS);
    }

    /**
     * liste de familles
     *
     * @return
     */
    public MapXnFamArt getAllXnFamArt() {
        try {

            DoxnFamArt[] all = (DoxnFamArt[]) retrieveAll(getDefaultDatasourceName(),
                    new String[]{"FAA_CODE", "FAA_LIB"}, "st_critere",
                    "cri_xtx_id = xtx_id and cri_crv_crn_code='FAAACT' and cri_crv_valeur='O'",
                    "FAA_CODE");

            return new MapXnFamArt(all);
        } catch (TechniqueException e) {
            throw new Bug(e);

        }
    }

}
