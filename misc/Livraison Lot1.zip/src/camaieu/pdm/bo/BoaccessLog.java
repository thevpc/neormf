package camaieu.pdm.bo;

import camaieu.common.BoEasyAncestorBean;
import camaieu.common.Bug;
import camaieu.pdm.common.PDMBusinessConstants;
import camaieu.pdm.dataobject.DoaccessLog;
import wg4.bean.ancestor.TechniqueException;

import java.util.HashMap;

/**
 * @author tijani Souissi (ADD'IT Tunisie)
 * @creation_date date 21/01/2004
 * @last_modification_date 28/07/2004
 * @last_modification_date 28/07/2004
 * @status pour validation
 */
public class BoaccessLog extends BoEasyAncestorBean {
    /**
     *
     */
    public BoaccessLog() {
        super(DoaccessLog.class, PDMBusinessConstants.DATASOURCE_PDM);

    }

    /**
     * liste des logs
     *
     * @return
     */
    public HashMap getAllAccessLog() {
        try {
            DoaccessLog[] all = (DoaccessLog[]) retrieveAll(getDefaultDatasourceName(),
                    new String[]{"log_fou_code", "log_date"}, null, null, null);
            HashMap hashMap = new HashMap();
            // chargement de la table Xn_Four dans un tableau en m�moire
            for (int i = 0; i < all.length; i++) {
                hashMap.put(all[i].getLogFouCode(), all[i]);
            }
            return hashMap;

        } catch (TechniqueException e) {
            throw new Bug(e);

        }

    }
    //public void logUser
}
