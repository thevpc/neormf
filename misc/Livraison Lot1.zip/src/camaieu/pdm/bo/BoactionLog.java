package camaieu.pdm.bo;

import camaieu.common.BoEasyAncestorBean;
import camaieu.common.Bug;
import camaieu.pdm.common.PDMBusinessConstants;
import camaieu.pdm.dataobject.DoactionLog;
import wg4.bean.ancestor.TechniqueException;

import java.util.HashMap;

/**
 * @author tijani Souissi (ADD'IT Tunisie)
 * @creation_date date 21/01/2004
 * @last_modification_date 28/07/2004
 * @last_modification_date 28/07/2004
 * @status pour validation
 */
public class BoactionLog extends BoEasyAncestorBean {

    public BoactionLog() {
        super(DoactionLog.class, PDMBusinessConstants.DATASOURCE_PDM);

    }

//     public BoactionLog[] getActionLogs(String modelecode){
//        try {
//               BoactionLog[] all=(BoactionLog[]) retrieveAll(getDefaultDatasourceName(),
//                    new String [] {"act_fou_code","act_fic_champ","act_fic_version","act_date"},null,"ACT_FIC_SPT_MODELE_CODE="+modelecode,null) ;
//            return all ;
//
//        } catch (TechniqueException e) {
//                throw new Bug(e);
//
//        }
//
//    }
//    public Date getAction(String modelecode){
//       try {
//              Date[] all=(Date[]) retrieveAll(getDefaultDatasourceName(),
//                   new String [] {"act_date"},null,"ACT_FIC_SPT_MODELE_CODE="+modelecode,null) ;
//           return all[0] ;
//
//       } catch (TechniqueException e) {
//               throw new Bug(e);
//
//       }
//
//   }
    /**
     * liste des logs
     *
     * @param modelecode
     * @return
     */
    public HashMap getActionLogs(String modelecode) {
        try {
            DoactionLog[] all = (DoactionLog[]) retrieveAll(getDefaultDatasourceName(),
                    new String[]{"act_fou_code", "act_fic_champ", "act_fic_version", "ACT_FIC_SPT_MODELE_CODE", "act_date"},
                    null,
                    "ACT_FIC_SPT_MODELE_CODE=" + modelecode,
                    null);
            HashMap hashMap = new HashMap();
            // chargement de la table Xn_Four dans un tableau en m�moire
            for (int i = 0; i < all.length; i++) {
                hashMap.put(all[i].getActFouCode() +
                        all[i].getActFicChamp() +
                        all[i].getActFicVersion() +
                        all[i].getActFicSptModeleCode(), all[i]);
            }
            return hashMap;

        } catch (TechniqueException e) {
            throw new Bug(e);

        }

    }

}
