package camaieu.pdm.bo;

import camaieu.common.BoEasyAncestorBean;
import camaieu.common.Bug;
import camaieu.common.NumberUtils;
import camaieu.common.QueryManager;
import camaieu.pdm.common.PDMBusinessConstants;
import camaieu.pdm.common.PDMUtils;
import camaieu.pdm.dataobject.DosuiviProtoMap;
import wg4.bean.ancestor.TechniqueException;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * @author tijani Souissi (ADD'IT Tunisie)
 * @creation_date date 21/01/2004
 * @last_modification_date 28/07/2004
 * @last_modification_date 28/07/2004
 * @status pour validation
 */
public class BosuiviProtoMap extends BoEasyAncestorBean {
    /**
     *
     */
    public BosuiviProtoMap() {
        super(DosuiviProtoMap.class, PDMBusinessConstants.DATASOURCE_PDM);

    }

    /**
     * le proto map du mod�le pr�cis�
     *
     * @param modelecode
     * @return
     */
    public DosuiviProtoMap[] getProtoMap(String modelecode) {
        try {
            DosuiviProtoMap[] all = (DosuiviProtoMap[]) retrieveAll(getDefaultDatasourceName(),
                    new String[]{"SPM_SPT_MODELE_CODE",
                                 "SPM_NO_PROTO ",
                                 "SPM_DT_ENV_COMMENT",
                                 "SPM_DT_RETOUR_DDE",
                                 "SPM_DT_RECEP_COMMENT",
                                 "SPM_DT_ENV_PROTO",
                                 "SPM_DT_RECEP_PROTO",
                                 "SPM_DT_REUNION_PROD",
                                 "SPM_DECISION_OK_MAP",
                                 "SPM_DT_DECISION_OK_MAP "}
                    , null
                    , "SPM_SPT_MODELE_CODE=" + modelecode
                    , "SPM_NO_PROTO");

            return all;

        } catch (TechniqueException e) {
            throw new Bug(e);

        }

    }

    /**
     * insertion d'un nouvel enregistrement
     *
     * @param modele
     * @return
     */
    public boolean insertRow(String modele) {
        String insertQuery = QueryManager.getQuery("camaieu.pdm.sql.insert_suivi_proto_map");
        try {
            return 0 < update(getDefaultDatasourceName(), insertQuery, new Object[][]{{new Integer(modele), getNumNouveauProtoMap(new Integer(modele))}}, true);
        } catch (TechniqueException e) {
            return false;
        }
    }

    /**
     * retourne un nouvel id de protomap pour le modele s�lectionn�
     *
     * @param modele
     * @return
     */
    private Integer getNumNouveauProtoMap(Integer modele) {

        ArrayList parametres = new ArrayList();
        parametres.add(modele);
        try {
            Object[][] themax = (Object[][]) retrieve(getDefaultDatasourceName(),
                    "SELECT NVL(MAX(SPM_NO_PROTO),0)+1 FROM SUIVI_PROTO_MAP WHERE SPM_SPT_MODELE_CODE=?",
                    (Object[]) parametres.toArray(new Object[parametres.size()]));
            return NumberUtils.toInteger((Number) themax[0][0]);
        } catch (TechniqueException e) {
            throw new Bug(e);

        }

    }

    /**
     * chargement du contenu de l'enregistrement fichier
     *
     * @param modele
     * @return
     * @throws TechniqueException
     */
    public DosuiviProtoMap loadFichier(Integer modele, Integer noProto) throws TechniqueException {

        String q = "select SPM_COMMENTAIRES from SUIVI_PROTO_MAP where SPM_SPT_MODELE_CODE=? and SPM_NO_PROTO=?";
        try {
            PreparedStatement ps = getConnection().prepareStatement(q);
            ps.setInt(1, modele.intValue());
            ps.setInt(2, noProto.intValue());
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                DosuiviProtoMap dosuiviProtoMap = new DosuiviProtoMap();
                dosuiviProtoMap.setSpmCommentaires(rs.getBytes(1));
                return dosuiviProtoMap;
            }
            return null;
        } catch (SQLException e) {
            throw new Bug(e);
        }
    }

    /**
     * enrtegistrement du fichier
     *
     * @param f
     * @param modeleCode
     * @param noProto
     * @throws SQLException
     * @throws IOException
     * @throws TechniqueException
     */
    public void uploadFile(File f, Integer modeleCode, Integer noProto) throws SQLException, IOException, TechniqueException {
        String q = " update SUIVI_PROTO_MAP set SPM_COMMENTAIRES=? where SPM_SPT_MODELE_CODE=? and SPM_NO_PROTO=?";
        Connection c = null;
        try {
            c = getConnection();
            if (f != null) {
                PreparedStatement ps = getConnection().prepareStatement(q);
                PDMUtils.populateBlob(ps, 1, f);
                ps.setInt(2, modeleCode.intValue());
                ps.setInt(3, noProto.intValue());
                ps.executeUpdate();
                ps.close();
            }
        } finally {
            if (c != null) {
                c.close();
            }
        }

    }

}