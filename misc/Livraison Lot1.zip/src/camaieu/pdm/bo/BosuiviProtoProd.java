package camaieu.pdm.bo;

import camaieu.common.BoEasyAncestorBean;
import camaieu.common.Bug;
import camaieu.common.NumberUtils;
import camaieu.common.QueryManager;
import camaieu.pdm.common.PDMBusinessConstants;
import camaieu.pdm.common.PDMUtils;
import camaieu.pdm.dataobject.DosuiviProtoProd;
import wg4.bean.ancestor.TechniqueException;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * @author tijani Souissi (ADD'IT Tunisie)
 * @creation_date date 21/01/2004
 * @last_modification_date 28/07/2004
 * @last_modification_date 28/07/2004
 * @status pour validation
 */
public class BosuiviProtoProd extends BoEasyAncestorBean {
    public BosuiviProtoProd() {
        super(DosuiviProtoProd.class, PDMBusinessConstants.DATASOURCE_PDM);

    }

    /**
     * liste de suiviProtoProd
     *
     * @param modelecode
     * @return
     */
    public DosuiviProtoProd[] getProtoProd(String modelecode) {
        try {
            DosuiviProtoProd[] all = (DosuiviProtoProd[]) retrieveAll(getDefaultDatasourceName(),
                    new String[]{"SPP_SPT_MODELE_CODE",
                                 "SPP_NO_PROTO",
                                 "SPP_DT_ENV_COMMENT",
                                 "SPP_DT_RECEP_COMMENT",
                                 "SPP_DT_RETOUR_DDE",
                                 "SPP_DT_ENV_PROTO",
                                 "SPP_DT_RECEP_PROTO",
                                 "SPP_DT_DEC_OK_PROD",
                                 "SPP_DEC_OK_PROD"}
                    , null
                    , "SPP_SPT_MODELE_CODE=" + modelecode
                    , "SPP_NO_PROTO");

            return all;

        } catch (TechniqueException e) {
            throw new Bug(e);

        }

    }

    /**
     * insertion d'un nouvel enregistrement
     *
     * @param modele
     * @return
     */
    public boolean insertRow(String modele) {

        String insertQuery = QueryManager.getQuery("camaieu.pdm.sql.insert_suivi_proto_prod");
        try {
            return 0 < update(getDefaultDatasourceName(), insertQuery, new Object[][]{{new Integer(modele), getNumNouveauProtoProd(new Integer(modele))}}, true);
        } catch (TechniqueException e) {
            //e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
            return false;
        }

    }

    /**
     * r�cup�ration du nouvel identifiant
     *
     * @param modele
     * @return
     */
    private Integer getNumNouveauProtoProd(Integer modele) {
        ArrayList parametres = new ArrayList();
        parametres.add(modele);
        try {
            Object[][] themax = (Object[][]) retrieve(getDefaultDatasourceName(),
                    "SELECT NVL(MAX(SPP_NO_PROTO),0)+1 FROM SUIVI_PROTO_PROD WHERE SPP_SPT_MODELE_CODE=?",
                    (Object[]) parametres.toArray(new Object[parametres.size()]));
            return NumberUtils.toInteger((Number) themax[0][0]);
        } catch (TechniqueException e) {
            throw new Bug(e);

        }

    }

    /**
     * chargement d'un enregistrement
     *
     * @param modele
     * @return
     * @throws TechniqueException
     */
    public DosuiviProtoProd loadFichier(Integer modele, Integer noProto) throws TechniqueException {

        String q = "select SPP_COMMENTAIRES from SUIVI_PROTO_PROD where SPP_SPT_MODELE_CODE=? and SPP_NO_PROTO=?";
        try {
            PreparedStatement ps = getConnection().prepareStatement(q);
            ps.setInt(1, modele.intValue());
            ps.setInt(2, noProto.intValue());
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                DosuiviProtoProd dosuiviProtoProd = new DosuiviProtoProd();
                dosuiviProtoProd.setSppCommentaires(rs.getBytes(1));
                return dosuiviProtoProd;
            }
            return null;
        } catch (SQLException e) {
            throw new Bug(e);
        }
    }


    /**
     * enregistrement du fichier
     *
     * @param f
     * @param modeleCode
     * @param noProto
     * @throws SQLException
     * @throws IOException
     * @throws TechniqueException
     */
    public void uploadFile(File f, Integer modeleCode, Integer noProto) throws SQLException, IOException, TechniqueException {
        String q = " update SUIVI_PROTO_PROD set SPP_COMMENTAIRES=? where SPP_SPT_MODELE_CODE=? and SPP_NO_PROTO=?";
        Connection c = null;
        try {
            c = getConnection();
            if (f != null) {
                PreparedStatement ps = getConnection().prepareStatement(q);
                PDMUtils.populateBlob(ps, 1, f);
                ps.setInt(2, modeleCode.intValue());
                ps.setInt(3, noProto.intValue());
                ps.executeUpdate();
                ps.close();
            }
        } finally {
            if (c != null) {
                c.close();
            }
        }
    }

}
