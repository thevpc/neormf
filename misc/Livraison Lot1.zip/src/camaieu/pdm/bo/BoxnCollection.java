package camaieu.pdm.bo;

import camaieu.common.BoEasyAncestorBean;
import camaieu.common.Bug;
import camaieu.pdm.common.MapXnCollection;
import camaieu.pdm.common.PDMBusinessConstants;
import camaieu.pdm.dataobject.DoxnCollection;
import wg4.bean.ancestor.TechniqueException;

/**
 * @author tijani Souissi (ADD'IT Tunisie)
 * @creation_date date 21/01/2004
 * @last_modification_date 28/07/2004
 * @last_modification_date 28/07/2004
 * @status pour validation
 */
public class BoxnCollection extends BoEasyAncestorBean {
    public BoxnCollection() {
        super(DoxnCollection.class, PDMBusinessConstants.DATASOURCE_DTS);

    }

    /**
     * liste des collections
     *
     * @return
     */
    public MapXnCollection getAllXnCollection() {
        try {
            DoxnCollection[] all = (DoxnCollection[]) retrieveAll(getDefaultDatasourceName(),
                    new String[]{"clt_an", "clt_code", "clt_sai_code", "clt_lib"}, null, null, "clt_an,clt_dt_deb");

            return new MapXnCollection(all);
        } catch (TechniqueException e) {
            throw new Bug(e);

        }

    }

}


