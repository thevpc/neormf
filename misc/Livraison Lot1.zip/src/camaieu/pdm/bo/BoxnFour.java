package camaieu.pdm.bo;

import camaieu.common.BoEasyAncestorBean;
import camaieu.common.Bug;
import camaieu.pdm.common.MapXnFour;
import camaieu.pdm.common.PDMBusinessConstants;
import camaieu.pdm.common.PDMUtils;
import camaieu.pdm.dataobject.DoxnFour;
import wg4.bean.ancestor.TechniqueException;

import javax.servlet.http.HttpServletRequest;


/**
 * @author tijani Souissi (ADD'IT Tunisie)
 * @creation_date date 21/01/2004
 * @last_modification_date 28/07/2004
 * @last_modification_date 28/07/2004
 * @status pour validation
 */
public class BoxnFour extends BoEasyAncestorBean {

    /**
     *
     */
    public BoxnFour() {
        super(DoxnFour.class, PDMBusinessConstants.DATASOURCE_DTS);

    }

    /**
     * liste de fournisseurs
     *
     * @return
     */
    public MapXnFour getAllFournissueurs() {
        try {
            DoxnFour[] all = (DoxnFour[]) retrieveAll(getDefaultDatasourceName(),
                    new String[]{"FOU_CODE", "FOU_NOM", "FOU_PAY_CODE", "FOU_PAY_CODE_FAB"},
                    null,
                    null,
                    null);
            return new MapXnFour(all);
        } catch (TechniqueException e) {
            throw new Bug(e);
        }
    }

    public MapXnFour getAllFournissueursTissu() {
        try {
            DoxnFour[] all = (DoxnFour[]) retrieveAll(getDefaultDatasourceName(),
                    new String[]{"FOU_CODE", "FOU_NOM", "FOU_PAY_CODE"},
                    null,
                    "FOU_DOMAINE='C' ",
                    null);
            return new MapXnFour(all);
        } catch (TechniqueException e) {
            throw new Bug(e);
        }
    }

    public MapXnFour getAllFournissueursBureauxExternes() {
        try {
            DoxnFour[] all = (DoxnFour[]) retrieveAll(getDefaultDatasourceName(),
                    new String[]{"FOU_CODE", "FOU_NOM", "FOU_PAY_CODE"},
                    null,
                    "FOU_FOT_CODE = 'SR' ",
                    null);
            return new MapXnFour(all);
        } catch (TechniqueException e) {
            throw new Bug(e);
        }
    }

    public MapXnFour getAllFournissueursFaconniers() {
        try {
            DoxnFour[] all = (DoxnFour[]) retrieveAll(getDefaultDatasourceName(),
                    new String[]{"FOU_CODE", "FOU_NOM", "FOU_PAY_CODE", "FOU_PAY_CODE_FAB"},
                    null,
                    " FOU_DOMAINE = 'F'  OR " +
                    "(FOU_DOMAINE = 'A'  and " +
                    "FOU_FOT_CODE IN ('AG', 'AI', 'AF', 'FF', 'FI', 'FP', 'GS', 'IM'))",
                    null);
            return new MapXnFour(all);
        } catch (TechniqueException e) {
            throw new Bug(e);
        }
    }

    public String getAllFournissueursAgent(HttpServletRequest request) {
        try {
            DoxnFour[] all = (DoxnFour[]) retrieveAll(getDefaultDatasourceName(),
                    new String[]{"FOU_CODE", "FOU_NOM", "FOU_PAY_CODE"},
                    null,
                    "FOU_FOU_CODE_AGENTI = '" + PDMUtils.getCurrentUserFouCode(request) + "'",
                    null);

            String fournisseurs = "";
            for (int i = 0; i < all.length; i++) {
                fournisseurs += ("'" + all[i].getFouCode() + "',");
            }
            if (fournisseurs != "") {
                fournisseurs = "(" + fournisseurs.substring(0, fournisseurs.length() - 1) + ")";
            }

            return fournisseurs;
        } catch (TechniqueException e) {
            throw new Bug(e);
        }
    }

}
