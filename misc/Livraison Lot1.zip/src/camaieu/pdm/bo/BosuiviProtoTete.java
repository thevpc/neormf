package camaieu.pdm.bo;

import camaieu.common.BoEasyAncestorBean;
import camaieu.common.Bug;
import camaieu.common.NumberUtils;
import camaieu.common.QueryManager;
import camaieu.pdm.common.PDMBusinessConstants;
import camaieu.pdm.common.PDMUtils;
import camaieu.pdm.dataobject.DosuiviProtoMap;
import camaieu.pdm.dataobject.DosuiviProtoProd;
import camaieu.pdm.dataobject.DosuiviProtoTete;
import camaieu.pdm.dataobject.MergedDoSuivi;
import wg4.bean.ancestor.TechniqueException;
import wg4.fwk.dataobject.DataObject;

import javax.servlet.http.HttpServletRequest;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;

/**
 * @author tijani Souissi (ADD'IT Tunisie)
 * @creation_date date 21/01/2004
 * @last_modification_date 28/07/2004
 * @last_modification_date 28/07/2004
 * @status pour validation
 */
public class BosuiviProtoTete extends BoEasyAncestorBean {
    /**
     *
     */
    public BosuiviProtoTete() {
        super(camaieu.pdm.dataobject.DosuiviProtoTete.class, camaieu.pdm.common.PDMBusinessConstants.DATASOURCE_PDM);
    }

    /**
     * r�cup�ration de la liste des mod�les
     *
     * @param filtre_collection
     * @param filtre_famille
     * @param filtre_pays
     * @param filtre_etat
     * @param modele_id
     * @param allFaconniers
     * @param allCollections
     * @param allDelai
     * @param request
     * @return
     */
    public camaieu.pdm.dataobject.MergedDoSuivi[] getAllDosuiviProtoTete(String filtre_collection,
                                                                         String filtre_famille,
                                                                         String filtre_pays,
                                                                         String filtre_etat,
                                                                         String modele_id,
                                                                         camaieu.pdm.common.MapXnFour allFaconniers,
                                                                         camaieu.pdm.common.MapXnCollection allCollections,
                                                                         HashMap allDelai,
                                                                         HttpServletRequest request) {

        camaieu.pdm.dataobject.MergedDoSuivi[] mergedDoSuiviLignes = getAllDosuiviProtoTete(filtre_collection,
                filtre_famille,
                filtre_pays,
                filtre_etat,
                modele_id, request);
        for (int i = 0; i < mergedDoSuiviLignes.length; i++) {
            camaieu.pdm.dataobject.MergedDoSuivi mergedDoSuiviLigne = mergedDoSuiviLignes[i];
            Timestamp cltDtDeb = null;
            if (allCollections != null) {
                cltDtDeb = allCollections.getDataObject(mergedDoSuiviLigne.getDosuiviProtoTete().getSptCltAn(),
                        mergedDoSuiviLigne.getDosuiviProtoTete().getSptCltSaiCode(),
                        mergedDoSuiviLigne.getDosuiviProtoTete().getSptCltCode()).getCltDtDeb();
            }
            Integer delValeur = null;
            if (allDelai != null) {
                delValeur = ((camaieu.pdm.dataobject.DoDelais) allDelai.get(allFaconniers.getDataObject(mergedDoSuiviLigne.getDosuiviProtoTete().getSptFacCode())
                        .getFouPayCode())).getDelValeur();
            }

            mergedDoSuiviLigne.getDoNodhosProperties().setDelValeur(delValeur);
            Calendar c = Calendar.getInstance();
            if (cltDtDeb != null && delValeur != null) {
                c.setTime(cltDtDeb);
                c.add(Calendar.DAY_OF_YEAR, -delValeur.intValue());
                mergedDoSuiviLigne.getDoNodhosProperties().setDateDebutProd(new Timestamp(c.getTimeInMillis()));
            }
        }
        return mergedDoSuiviLignes;
    }

    /**
     * r�cup�ration de la liste des mod�les
     *
     * @param filtre_collection
     * @param filtre_famille
     * @param filtre_pays
     * @param filtre_etat
     * @param modele_id
     * @param request
     * @return
     */
    public MergedDoSuivi[] getAllDosuiviProtoTete(String filtre_collection,
                                                  String filtre_famille,
                                                  String filtre_pays,
                                                  String filtre_etat,
                                                  String modele_id,
                                                  HttpServletRequest request) {
        try {
            String query = QueryManager.getQuery("camaieu.pdm.sql.all_suivi_proto_tete");
            ArrayList parametres = new ArrayList();
            if (filtre_collection != null) {
                camaieu.pdm.dataobject.DoxnCollection clt = camaieu.pdm.common.MapXnCollection.getDataObjectByStringKey(filtre_collection);
                query += (" AND SPT_CLT_CODE=?");
                query += (" AND SPT_CLT_AN=?");
                query += (" AND SPT_CLT_SAI_CODE=?");
                parametres.add(clt.getCltCode());
                parametres.add(clt.getCltAn());
                parametres.add(clt.getCltSaiCode());
            }
            if (modele_id != null) {
                query += (" AND SPT_MODELE_CODE=?");
                parametres.add(modele_id);
            }

            if (filtre_etat != null) {
                query += (" and (" + QueryManager.getQuery("camaieu.pdm.sql." + filtre_etat) + ") ");
            }

            if (filtre_pays != null && filtre_pays.length() != 0) {
                query += (" AND (SPT_FAC_CODE in " + filtre_pays + ")");
            }
            if (!"-".equals(PDMUtils.getCurrentUserFamily(request))) {
                if (PDMBusinessConstants.ROLE_AC.equals(PDMUtils.getCurrentUserRole(request)) ||
                        PDMBusinessConstants.ROLE_MO.equals(PDMUtils.getCurrentUserRole(request)) ||
                        filtre_famille != null) {
                    query += (" and SPT_FAA_CODE =?");
                    parametres.add(PDMUtils.getCurrentUserFamily(request));
                }
            }
            if (PDMBusinessConstants.ROLE_BI.equals(PDMUtils.getCurrentUserRole(request))) {
                query += (" and (SPT_BUREAU_CODE =? OR SPT_FAC_CODE  in " + new BoxnFour().getAllFournissueursAgent(request) + ")");
                parametres.add(PDMUtils.getCurrentUserFouCode(request));
            }

            DataObject[][] all = retrieve(getDefaultDatasourceName(),
                    query,
                    (Object[]) parametres.toArray(new Object[parametres.size()]),
                    new Class[]{DosuiviProtoTete.class, DosuiviProtoMap.class, DosuiviProtoProd.class});

            MergedDoSuivi[] mergedDoSuivis = new MergedDoSuivi[all[0].length];
            for (int i = 0; i < mergedDoSuivis.length; i++) {
                DosuiviProtoTete dosuiviProtoTete = (DosuiviProtoTete) all[0][i];
                DosuiviProtoMap dosuiviProtoMap = (DosuiviProtoMap) all[1][i];
                DosuiviProtoProd dosuiviProtoProd = (DosuiviProtoProd) all[2][i];
                MergedDoSuivi.DoNodhosProperties doNodhosProperties = new MergedDoSuivi.DoNodhosProperties();
                Object[][] r = null;
                r = retrieve(PDMBusinessConstants.DATASOURCE_DTS,
                        QueryManager.getQuery("camaieu.pdm.sql.all_suivi_proto_tete_lancement_tissu")
                        , new Object[]{((DosuiviProtoTete) all[0][i]).getSptRefNodhos()},
                        1);
                if (r.length > 0) {
                    doNodhosProperties.setCftDtCommande((Timestamp) r[0][0]);
                    String modeleId = dosuiviProtoTete.getSptRefNodhos();
                    if (modeleId == null) {
                        Object[][] o = retrieve(PDMBusinessConstants.DATASOURCE_DTS, "Select FOU_FOT_CODE from XN_FOUR where FOU_CODE=?", new Object[]{dosuiviProtoTete.getSptFacCode()});
                        if ("FA".equals(o[0][0]) || "FI".equals(o[0][0]) || "GP".equals(o[0][0]) || "TR".equals(o[0][0])) {
                            doNodhosProperties.setFaconNegoce("Fa�on");
                        } else if ("AF".equals(o[0][0]) || "AG".equals(o[0][0]) || "AI".equals(o[0][0]) || "GS".equals(o[0][0]) || "IM".equals(o[0][0]) || "TI".equals(o[0][0])) {
                            doNodhosProperties.setFaconNegoce("PF");
                        } else {
                            doNodhosProperties.setFaconNegoce((String) o[0][0]);
                        }
                    } else {
                        Object[][] o = retrieve(PDMBusinessConstants.DATASOURCE_DTS, "Select MOD_TYPE from XN_MODELE where MOD_CODE=?", new Object[]{modeleId});
                        doNodhosProperties.setFaconNegoce((String) o[0][0]);
                    }
                }

                r = retrieve(PDMBusinessConstants.DATASOURCE_DTS,
                        QueryManager.getQuery("camaieu.pdm.sql.all_suivi_proto_tete_depart_1ere_cmd"),
                        new Object[]{((DosuiviProtoTete) all[0][i]).getSptRefNodhos()},
                        1);

                if (r.length > 0) {
                    doNodhosProperties.setCatDtPrevLiv((Timestamp) r[0][2]);
                }

                MergedDoSuivi mergedDoSuiviItem = new MergedDoSuivi(dosuiviProtoTete,
                        dosuiviProtoMap,
                        dosuiviProtoProd,
                        doNodhosProperties);
                mergedDoSuivis[i] = mergedDoSuiviItem;
            }


            return mergedDoSuivis;
        } catch (TechniqueException e) {
            throw new Bug(e);
        }
        //comment updater
    }

    /**
     * mise � jour d'un enregistrement
     *
     * @param row
     * @return
     */
    public boolean updateRow(MergedDoSuivi row) {
        DosuiviProtoProd dosuiviprotoprod = new DosuiviProtoProd();
        DosuiviProtoMap dosuiviprotomap = new DosuiviProtoMap();
        DosuiviProtoTete dosuiviprototete = new DosuiviProtoTete();
        dosuiviprotoprod = row.getDosuiviProtoProd();
        dosuiviprotomap = row.getDosuiviProtoMap();
        dosuiviprototete = row.getDosuiviProtoTete();
        dosuiviprotoprod.setPersist(DataObject.PERSIST_UPDATE);
        dosuiviprotomap.setPersist(DataObject.PERSIST_UPDATE);
        dosuiviprototete.setPersist(DataObject.PERSIST_UPDATE);

        try {
            persist(getDefaultDatasourceName(), new DataObject[]{dosuiviprotoprod}, true);
            persist(getDefaultDatasourceName(), new DataObject[]{dosuiviprototete}, true);
            persist(getDefaultDatasourceName(), new DataObject[]{dosuiviprotomap}, true);
            return true;
        } catch (TechniqueException e) {
            return false;
        }

    }

    /**
     * insertion d'un nouvel enregistrement
     *
     * @param row
     * @return
     */
    public boolean insertRow(MergedDoSuivi row) {
        DosuiviProtoProd dosuiviprotoprod = new DosuiviProtoProd();
        DosuiviProtoMap dosuiviprotomap = new DosuiviProtoMap();
        DosuiviProtoTete dosuiviprototete = new DosuiviProtoTete();
        dosuiviprotoprod = row.getDosuiviProtoProd();
        dosuiviprotomap = row.getDosuiviProtoMap();
        dosuiviprototete = row.getDosuiviProtoTete();

        String insertQueryMap = QueryManager.getQuery("camaieu.pdm.sql.insert_suivi_proto_map");
        String insertQueryProd = QueryManager.getQuery("camaieu.pdm.sql.insert_suivi_proto_prod");
        String insertQueryTete = QueryManager.getQuery("camaieu.pdm.sql.insert_suivi_proto_tete");
        try {
            int t = update(getDefaultDatasourceName(), insertQueryTete, new Object[][]{{dosuiviprototete.getSptModeleCode()}}, true);
            int m = update(getDefaultDatasourceName(), insertQueryMap, new Object[][]{{dosuiviprototete.getSptModeleCode(),
                                                                                       dosuiviprotomap.getSpmNoProto()}}, true);
            int p = update(getDefaultDatasourceName(), insertQueryProd, new Object[][]{{dosuiviprototete.getSptModeleCode(),
                                                                                        dosuiviprotoprod.getSppNoProto()}}, true);

        } catch (TechniqueException e) {
            //e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
            //return false;
        }


        dosuiviprotoprod.setPersist(DataObject.PERSIST_UPDATE);
        dosuiviprotomap.setPersist(DataObject.PERSIST_UPDATE);
        dosuiviprototete.setPersist(DataObject.PERSIST_UPDATE);

        try {
            persist(getDefaultDatasourceName(), new DataObject[]{dosuiviprotoprod}, true);
            persist(getDefaultDatasourceName(), new DataObject[]{dosuiviprototete}, true);
            persist(getDefaultDatasourceName(), new DataObject[]{dosuiviprotomap}, true);
            return true;
        } catch (TechniqueException e) {
            return false;
        }

    }

    /**
     * supprime un mod�le
     *
     * @param dosuiviProtoTete
     * @return
     */
    public boolean deleteModele(DosuiviProtoTete dosuiviProtoTete) {
        dosuiviProtoTete.setPersist(DataObject.PERSIST_UPDATE);
        try {
            persist(getDefaultDatasourceName(), new DataObject[]{dosuiviProtoTete}, true);
            return true;
        } catch (TechniqueException e) {
            return false;
        }

    }

    /**
     * nouveau num�ro de mod�le
     *
     * @return
     */
    public Integer getNumNouveauModele() {

        try {
            Object[][] themax = (Object[][]) retrieve(// getDefaultDatasourceName(),
                    PDMBusinessConstants.DATASOURCE_PDM,
                    "SELECT NVL(MAX(SPT_MODELE_CODE),0)+1 FROM SUIVI_PROTO_TETE ",
                    new Object[0]);
            return NumberUtils.toInteger((Number) themax[0][0]);
        } catch (TechniqueException e) {
            throw new Bug(e);

        }

    }
}