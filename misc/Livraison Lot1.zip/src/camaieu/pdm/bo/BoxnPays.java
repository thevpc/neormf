package camaieu.pdm.bo;

import camaieu.common.BoEasyAncestorBean;
import camaieu.common.Bug;
import camaieu.pdm.common.MapXnPays;
import camaieu.pdm.common.PDMBusinessConstants;
import camaieu.pdm.dataobject.DoxnPays;
import wg4.bean.ancestor.TechniqueException;

/**
 * @author tijani Souissi (ADD'IT Tunisie)
 * @creation_date date 21/01/2004
 * @last_modification_date 28/07/2004
 * @last_modification_date 28/07/2004
 * @status pour validation
 */
public class BoxnPays extends BoEasyAncestorBean {

    /**
     *
     */
    public BoxnPays() {
        super(DoxnPays.class, PDMBusinessConstants.DATASOURCE_DTS);
    }

    /**
     * liste des pays
     *
     * @return
     */
    public MapXnPays getAllXnPays() {
        try {
            DoxnPays[] all = (DoxnPays[]) retrieveAll(getDefaultDatasourceName(),
                    new String[]{"PAY_CODE", "PAY_NOM"}, null, null, "PAY_NOM");

            return new MapXnPays(all);

        } catch (TechniqueException e) {
            throw new Bug(e);

        }
    }

}


