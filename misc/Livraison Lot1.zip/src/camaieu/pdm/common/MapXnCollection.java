package camaieu.pdm.common;

import camaieu.common.StringUtils;
import camaieu.pdm.dataobject.DoxnCollection;

import java.util.HashMap;

/**
 * Classe utilitaire pour g�rer un tableau de Collection
 *
 * @author taha BEN SALAH (ADD'IT Tunisie)
 * @creation_date date 21/01/2004
 * @last_modification_date 28/07/2004
 * @last_modification_date 28/07/2004
 * @status pour validation
 */
public class MapXnCollection {
    private HashMap hashMap = new HashMap();
    private DoxnCollection[] all;

    /**
     * constructeur par d�faut
     *
     * @param all
     */
    public MapXnCollection(DoxnCollection[] all) {
        this.all = all;
        for (int i = 0; i < all.length; i++) {
            hashMap.put(getStringKey(all[i].getCltAn(), all[i].getCltSaiCode(), all[i].getCltCode())
                    , all[i]);
        }
    }

    /**
     * recup�re un DataObject � partir de la clef
     *
     * @param cltAn
     * @param cltSaiCode
     * @param cltCode
     * @return
     */
    public DoxnCollection getDataObject(String cltAn, String cltSaiCode, String cltCode) {
        return (DoxnCollection) hashMap.get(getStringKey(cltAn, cltSaiCode, cltCode));
    }

    /**
     * r�cup�re tout le tableau
     *
     * @return
     */
    public DoxnCollection[] getArray() {
        return all;
    }

    /**
     * retourne une clef � partir d'une chaine compos�e
     *
     * @param doxnCollection
     * @return
     */
    public String getStringKey(DoxnCollection doxnCollection) {
        return getStringKey(doxnCollection.getCltAn(), doxnCollection.getCltSaiCode(), doxnCollection.getCltCode());
    }

    /**
     * retourne une clef � partir d'une chaine compos�e
     *
     * @param position dans le tableau
     * @return
     */
    public String getStringKeyAt(int position) {
        return getStringKey(all[position]);
    }

    /**
     * recup�re un DO rempli avec les champs clef � partir de la chaine donn�e
     *
     * @param stringKey
     * @return
     */
    public static DoxnCollection getDataObjectByStringKey(String stringKey) {
        String[] k = StringUtils.split(stringKey, "$", false);
        DoxnCollection doxnCollection = new DoxnCollection();
        doxnCollection.setCltAn(k[0]);
        doxnCollection.setCltSaiCode(k[1]);
        doxnCollection.setCltCode(k[2]);
        return doxnCollection;
    }

    /**
     * retourne une chaine identifiant la clef compos�e
     *
     * @param cltAn
     * @param cltSaiCode
     * @param cltCode
     * @return
     */
    public static String getStringKey(String cltAn, String cltSaiCode, String cltCode) {
        return cltAn + '$' + cltSaiCode + '$' + cltCode;
    }
}
