package camaieu.pdm.common;

/**
 * Classe utilitaire pour g�rer les constantes m�tier
 *
 * @author taha BEN SALAH (ADD'IT Tunisie)
 * @creation_date date 21/01/2004
 * @last_modification_date 28/07/2004
 * @last_modification_date 28/07/2004
 * @status pour validation
 */
public final class PDMBusinessConstants {
    private PDMBusinessConstants() {
    }

    // * * * * * ********************************************
    // Data sources de connection aux bases de donn�es
    // * * * * * ********************************************

    public final static String DATASOURCE_PDM = "jdbc/pdm";
    public final static String DATASOURCE_DTS = "jdbc/dts";


    // * * * * * ********************************************
    // Roles utilisateurs
    // * * * * * ********************************************
    public final static String ROLE_HA = "HA";
    public final static String ROLE_AC = "ac";
    public final static String ROLE_MO = "mo";
    public final static String ROLE_CQ = "cq";
    public final static String ROLE_BI = "bi";
    public final static String ROLE_BE = "be";
    public final static String ROLE_FA = "FA";
    public final static String ROLE_ADMIN = "admin";

    // * * * * * ********************************************
    // Droits
    // * * * * * ********************************************

    public final static Integer DROIT_MODIF_Ok = new Integer(1);
    public final static Integer DROIT_VISIBLE_Ok = new Integer(2);
    public final static Integer DROIT_NULL = new Integer(3);

    // * * * * * ********************************************
    // Types de fichiers
    // * * * * * ********************************************

    public static final class DoFichiers {
        public static final class FicChamp {
            public static final String SPT_FICHE_TECHNIQUE = "SPT_FICHE_TECHNIQUE";
            public static final String SPT_BAREME_MENSU = "SPT_BAREME_MENSU";
            public static final String SPT_PATRONAGE = "SPT_PATRONAGE";
            public static final String SPT_NOMENCLATURE = "SPT_NOMENCLATURE";
            public static final String SPM_COMMENTAIRES = "SPM_COMMENTAIRES";
            public static final String SPP_COMMENTAIRES = "SPP_COMMENTAIRES";
            public static final String SPT_COMMENT_POST_OK_PROD = "SPT_COMMENT_POST_OK_PROD";
        }
    }
}

