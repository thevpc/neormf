package camaieu.pdm.common;

/**
 * Classe utilitaire pour g�rer les constantes de type request
 *
 * @author taha BEN SALAH (ADD'IT Tunisie)
 * @creation_date date 21/01/2004
 * @last_modification_date 28/07/2004
 * @last_modification_date 28/07/2004
 * @status pour validation
 */
public final class PDMRequestConstants {
    /**
     *
     */
    private PDMRequestConstants() {
    }

    /**
     * modeles
     */
    public static final String SUIVI_MERGED_DO_SUIVI_ARRAY = "SUIVI_MERGED_DO_SUIVI";

    /**
     * delais
     */
    public static final String SUIVI_DELAI_HASHMAP = "SUIVI_DELAI_HASHMAP";

    /**
     * Erreur
     */

    public static final String ERREUR = "erreur";
    /**
     * mode =insertion 0 /mise � jour 1
     */
    public static final String IS_UPDATE_MODE = "isUpdateMode";

    /**
     * droits
     */
    public static final String DROITS = "droits";
    /**
     *
     */

    public static final String LOGS= "logs";
    /**
     * identifiant modele
     */

    public static final String MODELE_ID = "MODELE_ID";
    /**
     *   champ type de fichier
     */
    public static final String FIC_CHAMP = "FIC_CHAMP";
    /**
     * verion fichier
     */
    public static final String FIC_VERSION= "FIC_VERSION";
    /**
     * fichier
     */

    public static final String FILE= "file";
    /**
     * num�ro prototype
     */
    public static final String NO_PROTO= "NO_PROTO";
    /**
     * modele
     */
    public static final String MODELE= "modele";
    /**
     * fichiers du modele
     */
    public static final String MODELE_FILES= "ModeleFiles";
    /**
     * numero modele
     */
    public static final String NO_MODELE= "nommodele";
    /**
     * proto maps
     */
    public static final String PROTO_MAPS= "protomaps";
    /**
     * proto prods
     */
    public static final String PROTO_PRODS= "protoprods";
    /**
     * type du fichier
     */
    public static final String FILE_TYPE= "filetype";
    /**
     * parametres de visualisation
     */
    public static final String CSV= "csv";
    /**
     * parametres de visualisation
     */
    public static final String PARAMS= "parametres";
    /**
     * Filtre famille
     */

    public static final String SUIV_FILTRE_FAMILLE="suiv_filtre_famille";
    /**
     * Filtre collection
     */
    public static final String SUIVI_FILTRE_COLLECTION="suivi_filtre_collection";
    /**
     * Filtre pays
     */
    public static final String SUIVI_FILTRE_PAYS="suivi_filtre_pays";
    /**
     * Filtre etat
     */
    public static final String SUIVI_FILTRE_ETAT="suivi_filtre_etat";




}

