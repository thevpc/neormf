package camaieu.pdm.common;

import camaieu.common.StringUtils;
import camaieu.pdm.dataobject.DoParametres;

import java.util.HashMap;

/**
 * Classe utilitaire pour g�rer un tableau de Collection
 *
 * @author taha BEN SALAH (ADD'IT Tunisie)
 * @creation_date date 21/01/2004
 * @last_modification_date 28/07/2004
 * @last_modification_date 28/07/2004
 * @status pour validation
 */
public class MapParametres {
    private HashMap hashMap = new HashMap();
    private DoParametres[] all;

    /**
     * constructeur par d�faut
     *
     * @param all
     */
    public MapParametres(DoParametres[] all) {
        this.all = all;
        for (int i = 0; i < all.length; i++) {
            hashMap.put(getStringKey(all[i].getParNomChamp(), all[i].getParRolCode(), all[i].getParFaaCode())
                    , all[i]);
        }
    }

    /**
     * recup�re un DataObject � partir de la clef
     *
     * @return
     */
    public DoParametres getDataObject(String parNomChamp, String parRolCode, String parFaaCode) {
        DoParametres p = (DoParametres) hashMap.get(getStringKey(parNomChamp, parRolCode, parFaaCode));
        if (p == null && !"-".equals(parFaaCode)) {
            parFaaCode = "-";
            p = (DoParametres) hashMap.get(getStringKey(parNomChamp, parRolCode, parFaaCode));
        }
        return p;
    }

    public boolean isVisibleColumn(String column, String role, String famille) {
        DoParametres p = getDataObject(column, role, famille);
        if (p != null) {
            return "O".equalsIgnoreCase(p.getParVisible());
        }
        return false;
    }

    public boolean isUpdatableColumn(String column, String role, String famille) {
        DoParametres p = getDataObject(column, role, famille);
        if (p != null) {
            return "O".equalsIgnoreCase(p.getParModification());
        }
        return false;
    }

    /**
     * r�cup�re tout le tableau
     *
     * @return
     */
    public DoParametres[] getArray() {
        return all;
    }

    /**
     * retourne une clef � partir d'une chaine compos�e
     *
     * @param doParametres
     * @return
     */
    public static String getStringKey(DoParametres doParametres) {
        return getStringKey(doParametres.getParNomChamp(), doParametres.getParRolCode(), doParametres.getParFaaCode());
    }

    /**
     * retourne une clef � partir d'une chaine compos�e
     *
     * @param position dans le tableau
     * @return
     */
    public String getStringKeyAt(int position) {
        return getStringKey(all[position]);
    }

    /**
     * recup�re un DO rempli avec les champs clef � partir de la chaine donn�e
     *
     * @param stringKey
     * @return
     */
    public static DoParametres getDataObjectByStringKey(String stringKey) {
        String[] k = StringUtils.split(stringKey, "$", false);
        DoParametres doParametres = new DoParametres();
        doParametres.setParNomChamp(k[0]);
        doParametres.setParRolCode(k[1]);
        doParametres.setParFaaCode(k[2]);
        return doParametres;
    }

    /**
     * retourne une chaine identifiant la clef compos�e
     *
     * @param parNomChamp
     * @param parRolCode
     * @param parFaaCode
     * @return
     */
    public static String getStringKey(String parNomChamp, String parRolCode, String parFaaCode) {
        return parNomChamp + '$' + parRolCode + '$' + parFaaCode;
    }
}
