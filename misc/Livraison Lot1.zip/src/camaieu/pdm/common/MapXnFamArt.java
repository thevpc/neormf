package camaieu.pdm.common;

import camaieu.pdm.dataobject.DoxnFamArt;

import java.util.HashMap;

/**
 * Classe utilitaire pour g�rer un tableau de Collection
 *
 * @author taha BEN SALAH (ADD'IT Tunisie)
 * @creation_date date 21/01/2004
 * @last_modification_date 28/07/2004
 * @last_modification_date 28/07/2004
 * @status pour validation
 */
public class MapXnFamArt {
    private HashMap hashMap = new HashMap();
    private DoxnFamArt[] all;

    /**
     * constructeur par d�faut
     *
     * @param all
     */
    public MapXnFamArt(DoxnFamArt[] all) {
        this.all = all;
        for (int i = 0; i < all.length; i++) {
            hashMap.put(all[i].getFaaCode(), all[i]);
        }
    }

    /**
     * recup�re un DataObject � partir de la clef
     *
     * @param faaCode
     * @return
     */
    public DoxnFamArt getDataObject(String faaCode) {
        if (!"-".equals(faaCode)) {
            return (DoxnFamArt) hashMap.get(faaCode);
        } else {
            return new DoxnFamArt();
        }

    }

    /**
     * r�cup�re tout le tableau
     *
     * @return
     */
    public DoxnFamArt[] getArray() {
        return all;
    }
}
