package camaieu.pdm.common;

import camaieu.common.WUtils;
import camaieu.upload.FileUploadHelper;
import camaieu.upload.SimpleUploadableFileFilter;

import javax.servlet.ServletContext;
import java.io.File;

/**
 * Classe utilitaire pour g�rer les  upload/download
 *
 * @author taha BEN SALAH (ADD'IT Tunisie)
 * @creation_date date 21/01/2004
 * @last_modification_date 28/07/2004
 * @last_modification_date 28/07/2004
 * @status pour validation
 */
public class PDMUploadHelper extends FileUploadHelper {
    /**
     * unique constructeur
     */
    public PDMUploadHelper(ServletContext servletContext) {
        super(// le r�pertoire racine pour l'upload
                WUtils.getStringWebEnvVar("uploadWebRoot", null) == null ?
                new File(WUtils.getStringWebEnvVar("uploadRoot", null))
                :
                new File(servletContext.getRealPath(WUtils.getStringWebEnvVar("uploadWebRoot", "upload")))
                ,
                // le r�pertoire temporaire pour l'upload
                new File(WUtils.getStringWebEnvVar("uploadTempRoot", "upload/temp")));

        setUploadableFileFilter(new SimpleUploadableFileFilter(WUtils.getIntWebEnvVar("uploadFileMaxSize", 700) * 1024,
                WUtils.getStringArrayWebEnvVar("uploadFileTypes", ",; ", false,
                        new String[]{"xml"})));
    }
}
