package camaieu.pdm.common;

import camaieu.pdm.dataobject.DoxnFour;

import java.util.HashMap;

/**
 * Classe utilitaire pour g�rer un tableau de Collection
 *
 * @author taha BEN SALAH (ADD'IT Tunisie)
 * @creation_date date 21/01/2004
 * @last_modification_date 28/07/2004
 * @last_modification_date 28/07/2004
 * @status pour validation
 */
public class MapXnFour {
    private HashMap hashMap = new HashMap();
    private DoxnFour[] all;

    /**
     * constructeur par d�faut
     *
     * @param all
     */
    public MapXnFour(DoxnFour[] all) {
        this.all = all;
        for (int i = 0; i < all.length; i++) {
            hashMap.put(all[i].getFouCode(), all[i]);
        }
    }

    /**
     * recup�re un DataObject � partir de la clef
     *
     * @param fouCode
     * @return
     */
    public DoxnFour getDataObject(String fouCode) {
        return (DoxnFour) hashMap.get(fouCode);
    }

    /**
     * r�cup�re tout le tableau
     *
     * @return
     */
    public DoxnFour[] getArray() {
        return all;
    }
}
