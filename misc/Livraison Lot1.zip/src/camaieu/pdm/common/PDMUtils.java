package camaieu.pdm.common;

import camaieu.common.WUtils;
import camaieu.pdm.bo.BoParametres;
import camaieu.webform.RecordEditorHelper;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.JspWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.HashMap;


/**
 * Classe utilitaire d'ordre g�n�ral
 *
 * @author taha BEN SALAH (ADD'IT Tunisie)
 * @creation_date date 21/01/2004
 * @last_modification_date 28/07/2004
 * @last_modification_date 28/07/2004
 * @status pour validation
 */
public final class PDMUtils {
    public static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("dd/MM/yy");

    /**
     *
     */
    public PDMUtils() {
    }


    /**
     * role de l'utilisateur courant
     *
     * @param request
     * @return role
     */
    public static String getCurrentUserRole(HttpServletRequest request) {
        return (String) request.getSession().getAttribute(PDMSessionConstants.USER_ROLE);
    }

    /**
     * fournisseur de l'utilisateur courant
     *
     * @param request
     * @return role
     */
    public static String getCurrentUserFouCode(HttpServletRequest request) {
        return (String) request.getSession().getAttribute(PDMSessionConstants.USER_FOU_CODE);
    }


    /**
     * colonne visible
     *
     * @param request
     * @param columnName
     * @return
     * @author taha
     */
    public static boolean isVisibleColumn(HttpServletRequest request, String columnName) {
        String role = getCurrentUserRole(request);
        String famille = getCurrentUserFamily(request);
        MapParametres p = (MapParametres) request.getSession().getAttribute("parametres");
        if (p == null) {
            BoParametres boParametres = new BoParametres();
            p = boParametres.getAllParametres();
            request.getSession().setAttribute(PDMRequestConstants.PARAMS, p);
        }
        return p.isVisibleColumn(columnName, role, famille);
    }

    /**
     * colonne modifiable
     *
     * @param request
     * @param columnName
     * @return
     * @author taha
     */
    public static boolean isUpdatableColumn(HttpServletRequest request, String columnName) {
        String role = getCurrentUserRole(request);
        String famille = getCurrentUserFamily(request);
        MapParametres p = (MapParametres) request.getSession().getAttribute("parametres");
        if (p == null) {
            BoParametres boParametres = new BoParametres();
            p = boParametres.getAllParametres();
            request.getSession().setAttribute(PDMRequestConstants.PARAMS , p);
        }
        return p.isVisibleColumn(columnName, role, famille);
    }

    /**
     * famille de l'utilisateur courant
     *
     * @param request
     * @return code famille
     */
    public static String getCurrentUserFamily(HttpServletRequest request) {
        return (String) request.getSession().getAttribute(PDMSessionConstants.USER_FAMILLE);
    }

    /**
     * pr�pare un fichier pour insertion
     *
     * @param s
     * @param position
     * @param file
     * @throws SQLException
     * @throws IOException
     */
    public static void populateBlob(PreparedStatement s, int position, File file) throws SQLException, IOException {
        byte[] bytes = new byte[(int) file.length()];
        FileInputStream inputStream = new FileInputStream(file);
        inputStream.read(bytes);
        inputStream.close();
        s.setBytes(position, bytes);
    }

    /**
     * retourne le code HTML du tag text
     *
     * @param helper
     * @param request
     * @param out
     * @param fieldName
     * @param maxLength
     * @param o
     * @throws IOException
     */
    public static final void textFieldHtml(RecordEditorHelper helper, HttpServletRequest request, JspWriter out, String fieldName, int maxLength, Object o) throws IOException {
        helper.startHtmlEditor(request, out, fieldName);
        out.print("<Input Type='text' name='" + fieldName + "' value='" + helper.getHtmlEditingValue(request, fieldName, o) + "' maxLength=" + maxLength + ">\n");
        helper.endHtmlEditor(request, out, fieldName);
    }

    /**
     * retourne un e chaine � afficher
     *
     * @param request
     * @param isUpdateMode
     * @param o
     * @return
     */
    public static final String getDisplayField(HttpServletRequest request, boolean isUpdateMode, Object o) {
        if (isUpdateMode && o != null ) {
            return WUtils.toDisplayable(request, o);
        } else {
            return "";
        }

    }

    /**
     * les droits de l'utilisateur
     *
     * @param dts
     * @param role
     * @param fam
     * @param champ
     * @return
     */
    public static final Integer getDroits(HashMap dts, String role, String fam, String champ) {
        //BoParametres droits=new BoParametres() ;
        //HashMap dts=droits.getParametres();
        if (dts.get(role + "-" + champ) == PDMBusinessConstants.DROIT_MODIF_Ok ||
                dts.get(role + fam + champ) == PDMBusinessConstants.DROIT_MODIF_Ok) {
            return PDMBusinessConstants.DROIT_MODIF_Ok;
        } else {
            if (dts.get(role + "-" + champ) == PDMBusinessConstants.DROIT_VISIBLE_Ok ||
                    dts.get(role + fam + champ) == PDMBusinessConstants.DROIT_VISIBLE_Ok) {
                return PDMBusinessConstants.DROIT_VISIBLE_Ok;
            } else {
                return PDMBusinessConstants.DROIT_NULL;
            }
        }
    }
}
