package camaieu.pdm.common;

/**
 * Classe utilitaire pour g�rer les constantes de type session
 *
 * @author taha BEN SALAH (ADD'IT Tunisie)
 * @creation_date date 21/01/2004
 * @last_modification_date 28/07/2004
 * @last_modification_date 28/07/2004
 * @status pour validation
 */
public final class PDMSessionConstants {
    /**
     * modeles
     */
    public static final String MODELE_DO_SUIVI_PROTO_TETE = "MODELE_DO_SUIVI_PROTO_TETE";

    /**
     * login
     */
    public static final String USER_LOGIN = "USER_LOGIN";

    /**
     * role
     */
    public static final String USER_ROLE = "USER_ROLE";

    /**
     * fournisseur
     */
    public static final String USER_FOU_CODE = "USER_FOU_CODE";

    /**
     * famille
     */
    public static final String USER_FAMILLE = "USER_FAMILLE";

    /**
     * collection
     */
    public static final String MAP_XN_COLLECTION = "MAP_XN_COLLECTION";

    /**
     * famille
     */
    public static final String MAP_XN_FAM_ART = "MAP_XN_FAM_ART";

    /**
     * faconnier
     */
    public static final String MAP_XN_FOUR_FAC = "MAP_XN_FOUR_FAC";

    /**
     * fournisseur bureau
     */
    public static final String MAP_XN_FOUR_BUR = "MAP_XN_FOUR_BUR";

    /**
     * fournisseur de tissus
     */
    public static final String MAP_XN_FOUR_TISS = "MAP_XN_FOUR_TISS";


    /**
     * pays
     */
    public static final String MAP_XN_PAYS = "MAP_XN_PAYS";

    /**
     * delais
     */
    public static final String ALL_DELAI_HASHMAP = "ALL_DELAI_HASHMAP";

}
