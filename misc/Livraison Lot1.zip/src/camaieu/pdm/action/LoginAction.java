package camaieu.pdm.action;

import camaieu.pdm.bo.*;
import camaieu.pdm.common.*;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author tijani Souissi (ADD'IT Tunisie)
 * @creation_date date 21/01/2004
 * @last_modification_date 28/07/2004
 * @last_modification_date 28/07/2004
 * @status pour validation
 */
public class LoginAction extends Action {

    //////////////////////////////////////////////////////////////
    // la securit� n'est pas encore impl�ment�e
    // cette classes est uniquement pour des besoins de tests
    //////////////////////////////////////////////////////////////


    /**
     * @see Action#execute(ActionMapping, ActionForm, HttpServletRequest, HttpServletResponse)
     */
    public final ActionForward execute(ActionMapping mapping, ActionForm form,
                                       HttpServletRequest request,
                                       HttpServletResponse response) throws Exception {


        String login = (String) request.getParameter("login");
        String role = (String) request.getParameter("role");
        String famille = (String) request.getParameter("famille");
        request.getSession().setAttribute(PDMSessionConstants.USER_LOGIN, login);
        request.getSession().setAttribute(PDMSessionConstants.USER_ROLE, role);
        request.getSession().setAttribute(PDMSessionConstants.USER_FAMILLE, famille);
        request.getSession().setAttribute(PDMSessionConstants.USER_FOU_CODE, "3001");


        BoxnCollection boxnCollection = new BoxnCollection();
        BoxnFamArt boxnFamArt = new BoxnFamArt();
        BoxnPays boxnPays = new BoxnPays();
        BoxnFour boxnFour = new BoxnFour();
        BoParametres boParametres = new BoParametres();
        MapXnCollection allCollections = boxnCollection.getAllXnCollection();
        MapXnFamArt allFamilles = boxnFamArt.getAllXnFamArt();
        MapXnPays allPays = boxnPays.getAllXnPays();
        MapXnFour allFournisseursTissu = boxnFour.getAllFournissueursTissu();
        MapXnFour allFournisseursFaconniers = boxnFour.getAllFournissueursFaconniers();
        MapXnFour allFournisseursBureauxExt = boxnFour.getAllFournissueursBureauxExternes();
        MapParametres allParametres = boParametres.getAllParametres();
        request.getSession().setAttribute(PDMSessionConstants.MAP_XN_COLLECTION, allCollections);
        request.getSession().setAttribute(PDMSessionConstants.MAP_XN_FAM_ART, allFamilles);
        request.getSession().setAttribute(PDMSessionConstants.MAP_XN_FOUR_BUR, allFournisseursBureauxExt);
        request.getSession().setAttribute(PDMSessionConstants.MAP_XN_FOUR_FAC, allFournisseursFaconniers);
        request.getSession().setAttribute(PDMSessionConstants.MAP_XN_FOUR_TISS, allFournisseursTissu);
        request.getSession().setAttribute(PDMSessionConstants.MAP_XN_PAYS, allPays);
        request.getSession().setAttribute(PDMSessionConstants.ALL_DELAI_HASHMAP, new BoDelais().getAllDelais());
        request.getSession().setAttribute(PDMRequestConstants.PARAMS, allParametres);

        return mapping.findForward("ok");
    }
}
