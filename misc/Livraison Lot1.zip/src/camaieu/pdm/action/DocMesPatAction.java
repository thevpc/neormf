package camaieu.pdm.action;

import camaieu.pdm.bo.BoFichiers;
import camaieu.pdm.common.PDMRequestConstants;
import camaieu.pdm.dataobject.DoFichiers;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;

/**
 * @author tijani Souissi (ADD'IT Tunisie)
 * @creation_date date 21/01/2004
 * @last_modification_date 28/07/2004
 * @last_modification_date 28/07/2004
 * @status pour validation
 */
public class DocMesPatAction extends Action {

    /**
     * @see Action#execute(ActionMapping, ActionForm, HttpServletRequest, HttpServletResponse)
     */
    public final ActionForward execute(ActionMapping mapping, ActionForm form,
                                       HttpServletRequest request,
                                       HttpServletResponse response) throws Exception {



        String ficmodeleid = request.getParameter(PDMRequestConstants.MODELE_ID);

        BoFichiers bofichiers = new BoFichiers();
        DoFichiers file = bofichiers.loadFichier("SPT_PATRONAGE", 1, Integer.parseInt(ficmodeleid));
        if (file != null) {
            request.setAttribute(PDMRequestConstants.FILE, file);
            return mapping.findForward("ok");
        } else {
            ArrayList erreurs = new ArrayList();
            erreurs.add("Fichier non trouv�");
            request.setAttribute(PDMRequestConstants.ERREUR, erreurs);
            return mapping.findForward("err");
        }
    }
}
