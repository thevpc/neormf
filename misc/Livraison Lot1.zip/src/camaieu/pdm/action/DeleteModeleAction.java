package camaieu.pdm.action;

import camaieu.pdm.bo.BosuiviProtoTete;
import camaieu.pdm.common.PDMRequestConstants;
import camaieu.pdm.dataobject.DosuiviProtoTete;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author tijani Souissi (ADD'IT Tunisie)
 * @creation_date date 21/01/2004
 * @last_modification_date 28/07/2004
 * @last_modification_date 28/07/2004
 * @status pour validation
 */
public class DeleteModeleAction extends Action {

    /**
     * @see Action#execute(ActionMapping, ActionForm, HttpServletRequest, HttpServletResponse)
     */
    public final ActionForward execute(ActionMapping mapping, ActionForm form,
                                       HttpServletRequest request,
                                       HttpServletResponse response) throws Exception {

        String modele = (String) request.getParameter(PDMRequestConstants.MODELE_ID);

        DosuiviProtoTete dosuiviProtoTete = new DosuiviProtoTete();
        dosuiviProtoTete.setSptModeleCode(new Integer(modele));
        dosuiviProtoTete.setSptStatus("X");
        BosuiviProtoTete bosuiviProtoTete = new BosuiviProtoTete();
        bosuiviProtoTete.deleteModele(dosuiviProtoTete);

        return mapping.findForward("ok");
    }
}
