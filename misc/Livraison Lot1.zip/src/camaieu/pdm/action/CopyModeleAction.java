package camaieu.pdm.action;

import camaieu.pdm.bo.BoParametres;
import camaieu.pdm.bo.BosuiviProtoTete;
import camaieu.pdm.common.PDMRequestConstants;
import camaieu.pdm.common.PDMSessionConstants;
import camaieu.pdm.dataobject.MergedDoSuivi;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * @author tijani Souissi (ADD'IT Tunisie)
 * @creation_date date 21/01/2004
 * @last_modification_date 28/07/2004
 * @last_modification_date 28/07/2004
 * @status pour validation
 */
public class CopyModeleAction extends Action {

    /**
     * @see Action#execute(ActionMapping, ActionForm, HttpServletRequest, HttpServletResponse)
     */
    public final ActionForward execute(ActionMapping mapping, ActionForm form,
                                       HttpServletRequest request,
                                       HttpServletResponse response) throws Exception {


        String vcmodele = (String) request.getParameter(PDMRequestConstants.MODELE_ID );       //SPT_MODELE_CODE interger

        BosuiviProtoTete bosuiviProtoTete = new BosuiviProtoTete();
        MergedDoSuivi[] dosuiviProtoTete = bosuiviProtoTete.getAllDosuiviProtoTete(null, null, null, null, vcmodele, request);

        //mise � jour ....copie pas pour tout les elements
        dosuiviProtoTete[0].getDosuiviProtoProd().setSppSptModeleCode(null);
        dosuiviProtoTete[0].getDosuiviProtoProd().setSppNoProto(null);
        dosuiviProtoTete[0].getDosuiviProtoProd().setSppDtEnvComment(null);
        dosuiviProtoTete[0].getDosuiviProtoProd().setSppDtRecepComment(null);
        dosuiviProtoTete[0].getDosuiviProtoProd().setSppDtRetourDde(null);
        dosuiviProtoTete[0].getDosuiviProtoProd().setSppDtEnvProto(null);
        dosuiviProtoTete[0].getDosuiviProtoProd().setSppDtRecepProto(null);
        dosuiviProtoTete[0].getDosuiviProtoProd().setSppDtDecOkProd(null);
        dosuiviProtoTete[0].getDosuiviProtoProd().setSppDecOkProd(null);
        dosuiviProtoTete[0].getDosuiviProtoTete().setSptOkProdEntrep(null);
        dosuiviProtoTete[0].getDosuiviProtoTete().setSptValidEchanSource(null);
        dosuiviProtoTete[0].getDosuiviProtoTete().setSptOkMatiere(null);
        dosuiviProtoTete[0].getDosuiviProtoTete().setSptEmploiDef(null);
        dosuiviProtoTete[0].getDosuiviProtoTete().setSptOkColoris(null);
        dosuiviProtoTete[0].getDosuiviProtoTete().setSptOkAccessoires(null);
        dosuiviProtoTete[0].getDosuiviProtoTete().setSptTeteSerie(null);
        dosuiviProtoTete[0].getDosuiviProtoTete().setSptDdeTeteSerie(null);
        dosuiviProtoTete[0].getDosuiviProtoTete().setSptDtRecepFtechFac(null);
        dosuiviProtoTete[0].getDosuiviProtoTete().setSptDtEnvPatronage(null);
        dosuiviProtoTete[0].getDosuiviProtoTete().setSptRecepDisqPat(null);
        dosuiviProtoTete[0].getDosuiviProtoTete().setSptDtEnvCtFac(null);
        dosuiviProtoTete[0].getDosuiviProtoTete().setSptDtEnvFtechFac(null);
        dosuiviProtoTete[0].getDosuiviProtoTete().setSptEmpProvisoire(null);
        dosuiviProtoTete[0].getDosuiviProtoTete().setSptCommentAchats(null);
        dosuiviProtoTete[0].getDosuiviProtoTete().setSptCommentBureau(null);
        dosuiviProtoTete[0].getDosuiviProtoTete().setSptCommentModeliste(null);

        request.getSession().setAttribute(PDMSessionConstants.MODELE_DO_SUIVI_PROTO_TETE, dosuiviProtoTete[0]);
        request.setAttribute(PDMRequestConstants.IS_UPDATE_MODE, "0");

        BoParametres droits = new BoParametres();
        request.setAttribute(PDMRequestConstants.DROITS, droits.getParametres());

        return mapping.findForward("ok");
    }
}
