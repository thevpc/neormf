package camaieu.pdm.action;

import camaieu.pdm.bo.*;
import camaieu.pdm.common.MapXnCollection;
import camaieu.pdm.common.PDMRequestConstants;
import camaieu.pdm.common.PDMSessionConstants;
import camaieu.pdm.common.PDMUploadHelper;
import camaieu.pdm.dataobject.DosuiviProtoMap;
import camaieu.pdm.dataobject.DosuiviProtoProd;
import camaieu.pdm.dataobject.DosuiviProtoTete;
import camaieu.pdm.dataobject.MergedDoSuivi;
import camaieu.webform.FieldConstraintsException;
import camaieu.webform.FieldConstraintsFactory;
import camaieu.webform.RecordEditorHelper;
import camaieu.webform.ValidatorUtils;
import com.oreilly.servlet.MultipartRequest;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;

/**
 * @author tijani Souissi (ADD'IT Tunisie)
 * @creation_date date 21/01/2004
 * @last_modification_date 28/07/2004
 * @last_modification_date 28/07/2004
 * @status pour validation
 */
public class UpdateModeleAction extends Action {
    /**
     * @see Action#execute(ActionMapping, ActionForm, HttpServletRequest, HttpServletResponse)
     */
    public final ActionForward execute(ActionMapping mapping, ActionForm form,
                                       HttpServletRequest request,
                                       HttpServletResponse response) throws Exception {


        //-----------construire un mergedsuiviproto pour l'envoyer au bosuiviprototete pour mise � jour
        DosuiviProtoTete updateinformationsspt = new DosuiviProtoTete();
        DosuiviProtoMap updateinformationsspm = new DosuiviProtoMap();
        DosuiviProtoProd updateinformationsspp = new DosuiviProtoProd();


        PDMUploadHelper uploadHelper = new PDMUploadHelper(getServlet().getServletContext());
        uploadHelper.setRequest(request);
        MultipartRequest multipartRequest = (MultipartRequest) uploadHelper.getMultipartRequest();


        File ftech = null;
        try {
            ftech = multipartRequest.getFile("PFicheTechnique");
        } catch (Exception e) {
        }
        File fbaremeMens = null;
        try {
            fbaremeMens = multipartRequest.getFile("PBaremeMensuration");
        } catch (Exception e) {

        }
        File fpatronnage = null;
        try {
            fpatronnage = multipartRequest.getFile("PPatronnage");
        } catch (Exception e) {

        }
        File fnomenclature = null;
        try {
            fnomenclature = multipartRequest.getFile("PNomenclature");
        } catch (Exception e) {

        }
        File fcommentMap = null;
        try {
            fcommentMap = multipartRequest.getFile("PCommentaireMap");
        } catch (Exception e) {

        }
        File fcommentProd = null;
        try {
            fcommentProd = multipartRequest.getFile("PCommentaireProd");
        } catch (Exception e) {

        }

        MergedDoSuivi dosuiviProtoTete = (MergedDoSuivi) request.getSession().getAttribute(PDMSessionConstants.MODELE_DO_SUIVI_PROTO_TETE);
        RecordEditorHelper recordEditorHelper = new RecordEditorHelper();
        if (dosuiviProtoTete != null) {
            recordEditorHelper = dosuiviProtoTete.getRecordEditorHelper();
        }

        String vcmodele = (String) multipartRequest.getParameter(PDMRequestConstants.MODELE_ID);       //SPT_MODELE_CODE interger
        boolean isUpdateMode = ("null".equals(vcmodele)) ? false : true;




        //String vmodele=null;    //SPT_NOM_MODELE va20
        try {
            updateinformationsspt.setSptNomModele(ValidatorUtils.parseString("PModele", (String) multipartRequest.getParameter("PModele"), request, recordEditorHelper, FieldConstraintsFactory.any()));
        } catch (FieldConstraintsException e) {
        }

//        String vrefNodhos=null;    //SPT_REF_NODHOS va20
        try {
            updateinformationsspt.setSptRefNodhos(ValidatorUtils.parseString("PRefNodhos", (String) multipartRequest.getParameter("PRefNodhos"), request, recordEditorHelper, FieldConstraintsFactory.any()));
        } catch (FieldConstraintsException e) {
        }
//        String vfamille=null;        //SPT_FAA_CODE va5
        try {
            updateinformationsspt.setSptFaaCode(ValidatorUtils.parseString("PFamille", (String) multipartRequest.getParameter("PFamille"), request, recordEditorHelper, FieldConstraintsFactory.any()));
        } catch (FieldConstraintsException e) {
        }

        try {
            String vcollection = ValidatorUtils.parseString("PCollection", (String) multipartRequest.getParameter("PCollection"), request, recordEditorHelper, FieldConstraintsFactory.any());   //ClT_CODE va3
            updateinformationsspt.setSptCltCode(MapXnCollection.getDataObjectByStringKey(vcollection).getCltCode());
            updateinformationsspt.setSptCltSaiCode(MapXnCollection.getDataObjectByStringKey(vcollection).getCltSaiCode());
            updateinformationsspt.setSptCltAn(MapXnCollection.getDataObjectByStringKey(vcollection).getCltAn());
        } catch (FieldConstraintsException e) {
        }

//        String vqualite=null;    //   SPT_QUALITE  va30
        try {
            updateinformationsspt.setSptQualite(ValidatorUtils.parseString("PQualite", (String) multipartRequest.getParameter("PQualite"), request, recordEditorHelper, FieldConstraintsFactory.any()));
        } catch (FieldConstraintsException e) {
        }

//        String vfoutissu=null;  //   SPT_FOU_CODE_TISSU va8
        try {
            updateinformationsspt.setSptFouCodeTissu(ValidatorUtils.parseString("PFouTissu", (String) multipartRequest.getParameter("PFouTissu"), request, recordEditorHelper, FieldConstraintsFactory.any()));
        } catch (FieldConstraintsException e) {
        }

//        String vlavage=null;        //SPT_LAVAGE va30
        try {
            updateinformationsspt.setSptLavage(ValidatorUtils.parseString("PLavage", (String) multipartRequest.getParameter("PLavage"), request, recordEditorHelper, FieldConstraintsFactory.any()));
        } catch (FieldConstraintsException e) {
        }

//        String vtypebureau=null;   //SPT_BUREAU_TYPE va2
        try {
            updateinformationsspt.setSptBureauType(ValidatorUtils.parseString("PTypeBureau", (String) multipartRequest.getParameter("PTypeBureau"), request, recordEditorHelper, FieldConstraintsFactory.any()));
        } catch (FieldConstraintsException e) {
        }
//        String vbureauexterne=null; //SPT_BUREAU_CODE  va8
        try {
            updateinformationsspt.setSptBureauCode(ValidatorUtils.parseString("PBureauExterne", (String) multipartRequest.getParameter("PBureauExterne"), request, recordEditorHelper, FieldConstraintsFactory.any()));
        } catch (FieldConstraintsException e) {
        }

//        String vfaconnier=null;//SPT_FAC_CODE ***va8
        try {
            updateinformationsspt.setSptFacCode(ValidatorUtils.parseString("PFaconnier", (String) multipartRequest.getParameter("PFaconnier"), request, recordEditorHelper, FieldConstraintsFactory.any()));
        } catch (FieldConstraintsException e) {
        }

        try {
            updateinformationsspt.setSptDtTransmission(ValidatorUtils.parseTimestamp("PDateTransmission", (String) multipartRequest.getParameter("PDateTransmission"), request, recordEditorHelper, FieldConstraintsFactory.anyTimestamp(true)));
        } catch (FieldConstraintsException e) {
        }

        try {
            updateinformationsspt.setSptDtEnvFtechBur(ValidatorUtils.parseTimestamp("PEnvoiFicheTechMAP", (String) multipartRequest.getParameter("PEnvoiFicheTechMAP"), request, recordEditorHelper, FieldConstraintsFactory.anyTimestamp(true)));
        } catch (FieldConstraintsException e) {
        }

        //String venvoicoupetypemap=null; //SPT_DT_ENV_CT_BUR date
        try {
            updateinformationsspt.setSptDtEnvCtBur(ValidatorUtils.parseTimestamp("PEnvoiCoupeTypeMAP", (String) multipartRequest.getParameter("PEnvoiCoupeTypeMAP"), request, recordEditorHelper, FieldConstraintsFactory.anyTimestamp(true)));
        } catch (FieldConstraintsException e) {
        }

        //String venvoifichetechcot=null; // SPT_DT_ENV_FTECH_COTATION date     //////????????????????????????
        try {
            updateinformationsspt.setSptDtEnvFtechBur(ValidatorUtils.parseTimestamp("PEnvoiFicheTechCot", (String) multipartRequest.getParameter("PEnvoiFicheTechCot"), request, recordEditorHelper, FieldConstraintsFactory.anyTimestamp(true)));
        } catch (FieldConstraintsException e) {
        }

//        String venvoicoupetypeessaimat=null;  // SPT_ENV_CTYPE_ESSAI_MAT va 50
        try {
            updateinformationsspt.setSptEnvCtypeEssaiMat(ValidatorUtils.parseString("PEnvoiCoupeTypeEssaiMat", (String) multipartRequest.getParameter("PEnvoiCoupeTypeEssaiMat"), request, recordEditorHelper, FieldConstraintsFactory.any()));
        } catch (FieldConstraintsException e) {
        }

//        String vreceptionfichetech=null; // SPT_DT_RECEP_FTECH_BUR date
        try {
            updateinformationsspt.setSptDtRecepFtechBur(ValidatorUtils.parseTimestamp("PReceptionFicheTech", (String) multipartRequest.getParameter("PReceptionFicheTech"), request, recordEditorHelper, FieldConstraintsFactory.anyTimestamp(true)));
        } catch (FieldConstraintsException e) {
        }

        //String vreceptioncoupetype=null;// SPT_DT_RECEP_CT_BUR date
        try {
            updateinformationsspt.setSptDtRecepCtBur(ValidatorUtils.parseTimestamp("PReceptionCoupeType", (String) multipartRequest.getParameter("PReceptionCoupeType"), request, recordEditorHelper, FieldConstraintsFactory.anyTimestamp(true)));
        } catch (FieldConstraintsException e) {
        }
        try {
            updateinformationsspt.setSptPrixFacon(ValidatorUtils.parseDouble("PPrixFacon", (String) multipartRequest.getParameter("PPrixFacon"), request, recordEditorHelper, FieldConstraintsFactory.anyDouble(true)));
            if (updateinformationsspt.getSptPrixFacon() == null) {
                updateinformationsspt.setSptPrixFacon(new Double(0));
            }

        } catch (FieldConstraintsException e) {
        }


//        String vnoproto=null; // SPM_NO_PROT
        try {
            updateinformationsspm.setSpmNoProto(ValidatorUtils.parseInteger("PNoProtoMap", (String) multipartRequest.getParameter("PNoProtoMap"), request, recordEditorHelper, FieldConstraintsFactory.anyInt(true)));
        } catch (FieldConstraintsException e) {
        }

        //String vdateretourdemande=null; //SPM_DT_RETOUR_DDE
        try {

            updateinformationsspm.setSpmDtRetourDde(ValidatorUtils.parseTimestamp("PDateRetourDemande", (String) multipartRequest.getParameter("PDateRetourDemande"), request, recordEditorHelper, FieldConstraintsFactory.anyTimestamp(true)));
        } catch (FieldConstraintsException e) {
        }

        //  String venvoicomment=null; //SPM_DT_ENV_COMMENT date
        try {
            updateinformationsspm.setSpmDtEnvComment(ValidatorUtils.parseTimestamp("PEnvoiComment", (String) multipartRequest.getParameter("PEnvoiComment"), request, recordEditorHelper, FieldConstraintsFactory.any()));
        } catch (FieldConstraintsException e) {
        }

        //String vreceptioncomment=null; //SPM_DT_RECEP_COMMENT date
        try {
            updateinformationsspm.setSpmDtRecepComment(ValidatorUtils.parseTimestamp("PReceptionComment", (String) multipartRequest.getParameter("PReceptionComment"), request, recordEditorHelper, FieldConstraintsFactory.anyTimestamp(true)));
        } catch (FieldConstraintsException e) {
        }

        //String venvoiprototype1=null; //SPM_DT_ENV_PROTO date
        try {
            updateinformationsspm.setSpmDtEnvProto(ValidatorUtils.parseTimestamp("PEnvoiPrototype1", (String) multipartRequest.getParameter("PEnvoiPrototype1"), request, recordEditorHelper, FieldConstraintsFactory.anyTimestamp(true)));
        } catch (FieldConstraintsException e) {
        }

        //String vreceptionprototype1=null; //SPM_DT_RECEP_PROTO date
        try {
            updateinformationsspm.setSpmDtRecepProto(ValidatorUtils.parseTimestamp("PReceptionPrototype1", (String) multipartRequest.getParameter("PReceptionPrototype1"), request, recordEditorHelper, FieldConstraintsFactory.anyTimestamp(true)));
        } catch (FieldConstraintsException e) {
        }

        //String vdatereunionproduit=null;   //SPM_DT_REUNION_PROD date
        try {
            updateinformationsspm.setSpmDtReunionProd(ValidatorUtils.parseTimestamp("PDateReunionProduit", (String) multipartRequest.getParameter("PDateReunionProduit"), request, recordEditorHelper, FieldConstraintsFactory.anyTimestamp(true)));
        } catch (FieldConstraintsException e) {
        }
//        String VokmAp=null; //SPM_DECISION_OK_MAP    va1
        try {
            updateinformationsspm.setSpmDecisionOkMap(ValidatorUtils.parseString("POkMAp", (String) multipartRequest.getParameter("POkMAp"), request, recordEditorHelper, FieldConstraintsFactory.any()));
        } catch (FieldConstraintsException e) {
        }

        //String vokmaptext=null;//SPM_DT_DECISION_OK_MAP date
        try {
            updateinformationsspm.setSpmDtDecisionOkMap(ValidatorUtils.parseTimestamp("POkMapText", (String) multipartRequest.getParameter("POkMapText"), request, recordEditorHelper, FieldConstraintsFactory.anyTimestamp(true)));
        } catch (FieldConstraintsException e) {
        }

        //Double vemploiprovisoire=null; //SPT_EMP_PROVISOIRE float
        try {
            updateinformationsspt.setSptEmpProvisoire(ValidatorUtils.parseDouble("PEmploiProvisoire", (String) multipartRequest.getParameter("PEmploiProvisoire"), request, recordEditorHelper, FieldConstraintsFactory.anyDouble(true)));
            if (updateinformationsspt.getSptEmpProvisoire() == null) {
                updateinformationsspt.setSptEmpProvisoire(new Double(0));
            }

        } catch (FieldConstraintsException e) {
        }

//        String venvoifichetechprod=null; //SPT_DT_ENV_FTECH_FAC date
        try {
            updateinformationsspt.setSptDtEnvFtechFac(ValidatorUtils.parseTimestamp("PEnvoiFicheTechProd", (String) multipartRequest.getParameter("PEnvoiFicheTechProd"), request, recordEditorHelper, FieldConstraintsFactory.anyTimestamp(true)));
        } catch (FieldConstraintsException e) {
        }

//        String venvoicoupetypeprod=null; //SPT_DT_ENV_CT_FAC date
        try {
            updateinformationsspt.setSptDtEnvCtFac(ValidatorUtils.parseTimestamp("PEnvoiCoupeTypeProd", (String) multipartRequest.getParameter("PEnvoiCoupeTypeProd"), request, recordEditorHelper, FieldConstraintsFactory.anyTimestamp(true)));
        } catch (FieldConstraintsException e) {
        }

//        String vrecepdisqpatronage=null; //SPT_RECEP_DISQ_PAT date
        try {
            updateinformationsspt.setSptRecepDisqPat(ValidatorUtils.parseTimestamp("PRecepDisqPatronage", (String) multipartRequest.getParameter("PRecepDisqPatronage"), request, recordEditorHelper, FieldConstraintsFactory.anyTimestamp(true)));
        } catch (FieldConstraintsException e) {
        }

//        String venvoipatronagefinal=null; //SPT_DT_ENV_PATRONAGE date
        try {
            updateinformationsspt.setSptDtEnvPatronage(ValidatorUtils.parseTimestamp("PEnvoiPatronageFinal", (String) multipartRequest.getParameter("PEnvoiPatronageFinal"), request, recordEditorHelper, FieldConstraintsFactory.anyTimestamp(true)));
        } catch (FieldConstraintsException e) {
        }

//        String vrecepfichetechprod=null;   //SPT_DT_RECEP_FTECH_FAC date
        try {
            updateinformationsspt.setSptDtRecepFtechFac(ValidatorUtils.parseTimestamp("PRecepFicheTechProd", (String) multipartRequest.getParameter("PRecepFicheTechProd"), request, recordEditorHelper, FieldConstraintsFactory.anyTimestamp(true)));
        } catch (FieldConstraintsException e) {
        }
//        String vrecepcoupetypeprod=null;   //SPT_DT_RECEP_CT_FAC date
        try {
            updateinformationsspt.setSptDtRecepCtFac(ValidatorUtils.parseTimestamp("PRecepCoupeTypeProd", (String) multipartRequest.getParameter("PRecepCoupeTypeProd"), request, recordEditorHelper, FieldConstraintsFactory.anyTimestamp(true)));
        } catch (FieldConstraintsException e) {
        }

//        String vnoprotoprod=null;  //SPP_NO_PROTO Integer
        try {
            updateinformationsspp.setSppNoProto(ValidatorUtils.parseInteger("PNoProtoProd", (String) multipartRequest.getParameter("PNoProtoProd"), request, recordEditorHelper, FieldConstraintsFactory.anyInt(true)));
        } catch (FieldConstraintsException e) {
        }

        //String vdateretourdemandee=null;  //SPP_DT_RETOUR_DDE date
        try {
            updateinformationsspp.setSppDtRetourDde(ValidatorUtils.parseTimestamp("PDateRetourDemandee", (String) multipartRequest.getParameter("PDateRetourDemandee"), request, recordEditorHelper, FieldConstraintsFactory.anyTimestamp(true)));
        } catch (FieldConstraintsException e) {
        }

//        String venvoiprototype2=null;        //  SPP_DT_ENV_PROTO date
        try {
            updateinformationsspp.setSppDtEnvProto(ValidatorUtils.parseTimestamp("PEnvoiPrototype2", (String) multipartRequest.getParameter("PEnvoiPrototype2"), request, recordEditorHelper, FieldConstraintsFactory.anyTimestamp(true)));
        } catch (FieldConstraintsException e) {
        }

        //String vreceptionprototype2=null;  //SPP_DT_RECEP_PROTO date
        try {
            updateinformationsspp.setSppDtRecepProto(ValidatorUtils.parseTimestamp("PReceptionPrototype2", (String) multipartRequest.getParameter("PReceptionPrototype2"), request, recordEditorHelper, FieldConstraintsFactory.anyTimestamp(true)));
        } catch (FieldConstraintsException e) {
        }

        //String vokProd=null;      //SPP_DEC_OK_PROD va1
        try {
            updateinformationsspp.setSppDecOkProd(ValidatorUtils.parseString("POkProd", (String) multipartRequest.getParameter("POkProd"), request, recordEditorHelper, FieldConstraintsFactory.any()));
        } catch (FieldConstraintsException e) {
        }

        //String vokprodtxt=null;                //SPP_DT_DEC_OK_PROD date
        try {
            updateinformationsspp.setSppDtDecOkProd(ValidatorUtils.parseTimestamp("POkProdTxt", (String) multipartRequest.getParameter("POkProdTxt"), request, recordEditorHelper, FieldConstraintsFactory.anyTimestamp(true)));
        } catch (FieldConstraintsException e) {
        }
//        String vteteSerieCB=null;           //SPT_DDE_TETE_SERIE va1
        try {
            String vteteSerieCB = ValidatorUtils.parseString("PTeteSerieCB", (String) multipartRequest.getParameter("PTeteSerieCB"), request, recordEditorHelper, FieldConstraintsFactory.any());
            updateinformationsspt.setSptDdeTeteSerie(vteteSerieCB != null ? "O" : "N");
        } catch (FieldConstraintsException e) {
        }

//        String vteteserietxt=null;       //SPT_TETE_SERIE date
        try {
            updateinformationsspt.setSptTeteSerie(ValidatorUtils.parseTimestamp("PTeteSerieTxt", (String) multipartRequest.getParameter("PTeteSerieTxt"), request, recordEditorHelper, FieldConstraintsFactory.anyTimestamp(true)));
        } catch (FieldConstraintsException e) {
        }


//        String vokaccessoires=null;   //SPT_OK_ACCESSOIRES date
        try {
            updateinformationsspt.setSptOkAccessoires(ValidatorUtils.parseTimestamp("POkAccessoires", (String) multipartRequest.getParameter("POkAccessoires"), request, recordEditorHelper, FieldConstraintsFactory.anyTimestamp(true)));
        } catch (FieldConstraintsException e) {
        }

        //String vokcoloris=null;           //SPT_OK_COLORIS date
        try {
            updateinformationsspt.setSptOkColoris(ValidatorUtils.parseTimestamp("POkColoris", (String) multipartRequest.getParameter("POkColoris"), request, recordEditorHelper, FieldConstraintsFactory.anyTimestamp(true)));
        } catch (FieldConstraintsException e) {
        }

        //String vemploidefinitif=null; //SPT_EMPLOI_DEF float
        try {
            updateinformationsspt.setSptEmploiDef(ValidatorUtils.parseDouble("PEmploiDefinitif", (String) multipartRequest.getParameter("PEmploiDefinitif"), request, recordEditorHelper, FieldConstraintsFactory.anyDouble(true)));
            if (updateinformationsspt.getSptEmploiDef() == null) {
                updateinformationsspt.setSptEmploiDef(new Double(0));
            }
        } catch (FieldConstraintsException e) {
        }

        //String vokmatiere=null;             //SPT_OK_MATIERE date
        try {
            updateinformationsspt.setSptOkMatiere(ValidatorUtils.parseTimestamp("POkMatiere", (String) multipartRequest.getParameter("POkMatiere"), request, recordEditorHelper, FieldConstraintsFactory.anyTimestamp(true)));
        } catch (FieldConstraintsException e) {
        }

        //String vvalidechcontsource=null; //SPT_VALID_ECHAN_SOURCE date
        try {
            updateinformationsspt.setSptValidEchanSource(ValidatorUtils.parseTimestamp("PValidEchContSource", (String) multipartRequest.getParameter("PValidEchContSource"), request, recordEditorHelper, FieldConstraintsFactory.anyTimestamp(true)));
        } catch (FieldConstraintsException e) {
        }

//        String vokprodentrepot=null; //SPT_OK_PROD_ENTREP date
        try {
            updateinformationsspt.setSptOkProdEntrep(ValidatorUtils.parseTimestamp("POkProdEntrepot", (String) multipartRequest.getParameter("POkProdEntrepot"), request, recordEditorHelper, FieldConstraintsFactory.anyTimestamp(true)));
        } catch (FieldConstraintsException e) {
        }

        //String vcommentachat=null; //SPT_COMMENT_ACHATS va200
        try {
            updateinformationsspt.setSptCommentAchats(ValidatorUtils.parseString("PCommentAchat", (String) multipartRequest.getParameter("PCommentAchat"), request, recordEditorHelper, FieldConstraintsFactory.any()));
        } catch (FieldConstraintsException e) {
        }

        //String vcommentmodeliste=null; //SPT_COMMENT_MODELISTE va200
        try {
            updateinformationsspt.setSptCommentModeliste(ValidatorUtils.parseString("PCommentModeliste", (String) multipartRequest.getParameter("PCommentModeliste"), request, recordEditorHelper, FieldConstraintsFactory.any()));
        } catch (FieldConstraintsException e) {
        }

//        String vcommentbureau=null;    //SPT_COMMENT_BUREAU va200
        try {
            updateinformationsspt.setSptCommentBureau(ValidatorUtils.parseString("PCommentBureau", (String) multipartRequest.getParameter("PCommentBureau"), request, recordEditorHelper, FieldConstraintsFactory.any()));
        } catch (FieldConstraintsException e) {
        }

        MergedDoSuivi updateinformation = new MergedDoSuivi(updateinformationsspt, updateinformationsspm, updateinformationsspp);

        if (recordEditorHelper.getErrorsCount() == 0) {
            //----------si pas d'erreurs effectuer la sauveguarde du modele
            // test mise � jour /insertion
            if (isUpdateMode) {
                //mise � jour
                updateinformationsspt.setSptModeleCode(Integer.valueOf(vcmodele));
                if (fcommentMap != null && updateinformationsspm.getSpmNoProto() != null) {
                    new BosuiviProtoMap().uploadFile(fcommentMap, Integer.valueOf(vcmodele), updateinformationsspm.getSpmNoProto());
                }
                if (fcommentProd != null && updateinformationsspp.getSppNoProto() != null) {
                    new BosuiviProtoMap().uploadFile(fcommentProd, Integer.valueOf(vcmodele), updateinformationsspp.getSppNoProto());
                }

                new BoFichiers().doUploadFiles(ftech, fbaremeMens, fpatronnage, fnomenclature, Integer.valueOf(vcmodele));

                boolean c = new BosuiviProtoTete().updateRow(updateinformation);
            } else {
                //insertion
                // calcul du num�ro du nouveau modele
                Integer newModele = new BosuiviProtoTete().getNumNouveauModele();
                updateinformationsspm.setSpmSptModeleCode(newModele);
                updateinformationsspp.setSppSptModeleCode(newModele);
                updateinformationsspt.setSptModeleCode(newModele);


                updateinformationsspp.setSppNoProto(new Integer(1));
                updateinformationsspm.setSpmNoProto(new Integer(1));
                updateinformationsspt.setSptStatus("O");
                boolean c = new BosuiviProtoTete().insertRow(updateinformation);
                if (fcommentMap != null && updateinformationsspm.getSpmNoProto() != null) {
                    new BosuiviProtoMap().uploadFile(fcommentMap, Integer.valueOf(vcmodele), updateinformationsspm.getSpmNoProto());
                }
                if (fcommentProd != null && updateinformationsspp.getSppNoProto() != null) {
                    new BosuiviProtoMap().uploadFile(fcommentProd, Integer.valueOf(vcmodele), updateinformationsspp.getSppNoProto());
                }
                new BoFichiers().doUploadFiles(ftech, fbaremeMens, fpatronnage, fnomenclature, newModele);
            }
            request.setAttribute(PDMRequestConstants.ERREUR, "0");
            //rafraichir le tableau suivi
            return mapping.findForward("ok");
        } else {

            request.setAttribute(PDMRequestConstants.ERREUR, "1");
            BoParametres droits = new BoParametres();
            request.setAttribute(PDMRequestConstants.DROITS, droits.getParametres());
            BoaccessLog logs = new BoaccessLog();
            request.setAttribute(PDMRequestConstants.LOGS, logs.getAllAccessLog());

            if (!isUpdateMode) {
                updateinformation.setRecordEditorHelper(recordEditorHelper);
                request.getSession().setAttribute(PDMSessionConstants.MODELE_DO_SUIVI_PROTO_TETE, updateinformation);
            }
            return mapping.findForward("erreur");
        }
    }
}
