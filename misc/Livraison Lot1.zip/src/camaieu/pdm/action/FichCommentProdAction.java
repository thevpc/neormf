package camaieu.pdm.action;

import camaieu.pdm.bo.BosuiviProtoProd;
import camaieu.pdm.common.PDMRequestConstants;
import camaieu.pdm.dataobject.DosuiviProtoProd;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author tijani Souissi (ADD'IT Tunisie)
 * @creation_date date 21/01/2004
 * @last_modification_date 28/07/2004
 * @last_modification_date 28/07/2004
 * @status pour validation
 */
public class FichCommentProdAction extends Action {

    /**
     * @see Action#execute(ActionMapping, ActionForm, HttpServletRequest, HttpServletResponse)
     */
    public final ActionForward execute(ActionMapping mapping, ActionForm form,
                                       HttpServletRequest request,
                                       HttpServletResponse response) throws Exception {


        String ficmodeleid = request.getParameter(PDMRequestConstants.MODELE_ID);
        String noProto = request.getParameter(PDMRequestConstants.NO_PROTO);


        DosuiviProtoProd file = new BosuiviProtoProd().loadFichier(Integer.valueOf(ficmodeleid), Integer.valueOf(noProto));
        request.setAttribute(PDMRequestConstants.FILE_TYPE, "FCP");
        if (file != null) {
            request.setAttribute(PDMRequestConstants.FILE, file);


        } else {
            request.setAttribute(PDMRequestConstants.ERREUR, "1");
        }
        return mapping.findForward("ok");
    }
}
