package camaieu.pdm.action;

import camaieu.pdm.bo.BoParametres;
import camaieu.pdm.bo.BoaccessLog;
import camaieu.pdm.bo.BosuiviProtoProd;
import camaieu.pdm.bo.BosuiviProtoTete;
import camaieu.pdm.common.MapXnCollection;
import camaieu.pdm.common.MapXnFour;
import camaieu.pdm.common.PDMRequestConstants;
import camaieu.pdm.common.PDMSessionConstants;
import camaieu.pdm.dataobject.MergedDoSuivi;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;

/**
 * @author tijani Souissi (ADD'IT Tunisie)
 * @creation_date date 21/01/2004
 * @last_modification_date 28/07/2004
 * @last_modification_date 28/07/2004
 * @status pour validation
 */
public class InsertSPPAction extends Action {
    /**
     * @see Action#execute(ActionMapping, ActionForm, HttpServletRequest, HttpServletResponse)
     */
    public final ActionForward execute(ActionMapping mapping, ActionForm form,
                                       HttpServletRequest request,
                                       HttpServletResponse response) throws Exception {


        // insere un nouveau prototype prod
        String modele = (String) request.getParameter(PDMRequestConstants.MODELE_ID);

        BosuiviProtoProd bosuiviProtoProd = new BosuiviProtoProd();
        bosuiviProtoProd.insertRow(modele);

        /// rafraichir modele apr�s insertion d'un nouveau prototype PROD

        BosuiviProtoTete bosuiviProtoTete = new BosuiviProtoTete();
        MergedDoSuivi[] dosuiviProtoTete = bosuiviProtoTete.getAllDosuiviProtoTete(null, null, null, null, modele
                ,
                (MapXnFour) request.getSession().getAttribute(PDMSessionConstants.MAP_XN_FOUR_FAC),
                (MapXnCollection) request.getSession().getAttribute(PDMSessionConstants.MAP_XN_COLLECTION),
                (HashMap) request.getSession().getAttribute(PDMSessionConstants.ALL_DELAI_HASHMAP)
                , request);

        //mise � jour ....

        request.setAttribute(PDMRequestConstants.MODELE, dosuiviProtoTete[0]);
        request.getSession().setAttribute(PDMSessionConstants.MODELE_DO_SUIVI_PROTO_TETE, dosuiviProtoTete[0]);
        request.setAttribute(PDMRequestConstants.IS_UPDATE_MODE, "1");

        BoaccessLog logs = new BoaccessLog();
        request.setAttribute(PDMRequestConstants.LOGS, logs.getAllAccessLog());

        BoParametres droits = new BoParametres();
        request.setAttribute(PDMRequestConstants.DROITS, droits.getParametres());


        return mapping.findForward("ok");
    }
}

