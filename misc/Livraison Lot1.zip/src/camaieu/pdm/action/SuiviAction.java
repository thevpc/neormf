package camaieu.pdm.action;

import camaieu.pdm.bo.BoFichiers;
import camaieu.pdm.bo.BosuiviProtoTete;
import camaieu.pdm.common.*;
import camaieu.pdm.dataobject.DoFichiers;
import camaieu.pdm.dataobject.MergedDoSuivi;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

/**
 * @author tijani So�uissi (ADD'IT Tunisie)
 * @creation_date date 21/01/2004
 * @last_modification_date 28/07/2004
 * @last_modification_date 28/07/2004
 * @status pour validation
 */
public class SuiviAction extends Action {
    /**
     * @see Action#execute(ActionMapping, ActionForm, HttpServletRequest, HttpServletResponse)
     */
    public final ActionForward execute(ActionMapping mapping, ActionForm form,
                                       HttpServletRequest request,
                                       HttpServletResponse response) throws Exception {


        String suiviFiltreFamille = (String) request.getParameter(PDMRequestConstants.SUIV_FILTRE_FAMILLE);
        String suiviFiltreCollection = (String) request.getParameter(PDMRequestConstants.SUIVI_FILTRE_COLLECTION);
        String suiviFiltrePays = (String) request.getParameter(PDMRequestConstants.SUIVI_FILTRE_PAYS);
        String suiviFiltreEtat = (String) request.getParameter(PDMRequestConstants.SUIVI_FILTRE_ETAT);
        String csv = (String) request.getParameter(PDMRequestConstants.CSV);
        if (suiviFiltreFamille != null && suiviFiltreFamille.length() == 0) {
            suiviFiltreFamille = null;
        }
        if (suiviFiltreCollection != null && suiviFiltreCollection.length() == 0) {
            suiviFiltreCollection = null;
        }
        if (suiviFiltrePays != null && suiviFiltrePays.length() == 0) {
            suiviFiltrePays = null;
        }
        if (suiviFiltreEtat != null && suiviFiltreEtat.length() == 0) {
            suiviFiltreEtat = null;
        }

        String userFamily = PDMUtils.getCurrentUserFamily(request);
        String userRole = PDMUtils.getCurrentUserRole(request);

        if (PDMBusinessConstants.ROLE_AC.equals(userRole) ||
                PDMBusinessConstants.ROLE_MO.equals(userRole)) {
            suiviFiltreFamille = userFamily;
        }

        if (suiviFiltreFamille != null && !"-".equals(userFamily)) {
            suiviFiltreFamille = userFamily;
        }
        if ("-".equals(userFamily)) {
            suiviFiltreFamille = null;
        }
        if (suiviFiltreFamille == null) {
            suiviFiltreFamille = userFamily;
        }

        request.setAttribute("suivi_filtre_famille", suiviFiltreFamille);
        request.setAttribute("suivi_filtre_collection", suiviFiltreCollection);
        request.setAttribute("suivi_filtre_pays", suiviFiltrePays);
        request.setAttribute("suivi_filtre_etat", suiviFiltreEtat);
        MapXnFour faconniers = (MapXnFour) request.getSession().getAttribute(PDMSessionConstants.MAP_XN_FOUR_FAC);

        String pays = "";
        if (suiviFiltrePays != null && faconniers != null) {
            for (int i = 0; i < faconniers.getArray().length; i++) {
                if (suiviFiltrePays.equals(faconniers.getArray()[i].getFouPayCodeFab())) {
                    pays += ("'" + faconniers.getArray()[i].getFouCode() + "',");
                }
            }
        }
        if (pays != "") {
            pays = "(" + pays.substring(0, pays.length() - 1) + ")";
        }


        BosuiviProtoTete bosuiviProtoTete = new BosuiviProtoTete();
        BoFichiers boFichiers = new BoFichiers();
        MergedDoSuivi[] mergedDoSuiviLignes = bosuiviProtoTete.getAllDosuiviProtoTete(suiviFiltreCollection,
                suiviFiltreFamille,
                pays,
                suiviFiltreEtat,
                null,
                faconniers,
                (MapXnCollection) request.getSession().getAttribute(PDMSessionConstants.MAP_XN_COLLECTION),
                (HashMap) request.getSession().getAttribute(PDMSessionConstants.ALL_DELAI_HASHMAP)
                , request);

        long today = System.currentTimeMillis();
        //Determiner les premi�res versions des fichiers associ�es � un mod�le
        for (int i = 0; i < mergedDoSuiviLignes.length; i++) {
            MergedDoSuivi line = mergedDoSuiviLignes[i];
            Timestamp nearestDate = null;
            DoFichiers[] fichiers = boFichiers.getModeleFiles(line.getDosuiviProtoTete().getSptModeleCode(), new Integer(1));
            line.setFichiers(fichiers);
            ArrayList allPossibleDates = new ArrayList();
            for (int j = 0; j < fichiers.length; j++) {
                allPossibleDates.add(fichiers[j].getFicDate());
            }

            allPossibleDates.add(line.getDosuiviProtoTete().getSptDtTransmission());
            allPossibleDates.add(line.getDosuiviProtoTete().getSptDtEnvFtechBur());
            allPossibleDates.add(line.getDosuiviProtoTete().getSptDtEnvCtBur());
            allPossibleDates.add(line.getDosuiviProtoTete().getSptDtRecepFtechBur());
            allPossibleDates.add(line.getDosuiviProtoTete().getSptDtRecepCtBur());
            allPossibleDates.add(line.getDosuiviProtoTete().getSptDtEnvFtechFac());
            allPossibleDates.add(line.getDosuiviProtoTete().getSptDtEnvCtFac());
            allPossibleDates.add(line.getDosuiviProtoTete().getSptDtRecepPat());
            allPossibleDates.add(line.getDosuiviProtoTete().getSptDtTransmission());

            allPossibleDates.add(line.getDosuiviProtoMap().getSpmDtRetourDde());
            allPossibleDates.add(line.getDosuiviProtoMap().getSpmDtRecepProto());
            allPossibleDates.add(line.getDosuiviProtoMap().getSpmDtReunionProd());
            allPossibleDates.add(line.getDosuiviProtoMap().getSpmDtDecisionOkMap());

            allPossibleDates.add(line.getDosuiviProtoProd().getSppDtRetourDde());
            allPossibleDates.add(line.getDosuiviProtoProd().getSppDtRecepProto());
            allPossibleDates.add(line.getDosuiviProtoProd().getSppDtRecepProto());
            allPossibleDates.add(line.getDosuiviProtoProd().getSppDtDecOkProd());

            for (Iterator iter = allPossibleDates.iterator(); iter.hasNext();) {
                Timestamp timestamp = (Timestamp) iter.next();
                if (
                        timestamp != null
                        &&
                        (today < timestamp.getTime())
                        &&
                        (nearestDate == null || nearestDate.getTime() > timestamp.getTime())
                ) {
                    nearestDate = timestamp;
                }
            }
            line.setNearestDate(nearestDate);
        }
        request.setAttribute(PDMRequestConstants.SUIVI_MERGED_DO_SUIVI_ARRAY, mergedDoSuiviLignes);
        if ("true".equals(csv)) {
            return mapping.findForward("csv");
        } else {
            return mapping.findForward("ok");
        }

    }
}
