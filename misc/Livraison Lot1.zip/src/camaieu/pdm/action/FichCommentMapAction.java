package camaieu.pdm.action;

import camaieu.pdm.bo.BosuiviProtoMap;
import camaieu.pdm.common.PDMRequestConstants;
import camaieu.pdm.dataobject.DosuiviProtoMap;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author tijani Souissi (ADD'IT Tunisie)
 * @creation_date date 21/01/2004
 * @last_modification_date 28/07/2004
 * @last_modification_date 28/07/2004
 * @status pour validation
 */
public class FichCommentMapAction extends Action {

    /**
     * @see Action#execute(ActionMapping, ActionForm, HttpServletRequest, HttpServletResponse)
     */
    public final ActionForward execute(ActionMapping mapping, ActionForm form,
                                       HttpServletRequest request,
                                       HttpServletResponse response) throws Exception {


        String vcmodele = (String) request.getParameter(PDMRequestConstants.MODELE_ID);       //SPT_MODELE_CODE interger
        String noProto = (String) request.getParameter(PDMRequestConstants.NO_PROTO );

        DosuiviProtoMap file = new BosuiviProtoMap().loadFichier(Integer.valueOf(vcmodele), Integer.valueOf(noProto));
        request.setAttribute(PDMRequestConstants.FILE_TYPE, "FCM");
        if (file != null) {
            request.setAttribute(PDMRequestConstants.FILE, file);
        } else {
            request.setAttribute(PDMRequestConstants.ERREUR, "1");
        }
        return mapping.findForward("ok");
    }
}
