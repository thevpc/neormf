package camaieu.pdm.action;

import camaieu.pdm.bo.BoFichiers;
import camaieu.pdm.bo.BoParametres;
import camaieu.pdm.bo.BosuiviProtoTete;
import camaieu.pdm.common.PDMRequestConstants;
import camaieu.pdm.common.PDMSessionConstants;
import camaieu.pdm.dataobject.MergedDoSuivi;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author tijani Souissi (ADD'IT Tunisie)
 * @creation_date date 21/01/2004
 * @last_modification_date 28/07/2004
 * @last_modification_date 28/07/2004
 * @status pour validation
 */
public class DeleteFileAction extends Action {

    /**
     * @see Action#execute(org.apache.struts.action.ActionMapping, org.apache.struts.action.ActionForm, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    public final ActionForward execute(ActionMapping mapping, ActionForm form,
                                       HttpServletRequest request,
                                       HttpServletResponse response) throws Exception {


        String ficchamp = request.getParameter(PDMRequestConstants.FIC_CHAMP );
        String ficversion = request.getParameter(PDMRequestConstants.FIC_VERSION );
        String ficmodeleid = request.getParameter(PDMRequestConstants.MODELE_ID);

        new BoFichiers().deleteFile(ficchamp, Integer.valueOf(ficversion), Integer.valueOf(ficmodeleid));

        BosuiviProtoTete bosuiviProtoTete = new BosuiviProtoTete();
        MergedDoSuivi[] dosuiviProtoTete = bosuiviProtoTete.getAllDosuiviProtoTete(null, null, null, null, ficmodeleid, request);
        request.getSession().setAttribute(PDMSessionConstants.MODELE_DO_SUIVI_PROTO_TETE, dosuiviProtoTete[0]);
        request.setAttribute(PDMRequestConstants.IS_UPDATE_MODE, "1");

        BoParametres droits = new BoParametres();
        request.setAttribute(PDMRequestConstants.DROITS, droits.getParametres());

        return mapping.findForward("ok");
    }
}
