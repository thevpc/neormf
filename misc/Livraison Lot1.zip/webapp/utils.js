function changeEcran() {
	window.location="achat_"+document.filtreForm.collection.selectedIndex+document.filtreForm.famille.selectedIndex+document.filtreForm.bureau.selectedIndex+document.filtreForm.etat.selectedIndex+".html";
}

function openDetails() {
	w = 400;
	h = 610;
	l = (screen.availWidth - w) / 2;
	t = (screen.availHeight - h) / 2;
	var fenetre = window.open('details.html','nouveau_modele','width='+w+',height='+h+',resizable=no,scrollbars=yes,status=no,toolbar=no,location=no,menubar=no,top='+t+',left='+l);
}

function openCreate() {
	w = 400;
	h = 550;
	l = (screen.availWidth - w) / 2;
	t = (screen.availHeight - h) / 2;
	var fenetre = window.open('details.html','nouveau_modele','width='+w+',height='+h+',resizable=no,scrollbars=yes,status=no,toolbar=no,location=no,menubar=no,top='+t+',left='+l);
}

function openAlerte() {
	w = 400;
	h = 200;
	l = (screen.availWidth - w) / 2;
	t = (screen.availHeight - h) / 2;
	var fenetre = window.open('exemple_alertes.html','alerte','width='+w+',height='+h+',resizable=no,scrollbars=yes,status=no,toolbar=no,location=no,menubar=no,top='+t+',left='+l);	
}

function openHistoProto(file) {
	w = 450;
	h = 270;
	l = (screen.availWidth - w) / 2;
	t = (screen.availHeight - h) / 2;
	//var fenetre = window.open(file,'alerte','width=450,height=270,resizable=no,scrollbars=yes,status=no,toolbar=no,location=no,menubar=no,top='+t+',left='+l);
	var fenetre = window.open(file,'alerte','width=500,height=500,resizable=no,scrollbars=yes,status=no,toolbar=no,location=no,menubar=no');

}

function openHistoProtoProd(file) {
	w = 450;
	h = 250;
	l = (screen.availWidth - w) / 2;
	t = (screen.availHeight - h) / 2;
	//var fenetre = window.open(file,'alerte','width='+w+',height='+h+',resizable=no,scrollbars=yes,status=no,toolbar=no,location=no,menubar=no,top='+t+',left='+l);
	var fenetre = window.open(file,'alerte','width=500,height=500,resizable=no,scrollbars=yes,status=no,toolbar=no,location=no,menubar=no');
}

function openHistoFichier(file) {
	w = 450;
	h = 500;
	l = (screen.availWidth - w) / 2;
	t = (screen.availHeight - h) / 2;
	//var fenetre = window.open(file,'alerte','width=450,height=270,resizable=no,scrollbars=yes,status=no,toolbar=no,location=no,menubar=no,top='+t+',left='+l);
	var fenetre = window.open(file,'alerte','width=500,height=500,resizable=no,scrollbars=yes,status=no,toolbar=no,location=no,menubar=no');
}

function testAlerte() {
	window.showModalDialog("alerte_window.html", "", "dialogHeight: 300px; edge: raised; status: yes; unadorned: yes;");
}

function openDetailsModeliste() {
	w = 400;
	h = 610;
	l = (screen.availWidth - w) / 2;
	t = (screen.availHeight - h) / 2;
	var fenetre = window.open('modeliste_details.html','nouveau_modele','width='+w+',height='+h+',resizable=no,scrollbars=yes,status=no,toolbar=no,location=no,menubar=no,top='+t+',left='+l);
}

var tps_histo_fiche_tech = 0;
var max_tps_histo_fiche_tech = 3;

function montreCalque(calque) {
	calque.style.visibility='visible';
}

function decompte() {
	if (tps_histo_fiche_tech>0) {
		tps_histo_fiche_tech--;
		if (tps_histo_fiche_tech==0) {
			histo_fiche_tech.style.visibility='hidden';
		}
	}
	setTimeout("decompte()",1000);
}

function deleteJs() {
    res=window.confirm("Etes-vous s�r(e) de vouloir annuler ce mod�le ?");
    if (res==true)
        document.deleteForm.submit();
          window.opener.opener='';
          window.opener.close();


}
function deleteFile(lien) {
    res=window.confirm("Etes-vous s�r(e) de vouloir supprimer ce fichier ?");
    if (res==true)
        window.parent.open(lien);
}
function copyJs() {
    res=window.confirm("Etes-vous s�r(e) de vouloir copier ce mod�le ?");
    if (res==true)
        document.copyForm.submit();
}

function insertSPM(lien) {
       if (document.savedata.POkMAp[0].checked==true)
       {
          alert("On ne peut pas demander un autre prototype s''il est accept� ");
       }else if(document.savedata.POkMAp[1].checked==true) {
          window.open(lien);
          window.opener='';
          window.close();
       }
}
function insertSPP(lien) {
       if (document.savedata.POkProd[0].checked==true)
       {
         alert("On ne peut pas demander un autre prototype s''il est accept� ");
       }else if(document.savedata.POkProd[1].checked==true) {
         window.open(lien);
         window.opener='';
         window.close();
       }
}

function bureauEtudeFaconnierClick(){
    if (document.savedata.PTypeBureau[2].checked==true){
           document.savedata.POkProd[0].disabled=true;
           document.savedata.POkProd[1].disabled=true;
           document.savedata.POkProdTxt.disabled=true;
           document.savedata.POkProdTxt.value='';
    }else{
           document.savedata.POkProd[0].disabled=  false;
           document.savedata.POkProd[1].disabled=  false;
           document.savedata.POkProdTxt.disabled=  false;
    }
}
function toDay(){
var d=new Date();
var aujourdhui=d.getDate()+'/';
if (d.getDate()<10) {
   aujourdhui='0'+d.getDate()+'/';
}
if (d.getMonth()<10){
   aujourdhui+='0'+d.getMonth()+'/';
}else{
   aujourdhui+=d.getMonth()+'/';
}
if ((d.getYear()%100)<10){
   aujourdhui+='0'+ (d.getYear()%100);
}else{
   aujourdhui+=(d.getYear()%100);
}
   return(aujourdhui);
}

function okMapClick( estAccepte){
    document.savedata.POkMapText.value=toDay();
    ////accepte
    if (estAccepte==true){
        // si le bureau d'etude est un fa�onnier
        if (document.savedata.PTypeBureau[2].checked==true){
            document.savedata.POkProd[0].disabled=false;
            document.savedata.POkProd[1].disabled=false;
            document.savedata.POkProdTxt.disabled=false;

            document.savedata.POkProd[0].checked=true;
            document.savedata.POkProd[1].checked=false;
            document.savedata.POkProdTxt.value=toDay();
        }
    }else{     //refus�

            document.savedata.POkProd[0].disabled=true;
            document.savedata.POkProd[1].disabled=true;
            document.savedata.POkProdTxt.disabled=true;
            document.savedata.POkProdTxt.value='';
    }

}
 function initStatus( estAccepte){
    window.focus();
    bureauEtudeFaconnierClick();
    okMapClick( estAccepte);
 }