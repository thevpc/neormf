using System;
using org.vpc.neormf.commons.beans;

namespace org.vpc.neormf.testjbgen.dto.facture{
/**
* DO NOT EDIT MANUALLY
* GENERATED AUTOMATICALLY BY JBGen (0.1)
* @author Taha BEN SALAH (thevpc@walla.com)
* @organization Vpc Open Source Fondation 2001-2006
* @framework neormf (license GPL2)
* 
*/
public class FactureKey : org.vpc.neormf.commons.beans.DataKey{
  public int facId;
  /**
  * Constructor
  */
  public FactureKey(){

  }

  /**
  * Constructor
  */
  public FactureKey(int facId){
    this.facId=facId;

  }

  public int GetFacId(){
    return facId;
  }

  public override Object KeyPartAt(int index){
    return facId;

  }

  public override int KeySize(){
    return 1;
  }

  public override DataInfo Info(){
    return FactureDTO.INFO;
  }

}
}
