using System;
using System.Collections;
using org.vpc.neormf.commons.beans;
using org.vpc.neormf.commons.util;
using org.vpc.neormf.commons.types;
using org.vpc.neormf.commons.types.converters;

namespace org.vpc.neormf.testjbgen.dto.lignefacture{
/**
* DO NOT EDIT MANUALLY
* GENERATED AUTOMATICALLY BY JBGen (0.1)
* @author Taha BEN SALAH (thevpc@walla.com)
* @organization Vpc Open Source Fondation 2001-2006
* @framework neormf (license GPL2)
* 
*/
public class LigneFactureDTO : DataContent{
  public static  DataInfo INFO= new DataInfo(
  // Bean Name
  "LigneFacture"
  // Bean Fields(name,title,column,type,sqlType,sqlConverter)...
  ,new DataField[]{
    new DataField("lnfArtId", "Lnf Art Id", "LNF_ART_ID", null,IntType.INT_NON_NULLABLE,null),
    new DataField("lnfFacId", "Lnf Fac Id", "LNF_FAC_ID", null,IntType.INT_NON_NULLABLE,null),
    new DataField("lnfQte", "Lnf Qte", "LNF_QTE", null,IntType.INT_NULLABLE,null),
    new DataField("lnfPrix", "Lnf Prix", "LNF_PRIX", null,new DoubleType(true,-1.0E53,1.0E53),null)
  },
  // Primary fields
  new String[]{"lnfArtId","lnfFacId"},
  // Title Field Name
  "lnfArtId",
  // DataContent Class Name
  "org.vpc.neormf.testjbgen.dto.lignefacture.LigneFactureDTO",
  // DataKey Class Name
  "org.vpc.neormf.testjbgen.dto.lignefacture.LigneFactureKey",
  // PropertyList Class Name
  "org.vpc.neormf.testjbgen.dto.lignefacture.LigneFactureProperties",
  // Default Order by fields
  null,null,
  // Extra Properties
  (Hashtable)Maps.fill(new Hashtable(),new Object[]{
    "BeanName",
  },new Object[]{
    "LigneFacture",
  }
  ))
  ;
  /**
  * attribute for lnfArtId
  */
  public int LnfArtId{
  get{
    return ((int)base.GetProperty(LigneFactureProperties.LNF_ART_ID));
  }
  set{
    base.SetProperty(LigneFactureProperties.LNF_ART_ID,value);
  }
  }

  /**
  * attribute for lnfFacId
  */
  public int LnfFacId{
  get{
    return ((int)base.GetProperty(LigneFactureProperties.LNF_FAC_ID));
  }
  set{
    base.SetProperty(LigneFactureProperties.LNF_FAC_ID,value);
  }
  }

  /**
  * attribute for lnfQte
  */
  public int LnfQte{
  get{
    return ((int)base.GetProperty(LigneFactureProperties.LNF_QTE));
  }
  set{
    base.SetProperty(LigneFactureProperties.LNF_QTE,value);
  }
  }

  /**
  * attribute for lnfPrix
  */
  public double LnfPrix{
  get{
    return ((double)base.GetProperty(LigneFactureProperties.LNF_PRIX));
  }
  set{
    base.SetProperty(LigneFactureProperties.LNF_PRIX,value);
  }
  }

  /**
  * Constructor
  */
  public LigneFactureDTO(){

  }

  /**
  * true if record contains the field lnfArtId
  */
  public bool ContainsLnfArtId(){
    return base.ContainsProperty(LigneFactureProperties.LNF_ART_ID);
  }

  /**
  * remove the field lnfArtId
  */
  public void UnsetLnfArtId(){
    base.UnsetProperty(LigneFactureProperties.LNF_ART_ID);
  }

  /**
  * true if record contains the field lnfFacId
  */
  public bool ContainsLnfFacId(){
    return base.ContainsProperty(LigneFactureProperties.LNF_FAC_ID);
  }

  /**
  * remove the field lnfFacId
  */
  public void UnsetLnfFacId(){
    base.UnsetProperty(LigneFactureProperties.LNF_FAC_ID);
  }

  /**
  * true if record contains the field lnfQte
  */
  public bool ContainsLnfQte(){
    return base.ContainsProperty(LigneFactureProperties.LNF_QTE);
  }

  /**
  * remove the field lnfQte
  */
  public void UnsetLnfQte(){
    base.UnsetProperty(LigneFactureProperties.LNF_QTE);
  }

  /**
  * true if record contains the field lnfPrix
  */
  public bool ContainsLnfPrix(){
    return base.ContainsProperty(LigneFactureProperties.LNF_PRIX);
  }

  /**
  * remove the field lnfPrix
  */
  public void UnsetLnfPrix(){
    base.UnsetProperty(LigneFactureProperties.LNF_PRIX);
  }

  public LigneFactureKey GetLigneFactureKey(){
    Object k0=base.GetProperty(LigneFactureProperties.LNF_ART_ID);
    if(k0==null){
      return null;
    }
    Object k1=base.GetProperty(LigneFactureProperties.LNF_FAC_ID);
    if(k1==null){
      return null;
    }
    return new LigneFactureKey(((int)k0),((int)k1));
  }

  public override org.vpc.neormf.commons.beans.DataKey GetDataKey(){
    return GetLigneFactureKey();
  }

  public override DataInfo Info(){
    return INFO;
  }

}
}
