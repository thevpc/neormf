using System;
using System.Collections;
using org.vpc.neormf.commons.beans;

namespace org.vpc.neormf.testjbgen.dto.client{
/**
* DO NOT EDIT MANUALLY
* GENERATED AUTOMATICALLY BY JBGen (0.1)
* @author Taha BEN SALAH (thevpc@walla.com)
* @organization Vpc Open Source Fondation 2001-2006
* @framework neormf (license GPL2)
* 
*/
public class ClientProperties : org.vpc.neormf.commons.beans.PropertyList{
  public static String CLI_ID="cliId";
  public static String CLI_NOM="cliNom";
  public static String CLI_ADDRESSE="cliAddresse";
  public static String CLI_ADDRESSE_2="cliAddresse2";
  public static String CL_ADDRESSE_3="clAddresse3";
  public static String[] ALL_PROPERTIES={CLI_ID,CLI_NOM,CLI_ADDRESSE,CLI_ADDRESSE_2,CL_ADDRESSE_3};
  /**
  * Constructor
  */
  public ClientProperties(){

  }

  public ClientProperties AddCliId(){
    base.AddProperty(CLI_ID);
    return this;
  }

  public ClientProperties RemoveCliId(){
    base.RemoveProperty(CLI_ID);
    return this;
  }

  public bool ContainsCliId(){
    return base.ContainsProperty(CLI_ID);
  }

  public ClientProperties AddCliNom(){
    base.AddProperty(CLI_NOM);
    return this;
  }

  public ClientProperties RemoveCliNom(){
    base.RemoveProperty(CLI_NOM);
    return this;
  }

  public bool ContainsCliNom(){
    return base.ContainsProperty(CLI_NOM);
  }

  public ClientProperties AddCliAddresse(){
    base.AddProperty(CLI_ADDRESSE);
    return this;
  }

  public ClientProperties RemoveCliAddresse(){
    base.RemoveProperty(CLI_ADDRESSE);
    return this;
  }

  public bool ContainsCliAddresse(){
    return base.ContainsProperty(CLI_ADDRESSE);
  }

  public ClientProperties AddCliAddresse2(){
    base.AddProperty(CLI_ADDRESSE_2);
    return this;
  }

  public ClientProperties RemoveCliAddresse2(){
    base.RemoveProperty(CLI_ADDRESSE_2);
    return this;
  }

  public bool ContainsCliAddresse2(){
    return base.ContainsProperty(CLI_ADDRESSE_2);
  }

  public ClientProperties AddClAddresse3(){
    base.AddProperty(CL_ADDRESSE_3);
    return this;
  }

  public ClientProperties RemoveClAddresse3(){
    base.RemoveProperty(CL_ADDRESSE_3);
    return this;
  }

  public bool ContainsClAddresse3(){
    return base.ContainsProperty(CL_ADDRESSE_3);
  }

  public override void AddAllProperties(){
    base.AddAllProperties(ALL_PROPERTIES);

  }

  public override DataInfo Info(){
    return ClientDTO.INFO;
  }

}
}
