using System;
using System.Collections;
using org.vpc.neormf.commons.beans;
using org.vpc.neormf.commons.util;
using org.vpc.neormf.commons.types;
using org.vpc.neormf.commons.types.converters;

namespace org.vpc.neormf.testjbgen.dto.client{
/**
* DO NOT EDIT MANUALLY
* GENERATED AUTOMATICALLY BY JBGen (0.1)
* @author Taha BEN SALAH (thevpc@walla.com)
* @organization Vpc Open Source Fondation 2001-2006
* @framework neormf (license GPL2)
* 
*/
public class ClientDTO : DataContent{
  public static  DataInfo INFO= new DataInfo(
  // Bean Name
  "Client"
  // Bean Fields(name,title,column,type,sqlType,sqlConverter)...
  ,new DataField[]{
    new DataField("cliId", "Cli Id", "CLI_ID", null,IntType.INT_NON_NULLABLE,null),
    new DataField("cliNom", "Cli Nom", "CLI_NOM", null,new StringType(true,0,50,false),null),
    new DataField("cliAddresse", "Cli Addresse", "CLI_ADDRESSE", null,new StringType(true,0,255,false),null),
    new DataField("cliAddresse2", "Cli Addresse2", "CLI_ADDRESSE_2", null,new StringType(true,0,255,false),null),
    new DataField("clAddresse3", "Cl Addresse3", "CL_ADDRESSE_3", null,new StringType(true,0,255,false),null)
  },
  // Primary fields
  new String[]{"cliId"},
  // Title Field Name
  "cliName",
  // DataContent Class Name
  "org.vpc.neormf.testjbgen.dto.client.ClientDTO",
  // DataKey Class Name
  "org.vpc.neormf.testjbgen.dto.client.ClientKey",
  // PropertyList Class Name
  "org.vpc.neormf.testjbgen.dto.client.ClientProperties",
  // Default Order by fields
  null,null,
  // Extra Properties
  (Hashtable)Maps.fill(new Hashtable(),new Object[]{
    "BeanName",
  },new Object[]{
    "Client",
  }
  ))
  ;
  /**
  * attribute for cliId
  */
  public int CliId{
  get{
    return ((int)base.GetProperty(ClientProperties.CLI_ID));
  }
  set{
    base.SetProperty(ClientProperties.CLI_ID,value);
  }
  }

  /**
  * attribute for cliNom
  */
  public String CliNom{
  get{
    return ((String)base.GetProperty(ClientProperties.CLI_NOM));
  }
  set{
    base.SetProperty(ClientProperties.CLI_NOM,value);
  }
  }

  /**
  * attribute for cliAddresse
  */
  public String CliAddresse{
  get{
    return ((String)base.GetProperty(ClientProperties.CLI_ADDRESSE));
  }
  set{
    base.SetProperty(ClientProperties.CLI_ADDRESSE,value);
  }
  }

  /**
  * attribute for cliAddresse2
  */
  public String CliAddresse2{
  get{
    return ((String)base.GetProperty(ClientProperties.CLI_ADDRESSE_2));
  }
  set{
    base.SetProperty(ClientProperties.CLI_ADDRESSE_2,value);
  }
  }

  /**
  * attribute for clAddresse3
  */
  public String ClAddresse3{
  get{
    return ((String)base.GetProperty(ClientProperties.CL_ADDRESSE_3));
  }
  set{
    base.SetProperty(ClientProperties.CL_ADDRESSE_3,value);
  }
  }

  /**
  * Constructor
  */
  public ClientDTO(){

  }

  /**
  * true if record contains the field cliId
  */
  public bool ContainsCliId(){
    return base.ContainsProperty(ClientProperties.CLI_ID);
  }

  /**
  * remove the field cliId
  */
  public void UnsetCliId(){
    base.UnsetProperty(ClientProperties.CLI_ID);
  }

  /**
  * true if record contains the field cliNom
  */
  public bool ContainsCliNom(){
    return base.ContainsProperty(ClientProperties.CLI_NOM);
  }

  /**
  * remove the field cliNom
  */
  public void UnsetCliNom(){
    base.UnsetProperty(ClientProperties.CLI_NOM);
  }

  /**
  * true if record contains the field cliAddresse
  */
  public bool ContainsCliAddresse(){
    return base.ContainsProperty(ClientProperties.CLI_ADDRESSE);
  }

  /**
  * remove the field cliAddresse
  */
  public void UnsetCliAddresse(){
    base.UnsetProperty(ClientProperties.CLI_ADDRESSE);
  }

  /**
  * true if record contains the field cliAddresse2
  */
  public bool ContainsCliAddresse2(){
    return base.ContainsProperty(ClientProperties.CLI_ADDRESSE_2);
  }

  /**
  * remove the field cliAddresse2
  */
  public void UnsetCliAddresse2(){
    base.UnsetProperty(ClientProperties.CLI_ADDRESSE_2);
  }

  /**
  * true if record contains the field clAddresse3
  */
  public bool ContainsClAddresse3(){
    return base.ContainsProperty(ClientProperties.CL_ADDRESSE_3);
  }

  /**
  * remove the field clAddresse3
  */
  public void UnsetClAddresse3(){
    base.UnsetProperty(ClientProperties.CL_ADDRESSE_3);
  }

  public ClientKey GetClientKey(){
    Object k0=base.GetProperty(ClientProperties.CLI_ID);
    if(k0==null){
      return null;
    }
    return new ClientKey(((int)k0));
  }

  public override org.vpc.neormf.commons.beans.DataKey GetDataKey(){
    return GetClientKey();
  }

  public override DataInfo Info(){
    return INFO;
  }

}
}
