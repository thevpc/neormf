using System;
using org.vpc.neormf.commons.beans;

namespace org.vpc.neormf.testjbgen{
/**
* DO NOT EDIT MANUALLY
* GENERATED AUTOMATICALLY BY JBGen (0.1)
* @author Taha BEN SALAH (thevpc@walla.com)
* @organization Vpc Open Source Fondation 2001-2006
* @framework neormf (license GPL2)
* 
*/
public class NeormfApplication : ModuleInfo{
  public static  NeormfApplication INSTANCE=new NeormfApplication();
  /**
  * Constructor
  */
  private NeormfApplication(){

  }

  public override String[] GetDTOList(){
     return new String[]{
    "org.vpc.neormf.testjbgen.dto.lignefacture.LigneFactureDTO",
    "org.vpc.neormf.testjbgen.dto.facture.FactureDTO",
    "org.vpc.neormf.testjbgen.dto.client.ClientDTO"
     };
  }

}
}
