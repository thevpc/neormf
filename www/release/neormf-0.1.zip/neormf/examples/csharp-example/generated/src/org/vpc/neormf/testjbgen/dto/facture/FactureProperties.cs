using System;
using System.Collections;
using org.vpc.neormf.commons.beans;

namespace org.vpc.neormf.testjbgen.dto.facture{
/**
* DO NOT EDIT MANUALLY
* GENERATED AUTOMATICALLY BY JBGen (0.1)
* @author Taha BEN SALAH (thevpc@walla.com)
* @organization Vpc Open Source Fondation 2001-2006
* @framework neormf (license GPL2)
* 
*/
public class FactureProperties : org.vpc.neormf.commons.beans.PropertyList{
  public static String FAC_ID="facId";
  public static String FAC_DATE="facDate";
  public static String FAC_CLI_ID="facCliId";
  public static String FAC_VALID="facValid";
  public static String FAC_MNT="facMnt";
  public static String[] ALL_PROPERTIES={FAC_ID,FAC_DATE,FAC_CLI_ID,FAC_VALID,FAC_MNT};
  /**
  * Constructor
  */
  public FactureProperties(){

  }

  public FactureProperties AddFacId(){
    base.AddProperty(FAC_ID);
    return this;
  }

  public FactureProperties RemoveFacId(){
    base.RemoveProperty(FAC_ID);
    return this;
  }

  public bool ContainsFacId(){
    return base.ContainsProperty(FAC_ID);
  }

  public FactureProperties AddFacDate(){
    base.AddProperty(FAC_DATE);
    return this;
  }

  public FactureProperties RemoveFacDate(){
    base.RemoveProperty(FAC_DATE);
    return this;
  }

  public bool ContainsFacDate(){
    return base.ContainsProperty(FAC_DATE);
  }

  public FactureProperties AddFacCliId(){
    base.AddProperty(FAC_CLI_ID);
    return this;
  }

  public FactureProperties RemoveFacCliId(){
    base.RemoveProperty(FAC_CLI_ID);
    return this;
  }

  public bool ContainsFacCliId(){
    return base.ContainsProperty(FAC_CLI_ID);
  }

  public FactureProperties AddFacValid(){
    base.AddProperty(FAC_VALID);
    return this;
  }

  public FactureProperties RemoveFacValid(){
    base.RemoveProperty(FAC_VALID);
    return this;
  }

  public bool ContainsFacValid(){
    return base.ContainsProperty(FAC_VALID);
  }

  public FactureProperties AddFacMnt(){
    base.AddProperty(FAC_MNT);
    return this;
  }

  public FactureProperties RemoveFacMnt(){
    base.RemoveProperty(FAC_MNT);
    return this;
  }

  public bool ContainsFacMnt(){
    return base.ContainsProperty(FAC_MNT);
  }

  public override void AddAllProperties(){
    base.AddAllProperties(ALL_PROPERTIES);

  }

  public override DataInfo Info(){
    return FactureDTO.INFO;
  }

}
}
