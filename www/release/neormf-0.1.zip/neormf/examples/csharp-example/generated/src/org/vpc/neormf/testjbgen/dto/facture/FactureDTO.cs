using System;
using System.Collections;
using org.vpc.neormf.commons.beans;
using org.vpc.neormf.commons.util;
using org.vpc.neormf.commons.types;
using org.vpc.neormf.commons.types.converters;

namespace org.vpc.neormf.testjbgen.dto.facture{
/**
* DO NOT EDIT MANUALLY
* GENERATED AUTOMATICALLY BY JBGen (0.1)
* @author Taha BEN SALAH (thevpc@walla.com)
* @organization Vpc Open Source Fondation 2001-2006
* @framework neormf (license GPL2)
* 
*/
public class FactureDTO : DataContent{
  public static  DataInfo INFO= new DataInfo(
  // Bean Name
  "Facture"
  // Bean Fields(name,title,column,type,sqlType,sqlConverter)...
  ,new DataField[]{
    new DataField("facId", "Fac Id", "FAC_ID", null,IntType.INT_NON_NULLABLE,null),
    new DataField("facDate", "Fac Date", "FAC_DATE", null,DateTimeType.DATETIME_NON_NULLABLE,null),
    new DataField("facCliId", "Fac Cli Id", "FAC_CLI_ID", null,IntType.INT_NON_NULLABLE,null),
    new DataField("facValid", "Fac Valid", "FAC_VALID", BooleanType.BOOL_NON_NULLABLE,IntType.INT_NON_NULLABLE,org.vpc.neormf.commons.types.converters.IntegerToBoolean.INTEGER_TO_BOOLEAN),
    new DataField("facMnt", "Fac Mnt", "facMnt", null,DoubleType.DOUBLE_NON_NULLABLE,null)
  },
  // Primary fields
  new String[]{"facId"},
  // Title Field Name
  "facId",
  // DataContent Class Name
  "org.vpc.neormf.testjbgen.dto.facture.FactureDTO",
  // DataKey Class Name
  "org.vpc.neormf.testjbgen.dto.facture.FactureKey",
  // PropertyList Class Name
  "org.vpc.neormf.testjbgen.dto.facture.FactureProperties",
  // Default Order by fields
  null,null,
  // Extra Properties
  (Hashtable)Maps.fill(new Hashtable(),new Object[]{
    "BeanName",
  },new Object[]{
    "Facture",
  }
  ))
  ;
  /**
  * attribute for facId
  */
  public int FacId{
  get{
    return ((int)base.GetProperty(FactureProperties.FAC_ID));
  }
  set{
    base.SetProperty(FactureProperties.FAC_ID,value);
  }
  }

  /**
  * attribute for facDate
  */
  public DateTime FacDate{
  get{
    return ((DateTime)base.GetProperty(FactureProperties.FAC_DATE));
  }
  set{
    base.SetProperty(FactureProperties.FAC_DATE,value);
  }
  }

  /**
  * attribute for facCliId
  */
  public int FacCliId{
  get{
    return ((int)base.GetProperty(FactureProperties.FAC_CLI_ID));
  }
  set{
    base.SetProperty(FactureProperties.FAC_CLI_ID,value);
  }
  }

  /**
  * attribute for facValid
  */
  public bool FacValid{
  get{
    return ((bool)base.GetProperty(FactureProperties.FAC_VALID));
  }
  set{
    base.SetProperty(FactureProperties.FAC_VALID,value);
  }
  }

  /**
  * attribute for facMnt
  */
  public double FacMnt{
  get{
    return ((double)base.GetProperty(FactureProperties.FAC_MNT));
  }
  set{
    base.SetProperty(FactureProperties.FAC_MNT,value);
  }
  }

  /**
  * Constructor
  */
  public FactureDTO(){

  }

  /**
  * true if record contains the field facId
  */
  public bool ContainsFacId(){
    return base.ContainsProperty(FactureProperties.FAC_ID);
  }

  /**
  * remove the field facId
  */
  public void UnsetFacId(){
    base.UnsetProperty(FactureProperties.FAC_ID);
  }

  /**
  * true if record contains the field facDate
  */
  public bool ContainsFacDate(){
    return base.ContainsProperty(FactureProperties.FAC_DATE);
  }

  /**
  * remove the field facDate
  */
  public void UnsetFacDate(){
    base.UnsetProperty(FactureProperties.FAC_DATE);
  }

  /**
  * true if record contains the field facCliId
  */
  public bool ContainsFacCliId(){
    return base.ContainsProperty(FactureProperties.FAC_CLI_ID);
  }

  /**
  * remove the field facCliId
  */
  public void UnsetFacCliId(){
    base.UnsetProperty(FactureProperties.FAC_CLI_ID);
  }

  /**
  * true if record contains the field facValid
  */
  public bool ContainsFacValid(){
    return base.ContainsProperty(FactureProperties.FAC_VALID);
  }

  /**
  * remove the field facValid
  */
  public void UnsetFacValid(){
    base.UnsetProperty(FactureProperties.FAC_VALID);
  }

  /**
  * true if record contains the field facMnt
  */
  public bool ContainsFacMnt(){
    return base.ContainsProperty(FactureProperties.FAC_MNT);
  }

  /**
  * remove the field facMnt
  */
  public void UnsetFacMnt(){
    base.UnsetProperty(FactureProperties.FAC_MNT);
  }

  public FactureKey GetFactureKey(){
    Object k0=base.GetProperty(FactureProperties.FAC_ID);
    if(k0==null){
      return null;
    }
    return new FactureKey(((int)k0));
  }

  public override org.vpc.neormf.commons.beans.DataKey GetDataKey(){
    return GetFactureKey();
  }

  public override DataInfo Info(){
    return INFO;
  }

}
}
