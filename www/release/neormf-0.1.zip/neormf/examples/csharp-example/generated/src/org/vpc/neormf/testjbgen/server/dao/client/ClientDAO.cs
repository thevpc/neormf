using System;
using System.Collections;
using System.Data;
using System.Text;
using System.Data.SqlClient;
using org.vpc.neormf.commons.jwrapper;
using org.vpc.neormf.commons.beans;
using org.vpc.neormf.commons.exceptions;
using org.vpc.neormf.commons.types.converters;
using org.vpc.neormf.commons.sql;
using org.vpc.neormf.testjbgen.dto.client;

namespace org.vpc.neormf.testjbgen.server.dao.client{
/**
* DO NOT EDIT MANUALLY
* GENERATED AUTOMATICALLY BY JBGen (0.1)
* @author Taha BEN SALAH (thevpc@walla.com)
* @organization Vpc Open Source Fondation 2001-2006
* @framework neormf (license GPL2)
* 
*/
public class ClientDAO : DBConnector{
  /**
  * DBConnector Constructor
  */
  public ClientDAO(){

  }

  /**
  * DBConnector Constructor
  */
  public ClientDAO(DBConnector other) : base(other){

  }

  /**
  * DBConnector Constructor
  */
  public ClientDAO(SqlConnection cnx) : base(){
    SetConnection(cnx);
  }

  /**
  * DBConnector Constructor
  */
  public ClientDAO(SqlConnection cnx, String caller) : base(){
    SetConnection(cnx);
    SetCallerPrincipalName(caller);
  }

  /**
  * DBConnector Constructor
  * @class:generator JBGen
  */
  public ClientKey Insert(ClientDTO data){
    // START Prologue initialization
     int cliId=0;
     bool cliId_isNull_=false;
     String cliNom=null;
     String cliAddresse=null;
     String cliAddresse2=null;
     String clAddresse3=null;
    // END   Prologue initialization
    // START Prologue checking
    if(data.ContainsCliId()){
      throw new ForbiddenFieldOnInsertException(ClientDTO.INFO.GetField(ClientProperties.CLI_ID));
    }
    // END  Prologue checking

    SqlConnection  _conn_=null;
    String _insertStatement_ = null;
    PreparedStatement _prepStmt_  = null;
    try{
      _conn_=GetConnection();

      // START data.preInsert.userCode
      // code retreived from data.preInsert.userCode
      // END   data.preInsert.userCode
      // START Local Fields Updates
    for(IEnumerator i=data.KeySet().GetEnumerator();i.MoveNext();){
      String selectedFieldName=(String)i.Current;
      switch(selectedFieldName){
        case "CLI_ADDRESSE_2":
        case "cliAddresse2":{  //field cliAddresse2
            // START field.cliAddresse2.preInsert.userCode
            // code retreived from field.cliAddresse2.preInsert.userCode
            // END   field.cliAddresse2.preInsert.userCode
          cliAddresse2=(data.CliAddresse2);
            // START field.cliAddresse2.postInsert.userCode
            // code retreived from field.cliAddresse2.postInsert.userCode
            // END   field.cliAddresse2.postInsert.userCode
          break;    }
        case "CLI_NOM":
        case "cliNom":{  //field cliNom
            // START field.cliNom.preInsert.userCode
            // code retreived from field.cliNom.preInsert.userCode
            // END   field.cliNom.preInsert.userCode
          cliNom=(data.CliNom);
            // START field.cliNom.postInsert.userCode
            // code retreived from field.cliNom.postInsert.userCode
            // END   field.cliNom.postInsert.userCode
          break;    }
        case "CLI_ADDRESSE":
        case "cliAddresse":{  //field cliAddresse
            // START field.cliAddresse.preInsert.userCode
            // code retreived from field.cliAddresse.preInsert.userCode
            // END   field.cliAddresse.preInsert.userCode
          cliAddresse=(data.CliAddresse);
            // START field.cliAddresse.postInsert.userCode
            // code retreived from field.cliAddresse.postInsert.userCode
            // END   field.cliAddresse.postInsert.userCode
          break;    }
        case "CLI_ID":
        case "cliId":{  //field cliId
            // START field.cliId.preInsert.userCode
            // code retreived from field.cliId.preInsert.userCode
            // END   field.cliId.preInsert.userCode
          if(data.GetProperty(ClientProperties.CLI_ID)==null){
            cliId_isNull_=true;
          }else{
            cliId=(data.CliId);
          }
            // START field.cliId.postInsert.userCode
            // code retreived from field.cliId.postInsert.userCode
            // END   field.cliId.postInsert.userCode
          break;    }
        case "CL_ADDRESSE_3":
        case "clAddresse3":{  //field clAddresse3
            // START field.clAddresse3.preInsert.userCode
            // code retreived from field.clAddresse3.preInsert.userCode
            // END   field.clAddresse3.preInsert.userCode
          clAddresse3=(data.ClAddresse3);
            // START field.clAddresse3.postInsert.userCode
            // code retreived from field.clAddresse3.postInsert.userCode
            // END   field.clAddresse3.postInsert.userCode
          break;    }
        default :{
          throw new UnknownFieldException(selectedFieldName);
        }
      }
    }
      // END   Local Fields Updates

      // START Database persistance
      _insertStatement_ = "INSERT INTO CLIENT(CLI_NOM, CLI_ADDRESSE) VALUES (?, ?)";
      _prepStmt_ = new PreparedStatement(_conn_,_insertStatement_);
      _prepStmt_.SetString(1,cliNom);
      _prepStmt_.SetString(2,cliAddresse);
      _prepStmt_.ExecuteUpdate();
      _prepStmt_.Close();
      _insertStatement_ = "INSERT INTO CLIENT_INFO(CLI_ADDRESSE_2, CL_ADDRESSE_3) VALUES (?, ?)";
      _prepStmt_ = new PreparedStatement(_conn_,_insertStatement_);
      _prepStmt_.SetString(1,cliAddresse2);
      _prepStmt_.SetString(2,clAddresse3);
      _prepStmt_.ExecuteUpdate();
      _prepStmt_.Close();


      // START Sequence Handling
      String _selectNewIdStatement_ = "SELECT @@IDENTITY";
      _prepStmt_ = new PreparedStatement(_conn_,_selectNewIdStatement_);
      ResultSet _rs_=_prepStmt_.ExecuteQuery();
      if(_rs_.MoveNext()){
        data.CliId=(_rs_.GetInt(1));
        _rs_.Close();
        _prepStmt_.Close();
      }
      _rs_.Close();
      _prepStmt_.Close();
      // END Sequence Handling
      // START data.postInsert.userCode
      // code retreived from data.postInsert.userCode
      // END   data.postInsert.userCode
      // END   Database persistance

      // returning Identifier;
      return data.GetClientKey();
    }catch(SqlException sqlExcp){
      throw new CreateDataException(sqlExcp);
    }
  }

  /**
  * @class:generator JBGen
  */
  public void Update(ClientDTO data){
    if(data.Size()==0){
      return;
    }
    // START Prologue Checking
    // END   ForbiddenFieldOnUpdate Cheking

      // START data.preUpdate.userCode
      // code retreived from data.preUpdate.userCode
      // END   data.preUpdate.userCode
    SqlConnection  _conn_=null;
    try{
      _conn_=GetConnection();
      StringBuilder _updateStatement_ = new StringBuilder();
      int _ucount_ = 0;
      PreparedStatement _prepStmt_ = null;
      bool _firstColumn_=true;
      _updateStatement_.Append( "UPDATE CLIENT SET ");
      if(data.ContainsCliNom()){
        if(_firstColumn_){
          _firstColumn_=false;
        }else{
          _updateStatement_.Append(", ");
        }
        _updateStatement_.Append("CLI_NOM=? ");
      }
      if(data.ContainsCliAddresse()){
        if(_firstColumn_){
          _firstColumn_=false;
        }else{
          _updateStatement_.Append(", ");
        }
        _updateStatement_.Append("CLI_ADDRESSE=? ");
      }
    _updateStatement_.Append(" WHERE CLI_ID = ? ");
      _prepStmt_ = new PreparedStatement(_conn_,_updateStatement_.ToString());
      int _pos_=1;
      if(data.ContainsCliNom()){
        _prepStmt_.SetString(_pos_++,data.CliNom);
      }
      if(data.ContainsCliAddresse()){
        _prepStmt_.SetString(_pos_++,data.CliAddresse);
      }
      _prepStmt_.SetInt(_pos_++,data.CliId);
      _ucount_=_prepStmt_.ExecuteUpdate();
      _prepStmt_.Close();
      if(_ucount_<=0){
        throw new UpdateDataException();
      }
      bool _firstColumn_=true;
      _updateStatement_.Append( "UPDATE CLIENT_INFO SET ");
      if(data.ContainsCliAddresse2()){
        if(_firstColumn_){
          _firstColumn_=false;
        }else{
          _updateStatement_.Append(", ");
        }
        _updateStatement_.Append("CLI_ADDRESSE_2=? ");
      }
      if(data.ContainsClAddresse3()){
        if(_firstColumn_){
          _firstColumn_=false;
        }else{
          _updateStatement_.Append(", ");
        }
        _updateStatement_.Append("CL_ADDRESSE_3=? ");
      }
    _updateStatement_.Append(" WHERE CLI_ID = ? ");
      _prepStmt_ = new PreparedStatement(_conn_,_updateStatement_.ToString());
      int _pos_=1;
      if(data.ContainsCliAddresse2()){
        _prepStmt_.SetString(_pos_++,data.CliAddresse2);
      }
      if(data.ContainsClAddresse3()){
        _prepStmt_.SetString(_pos_++,data.ClAddresse3);
      }
      _prepStmt_.SetInt(_pos_++,data.CliId);
      _ucount_=_prepStmt_.ExecuteUpdate();
      _prepStmt_.Close();
      if(_ucount_<=0){
        throw new UpdateDataException();
      }
      // START data.postUpdate.userCode
      // code retreived from data.postUpdate.userCode
      // END   data.postUpdate.userCode
    }catch(SqlException sqlExcp){
      throw new UpdateDataException(sqlExcp);
    }
  }

  /**
  * @class:generator JBGen
  */
  public void Delete(ClientKey key){
    SqlConnection  _conn_=null;
    try{
      _conn_=GetConnection();
      // START data.preDelete.userCode
      // code retreived from data.preDelete.userCode
      // END   data.preDelete.userCode
      int _ucount_=0;
      String _removeStatement_ = null;
      PreparedStatement _prepStmt_ = null;
      _removeStatement_ = "DELETE FROM CLIENT WHERE CLI_ID = ? ";
      _prepStmt_ = new PreparedStatement(_conn_,_removeStatement_);
      _prepStmt_.SetInt(1,(key.GetCliId()));
      _ucount_=_prepStmt_.ExecuteUpdate();
      _prepStmt_.Close();
      if(_ucount_<=0){
        throw new RemoveDataException();
      }
      _removeStatement_ = "DELETE FROM CLIENT_INFO WHERE CLI_ID = ? ";
      _prepStmt_ = new PreparedStatement(_conn_,_removeStatement_);
      _prepStmt_.SetInt(1,(key.GetCliId()));
      _ucount_=_prepStmt_.ExecuteUpdate();
      _prepStmt_.Close();
      if(_ucount_<=0){
        throw new RemoveDataException();
      }
      // START data.postDelete.userCode
      // code retreived from data.postDelete.userCode
      // END   data.postDelete.userCode
    }catch(SqlException sqlExcp){
      throw new RemoveDataException(sqlExcp);
    }
  }

  /**
  * @class:generator JBGen
  */
  public ClientDTO GetData(ClientProperties propertyList, ClientKey primaryKey){
    String where="CLIENT.CLI_ID = ?";
    Criteria criteria=new Criteria(where);
    criteria.SetInt(1,primaryKey.GetCliId());
    ICollection collection=Select(propertyList,criteria,null);
    if(collection.Count>0){
      for(IEnumerator i=collection.GetEnumerator();i.MoveNext();){
        return (ClientDTO) i.Current;
      }
    }
     throw new DataNotFoundException();

  }

  /**
  * @class:generator JBGen
  */
  public bool Exists(ClientKey primaryKey){
     ClientProperties propertyList=new ClientProperties();
    propertyList.AddCliId();
    String where="CLIENT.CLI_ID = ?";
    Criteria criteria=new Criteria(where);
    criteria.SetInt(1,primaryKey.GetCliId());
    ICollection collection=Select(propertyList,criteria,null);
    if(collection.Count>0){
      for(IEnumerator i=collection.GetEnumerator();i.MoveNext();){
        return true;
      }
    }
     return false;

  }

  /**
  * @class:generator JBGen
  */
  public ICollection Select(ClientProperties propertyList, Criteria criteria, OrderList order){
    SqlConnection  _conn_=null;
    try{
      _conn_=GetConnection();
      StringBuilder _selectStatement_ = new StringBuilder("SELECT ");
      if(criteria!=null && criteria.IsDistinct()){
        _selectStatement_.Append("DISTINCT ");
      }
      ArrayList _sqlStatementParamsProviderArrayList_=new ArrayList();
      if(propertyList==null){
        _selectStatement_.Append("(CLIENT.CLI_ID),(CLIENT.CLI_ID),(CLIENT.CLI_NOM),(CLIENT.CLI_ADDRESSE),(CLIENT_INFO.CLI_ADDRESSE_2),(CLIENT_INFO.CL_ADDRESSE_3)");
      }else{
        StringBuilder sb=new StringBuilder("CLI_ID");
        for(IEnumerator i=propertyList.GetEnumerator();i.MoveNext();){
          String selectedFieldName=(String)i.Current;
          switch(selectedFieldName){
            case "CLI_ADDRESSE_2":
            case "cliAddresse2":{  //field cliAddresse2
              if (sb.Length > 0) {
                sb.Append(" , ");
              }
              sb.Append("CLIENT_INFO.CLI_ADDRESSE_2");

              break;
            }
            case "CLI_NOM":
            case "cliNom":{  //field cliNom
              if (sb.Length > 0) {
                sb.Append(" , ");
              }
              sb.Append("CLIENT.CLI_NOM");

              break;
            }
            case "CLI_ADDRESSE":
            case "cliAddresse":{  //field cliAddresse
              if (sb.Length > 0) {
                sb.Append(" , ");
              }
              sb.Append("CLIENT.CLI_ADDRESSE");

              break;
            }
            case "CLI_ID":
            case "cliId":{  //field cliId
              if (sb.Length > 0) {
                sb.Append(" , ");
              }
              sb.Append("CLIENT.CLI_ID");

              break;
            }
            case "CL_ADDRESSE_3":
            case "clAddresse3":{  //field clAddresse3
              if (sb.Length > 0) {
                sb.Append(" , ");
              }
              sb.Append("CLIENT_INFO.CL_ADDRESSE_3");

              break;
            }
            default :{
              // default
              break;
            }
          }
        }
        _selectStatement_.Append(sb.ToString());
      }
      _selectStatement_.Append(" FROM CLIENT,CLIENT_INFO");
      if(criteria!=null && criteria.GetJoins()!=null){
        _selectStatement_.Append(" ");
        _selectStatement_.Append(criteria.GetJoins());
      }
        _selectStatement_.Append(" WHERE CLIENT_INFO.CLI_ID=CLIENT.CLI_ID");
      if(criteria!=null && criteria.GetWhereClause()!=null){
        _selectStatement_.Append(" AND ");
        _selectStatement_.Append(criteria.GetWhereClause());
      }
        if(order!=null){
          _selectStatement_.Append(" ORDER BY ");
          bool orderFirst=true;
        for(IEnumerator i=order.GetEnumerator();i.MoveNext();){
          OrderList.OrderItem item=(OrderList.OrderItem) i.Current;String selectedFieldName=item.GetFieldName();
          switch(selectedFieldName){
            case "CLI_ADDRESSE_2":
            case "cliAddresse2":{  //field cliAddresse2
              if(orderFirst){
                orderFirst=false;
              }else{
                _selectStatement_.Append(" , ");
              }
              _selectStatement_.Append("CLIENT_INFO.CLI_ADDRESSE_2");
              _selectStatement_.Append(" ").Append(item.IsAscendent()?"ASC":"DESC");
              break;    }
            case "CLI_NOM":
            case "cliNom":{  //field cliNom
              if(orderFirst){
                orderFirst=false;
              }else{
                _selectStatement_.Append(" , ");
              }
              _selectStatement_.Append("CLIENT.CLI_NOM");
              _selectStatement_.Append(" ").Append(item.IsAscendent()?"ASC":"DESC");
              break;    }
            case "CLI_ADDRESSE":
            case "cliAddresse":{  //field cliAddresse
              if(orderFirst){
                orderFirst=false;
              }else{
                _selectStatement_.Append(" , ");
              }
              _selectStatement_.Append("CLIENT.CLI_ADDRESSE");
              _selectStatement_.Append(" ").Append(item.IsAscendent()?"ASC":"DESC");
              break;    }
            case "CLI_ID":
            case "cliId":{  //field cliId
              if(orderFirst){
                orderFirst=false;
              }else{
                _selectStatement_.Append(" , ");
              }
              _selectStatement_.Append("CLIENT.CLI_ID");
              _selectStatement_.Append(" ").Append(item.IsAscendent()?"ASC":"DESC");
              break;    }
            case "CL_ADDRESSE_3":
            case "clAddresse3":{  //field clAddresse3
              if(orderFirst){
                orderFirst=false;
              }else{
                _selectStatement_.Append(" , ");
              }
              _selectStatement_.Append("CLIENT_INFO.CL_ADDRESSE_3");
              _selectStatement_.Append(" ").Append(item.IsAscendent()?"ASC":"DESC");
              break;    }
            default :{
              //WHEN UNKNOWN FIELD PASSED AS IS TO SQL
              if(orderFirst){
                orderFirst=false;
              }else{
                _selectStatement_.Append(" , ");
              }
              _selectStatement_.Append(selectedFieldName);
              _selectStatement_.Append(" ").Append(item.IsAscendent()?"ASC":"DESC");
              break;
            }
          }
        }
        }
        ArrayList list=new ArrayList();
        PreparedStatement _prepStmt_ = new PreparedStatement(_conn_,_selectStatement_.ToString());
        int _min_=-1;
        int _max_=-1;
        int _statementParamPos_=1;
        for(IEnumerator _i_=_sqlStatementParamsProviderArrayList_.GetEnumerator();_i_.MoveNext();){
          SqlStatementParamsProvider _p_=(SqlStatementParamsProvider) _i_.Current; 
          _statementParamPos_+=_p_.PopulateStatement(_prepStmt_,_statementParamPos_); 
        }
        if(criteria!=null){
          criteria.PopulateStatement(_prepStmt_,_statementParamPos_);
          _min_=criteria.GetMinRowIndex();
          _max_=criteria.GetMaxRowIndex();
        }
        ResultSet _rs_=_prepStmt_.ExecuteQuery();
        int _count_=0;
        while(_count_<_min_ && _rs_.MoveNext()){
          _count_++;
        }
      if(propertyList==null){
        while((_max_<0 || _count_<=_max_) && _rs_.MoveNext()){
          _count_++;
          ClientKey _tableKey_ = new ClientKey(_rs_.GetInt(1));
          ClientDTO data=new ClientDTO();
          data.CliId=(_rs_.GetInt(2));
          if(_rs_.WasNull()){
            data.SetProperty(ClientProperties.CLI_ID,null);
          }
          data.CliNom=(_rs_.GetString(3));
          data.CliAddresse=(_rs_.GetString(4));
          data.CliAddresse2=(_rs_.GetString(5));
          data.ClAddresse3=(_rs_.GetString(6));
          list.Add(data);
        }
      }else{
        while((_max_<0 || _count_<=_max_) && _rs_.MoveNext()){
          _count_++;
          int _col_=2;
          ClientKey _tableKey_ = new ClientKey(_rs_.GetInt(1));
          ClientDTO data=new ClientDTO();
        for(IEnumerator i=propertyList.KeySet().GetEnumerator();i.MoveNext();){
          String selectedFieldName=(String)i.Current;
          switch(selectedFieldName){
            case "CLI_ADDRESSE_2":
            case "cliAddresse2":{  //field cliAddresse2
              data.CliAddresse2=(_rs_.GetString(_col_++));

              break;
            }
            case "CLI_NOM":
            case "cliNom":{  //field cliNom
              data.CliNom=(_rs_.GetString(_col_++));

              break;
            }
            case "CLI_ADDRESSE":
            case "cliAddresse":{  //field cliAddresse
              data.CliAddresse=(_rs_.GetString(_col_++));

              break;
            }
            case "CLI_ID":
            case "cliId":{  //field cliId
              data.CliId=(_rs_.GetInt(_col_++));
              if(_rs_.WasNull()){
                data.SetProperty(ClientProperties.CLI_ID,null);
              }

              break;
            }
            case "CL_ADDRESSE_3":
            case "clAddresse3":{  //field clAddresse3
              data.ClAddresse3=(_rs_.GetString(_col_++));

              break;
            }
            default :{
              // default
              break;
            }
          }
        }
          list.Add(data);
        }
      }
      _rs_.Close();
      _prepStmt_.Close();
      return list;
    }catch(SqlException sqlExcp){
      throw new DataRetrievalException(sqlExcp);
    }
  }

  /**
  * @class:generator JBGen
  */
  public ICollection Select(ClientProperties propertyList, ClientDTO prototype, OrderList order){
    return Select(propertyList,_buildCriteriaQBE_(prototype),order);

  }

  private static Criteria _buildCriteriaQBE_(ClientDTO prototype){
      Criteria criteria=null;
      // building criteria
    if (prototype != null && prototype.Size() > 0) {
      StringBuilder whereClause = new StringBuilder();
      criteria = new Criteria();
      int pos=1;
      for(IEnumerator i=prototype.KeySet().GetEnumerator();i.MoveNext();){
        String selectedFieldName=(String)i.Current;
        switch(selectedFieldName){
          case "CLI_ADDRESSE_2":
          case "cliAddresse2":{  //field cliAddresse2
            if (whereClause.Length > 1) {
              whereClause.Append(" AND ");
            }
            String columnValue = prototype.CliAddresse2;
            whereClause.Append("CLIENT_INFO.CLI_ADDRESSE_2 = ?");
            criteria.SetString(pos++,columnValue);
            break;
          }
          case "CLI_NOM":
          case "cliNom":{  //field cliNom
            if (whereClause.Length > 1) {
              whereClause.Append(" AND ");
            }
            String columnValue = prototype.CliNom;
            whereClause.Append("CLIENT.CLI_NOM = ?");
            criteria.SetString(pos++,columnValue);
            break;
          }
          case "CLI_ADDRESSE":
          case "cliAddresse":{  //field cliAddresse
            if (whereClause.Length > 1) {
              whereClause.Append(" AND ");
            }
            String columnValue = prototype.CliAddresse;
            whereClause.Append("CLIENT.CLI_ADDRESSE = ?");
            criteria.SetString(pos++,columnValue);
            break;
          }
          case "CLI_ID":
          case "cliId":{  //field cliId
            if (whereClause.Length > 1) {
              whereClause.Append(" AND ");
            }
            int columnValue = prototype.CliId;
            whereClause.Append("CLIENT.CLI_ID = ?");
            criteria.SetInt(pos++,columnValue);
            break;
          }
          case "CL_ADDRESSE_3":
          case "clAddresse3":{  //field clAddresse3
            if (whereClause.Length > 1) {
              whereClause.Append(" AND ");
            }
            String columnValue = prototype.ClAddresse3;
            whereClause.Append("CLIENT_INFO.CL_ADDRESSE_3 = ?");
            criteria.SetString(pos++,columnValue);
            break;
          }
          default :{
            throw new UnknownFieldException(selectedFieldName);

          }
        }
      }
    	criteria.SetWhereClause(whereClause.ToString());
    }
      // START method.findAll.userCode
      // code retreived from method.findAll.userCode
      // END   method.findAll.userCode

      return criteria;

  }

}
}
