using System;
using org.vpc.neormf.commons.beans;

namespace org.vpc.neormf.testjbgen.dto.lignefacture{
/**
* DO NOT EDIT MANUALLY
* GENERATED AUTOMATICALLY BY JBGen (0.1)
* @author Taha BEN SALAH (thevpc@walla.com)
* @organization Vpc Open Source Fondation 2001-2006
* @framework neormf (license GPL2)
* 
*/
public class LigneFactureKey : org.vpc.neormf.commons.beans.DataKey{
  public int lnfArtId;
  public int lnfFacId;
  /**
  * Constructor
  */
  public LigneFactureKey(){

  }

  /**
  * Constructor
  */
  public LigneFactureKey(int lnfArtId, int lnfFacId){
    this.lnfArtId=lnfArtId;
    this.lnfFacId=lnfFacId;

  }

  public int GetLnfArtId(){
    return lnfArtId;
  }

  public int GetLnfFacId(){
    return lnfFacId;
  }

  public override Object KeyPartAt(int index){
    switch(index){
      case 0:{
        return lnfArtId;
      }
      case 1:{
        return lnfFacId;
      }
      default:{
        throw new Exception("ArrayIndexOutOfBoundsException "+index);
      }
    }
  }

  public override int KeySize(){
    return 2;
  }

  public override DataInfo Info(){
    return LigneFactureDTO.INFO;
  }

}
}
