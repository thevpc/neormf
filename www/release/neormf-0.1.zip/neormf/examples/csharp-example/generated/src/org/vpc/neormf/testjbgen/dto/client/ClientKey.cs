using System;
using org.vpc.neormf.commons.beans;

namespace org.vpc.neormf.testjbgen.dto.client{
/**
* DO NOT EDIT MANUALLY
* GENERATED AUTOMATICALLY BY JBGen (0.1)
* @author Taha BEN SALAH (thevpc@walla.com)
* @organization Vpc Open Source Fondation 2001-2006
* @framework neormf (license GPL2)
* 
*/
public class ClientKey : org.vpc.neormf.commons.beans.DataKey{
  public int cliId;
  /**
  * Constructor
  */
  public ClientKey(){

  }

  /**
  * Constructor
  */
  public ClientKey(int cliId){
    this.cliId=cliId;

  }

  public int GetCliId(){
    return cliId;
  }

  public override Object KeyPartAt(int index){
    return cliId;

  }

  public override int KeySize(){
    return 1;
  }

  public override DataInfo Info(){
    return ClientDTO.INFO;
  }

}
}
