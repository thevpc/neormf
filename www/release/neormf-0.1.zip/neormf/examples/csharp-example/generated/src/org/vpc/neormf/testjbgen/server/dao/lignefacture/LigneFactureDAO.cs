using System;
using System.Collections;
using System.Data;
using System.Text;
using System.Data.SqlClient;
using org.vpc.neormf.commons.jwrapper;
using org.vpc.neormf.commons.beans;
using org.vpc.neormf.commons.exceptions;
using org.vpc.neormf.commons.types.converters;
using org.vpc.neormf.commons.sql;
using org.vpc.neormf.testjbgen.dto.lignefacture;

namespace org.vpc.neormf.testjbgen.server.dao.lignefacture{
/**
* DO NOT EDIT MANUALLY
* GENERATED AUTOMATICALLY BY JBGen (0.1)
* @author Taha BEN SALAH (thevpc@walla.com)
* @organization Vpc Open Source Fondation 2001-2006
* @framework neormf (license GPL2)
* 
*/
public class LigneFactureDAO : DBConnector{
  /**
  * DBConnector Constructor
  */
  public LigneFactureDAO(){

  }

  /**
  * DBConnector Constructor
  */
  public LigneFactureDAO(DBConnector other) : base(other){

  }

  /**
  * DBConnector Constructor
  */
  public LigneFactureDAO(SqlConnection cnx) : base(){
    SetConnection(cnx);
  }

  /**
  * DBConnector Constructor
  */
  public LigneFactureDAO(SqlConnection cnx, String caller) : base(){
    SetConnection(cnx);
    SetCallerPrincipalName(caller);
  }

  /**
  * DBConnector Constructor
  * @class:generator JBGen
  */
  public LigneFactureKey Insert(LigneFactureDTO data){
    // START Prologue initialization
     int lnfArtId=0;
     bool lnfArtId_isNull_=false;
     int lnfFacId=0;
     bool lnfFacId_isNull_=false;
     int lnfQte=0;
     bool lnfQte_isNull_=false;
     double lnfPrix=0D;
     bool lnfPrix_isNull_=false;
    // END   Prologue initialization
    // START Prologue checking
    if(data.ContainsLnfArtId()){
      throw new ForbiddenFieldOnInsertException(LigneFactureDTO.INFO.GetField(LigneFactureProperties.LNF_ART_ID));
    }
    if(data.ContainsLnfFacId()){
      throw new ForbiddenFieldOnInsertException(LigneFactureDTO.INFO.GetField(LigneFactureProperties.LNF_FAC_ID));
    }
    // END  Prologue checking

    SqlConnection  _conn_=null;
    String _insertStatement_ = null;
    PreparedStatement _prepStmt_  = null;
    try{
      _conn_=GetConnection();
      lnfArtId=(data.LnfArtId);
      lnfFacId=(data.LnfFacId);

      // START data.preInsert.userCode
      // code retreived from data.preInsert.userCode
      // END   data.preInsert.userCode
      // START Local Fields Updates
    for(IEnumerator i=data.KeySet().GetEnumerator();i.MoveNext();){
      String selectedFieldName=(String)i.Current;
      switch(selectedFieldName){
        case "LNF_FAC_ID":
        case "lnfFacId":{  //field lnfFacId
            // START field.lnfFacId.preInsert.userCode
            // code retreived from field.lnfFacId.preInsert.userCode
            // END   field.lnfFacId.preInsert.userCode
          if(data.GetProperty(LigneFactureProperties.LNF_FAC_ID)==null){
            lnfFacId_isNull_=true;
          }else{
            lnfFacId=(data.LnfFacId);
          }
            // START field.lnfFacId.postInsert.userCode
            // code retreived from field.lnfFacId.postInsert.userCode
            // END   field.lnfFacId.postInsert.userCode
          break;    }
        case "LNF_PRIX":
        case "lnfPrix":{  //field lnfPrix
            // START field.lnfPrix.preInsert.userCode
            // code retreived from field.lnfPrix.preInsert.userCode
            // END   field.lnfPrix.preInsert.userCode
          if(data.GetProperty(LigneFactureProperties.LNF_PRIX)==null){
            lnfPrix_isNull_=true;
          }else{
            lnfPrix=(data.LnfPrix);
          }
            // START field.lnfPrix.postInsert.userCode
            // code retreived from field.lnfPrix.postInsert.userCode
            // END   field.lnfPrix.postInsert.userCode
          break;    }
        case "LNF_ART_ID":
        case "lnfArtId":{  //field lnfArtId
            // START field.lnfArtId.preInsert.userCode
            // code retreived from field.lnfArtId.preInsert.userCode
            // END   field.lnfArtId.preInsert.userCode
          if(data.GetProperty(LigneFactureProperties.LNF_ART_ID)==null){
            lnfArtId_isNull_=true;
          }else{
            lnfArtId=(data.LnfArtId);
          }
            // START field.lnfArtId.postInsert.userCode
            // code retreived from field.lnfArtId.postInsert.userCode
            // END   field.lnfArtId.postInsert.userCode
          break;    }
        case "LNF_QTE":
        case "lnfQte":{  //field lnfQte
            // START field.lnfQte.preInsert.userCode
            // code retreived from field.lnfQte.preInsert.userCode
            // END   field.lnfQte.preInsert.userCode
          if(data.GetProperty(LigneFactureProperties.LNF_QTE)==null){
            lnfQte_isNull_=true;
          }else{
            lnfQte=(data.LnfQte);
          }
            // START field.lnfQte.postInsert.userCode
            // code retreived from field.lnfQte.postInsert.userCode
            // END   field.lnfQte.postInsert.userCode
          break;    }
        default :{
          throw new UnknownFieldException(selectedFieldName);
        }
      }
    }
      // END   Local Fields Updates

      // START Database persistance
      _insertStatement_ = "INSERT INTO LIGNE_FACTURE(LNF_QTE, LNF_PRIX) VALUES (?, ?)";
      _prepStmt_ = new PreparedStatement(_conn_,_insertStatement_);
    if(lnfQte_isNull_){
      _prepStmt_.SetNull(1,SqlDbType.Int);
    }else{
      _prepStmt_.SetInt(1,lnfQte);
    }
    if(lnfPrix_isNull_){
      _prepStmt_.SetNull(2,SqlDbType.Float);
    }else{
      _prepStmt_.SetDouble(2,lnfPrix);
    }
      _prepStmt_.ExecuteUpdate();
      _prepStmt_.Close();

      // START data.postInsert.userCode
      // code retreived from data.postInsert.userCode
      // END   data.postInsert.userCode
      // END   Database persistance

      // returning Identifier;
      return data.GetLigneFactureKey();
    }catch(SqlException sqlExcp){
      throw new CreateDataException(sqlExcp);
    }
  }

  /**
  * @class:generator JBGen
  */
  public void Update(LigneFactureDTO data){
    if(data.Size()==0){
      return;
    }
    // START Prologue Checking
    // END   ForbiddenFieldOnUpdate Cheking

      // START data.preUpdate.userCode
      // code retreived from data.preUpdate.userCode
      // END   data.preUpdate.userCode
    SqlConnection  _conn_=null;
    try{
      _conn_=GetConnection();
      StringBuilder _updateStatement_ = new StringBuilder();
      int _ucount_ = 0;
      PreparedStatement _prepStmt_ = null;
      bool _firstColumn_=true;
      _updateStatement_.Append( "UPDATE LIGNE_FACTURE SET ");
      if(data.ContainsLnfQte()){
        if(_firstColumn_){
          _firstColumn_=false;
        }else{
          _updateStatement_.Append(", ");
        }
        _updateStatement_.Append("LNF_QTE=? ");
      }
      if(data.ContainsLnfPrix()){
        if(_firstColumn_){
          _firstColumn_=false;
        }else{
          _updateStatement_.Append(", ");
        }
        _updateStatement_.Append("LNF_PRIX=? ");
      }
    _updateStatement_.Append(" WHERE LNF_ART_ID = ?  AND LNF_FAC_ID = ? ");
      _prepStmt_ = new PreparedStatement(_conn_,_updateStatement_.ToString());
      int _pos_=1;
      if(data.ContainsLnfQte()){
    if(data.GetProperty(LigneFactureProperties.LNF_QTE)==null){
        _prepStmt_.SetNull(_pos_++,SqlDbType.Int);
    }else{
        _prepStmt_.SetInt(_pos_++,data.LnfQte);
    }
      }
      if(data.ContainsLnfPrix()){
    if(data.GetProperty(LigneFactureProperties.LNF_PRIX)==null){
        _prepStmt_.SetNull(_pos_++,SqlDbType.Float);
    }else{
        _prepStmt_.SetDouble(_pos_++,data.LnfPrix);
    }
      }
      _prepStmt_.SetInt(_pos_++,data.LnfArtId);
      _prepStmt_.SetInt(_pos_++,data.LnfFacId);
      _ucount_=_prepStmt_.ExecuteUpdate();
      _prepStmt_.Close();
      if(_ucount_<=0){
        throw new UpdateDataException();
      }
      // START data.postUpdate.userCode
      // code retreived from data.postUpdate.userCode
      // END   data.postUpdate.userCode
    }catch(SqlException sqlExcp){
      throw new UpdateDataException(sqlExcp);
    }
  }

  /**
  * @class:generator JBGen
  */
  public void Delete(LigneFactureKey key){
    SqlConnection  _conn_=null;
    try{
      _conn_=GetConnection();
      // START data.preDelete.userCode
      // code retreived from data.preDelete.userCode
      // END   data.preDelete.userCode
      int _ucount_=0;
      String _removeStatement_ = null;
      PreparedStatement _prepStmt_ = null;
      _removeStatement_ = "DELETE FROM LIGNE_FACTURE WHERE LNF_ART_ID = ?  AND LNF_FAC_ID = ? ";
      _prepStmt_ = new PreparedStatement(_conn_,_removeStatement_);
      _prepStmt_.SetInt(1,(key.GetLnfArtId()));
      _prepStmt_.SetInt(2,(key.GetLnfFacId()));
      _ucount_=_prepStmt_.ExecuteUpdate();
      _prepStmt_.Close();
      if(_ucount_<=0){
        throw new RemoveDataException();
      }
      // START data.postDelete.userCode
      // code retreived from data.postDelete.userCode
      // END   data.postDelete.userCode
    }catch(SqlException sqlExcp){
      throw new RemoveDataException(sqlExcp);
    }
  }

  /**
  * @class:generator JBGen
  */
  public LigneFactureDTO GetData(LigneFactureProperties propertyList, LigneFactureKey primaryKey){
    String where="LIGNE_FACTURE.LNF_ART_ID = ? AND LIGNE_FACTURE.LNF_FAC_ID = ?";
    Criteria criteria=new Criteria(where);
    criteria.SetInt(1,primaryKey.GetLnfArtId());
    criteria.SetInt(2,primaryKey.GetLnfFacId());
    ICollection collection=Select(propertyList,criteria,null);
    if(collection.Count>0){
      for(IEnumerator i=collection.GetEnumerator();i.MoveNext();){
        return (LigneFactureDTO) i.Current;
      }
    }
     throw new DataNotFoundException();

  }

  /**
  * @class:generator JBGen
  */
  public bool Exists(LigneFactureKey primaryKey){
     LigneFactureProperties propertyList=new LigneFactureProperties();
    propertyList.AddLnfArtId();
    propertyList.AddLnfFacId();
    String where="LIGNE_FACTURE.LNF_ART_ID = ? AND LIGNE_FACTURE.LNF_FAC_ID = ?";
    Criteria criteria=new Criteria(where);
    criteria.SetInt(1,primaryKey.GetLnfArtId());
    criteria.SetInt(2,primaryKey.GetLnfFacId());
    ICollection collection=Select(propertyList,criteria,null);
    if(collection.Count>0){
      for(IEnumerator i=collection.GetEnumerator();i.MoveNext();){
        return true;
      }
    }
     return false;

  }

  /**
  * @class:generator JBGen
  */
  public ICollection Select(LigneFactureProperties propertyList, Criteria criteria, OrderList order){
    SqlConnection  _conn_=null;
    try{
      _conn_=GetConnection();
      StringBuilder _selectStatement_ = new StringBuilder("SELECT ");
      if(criteria!=null && criteria.IsDistinct()){
        _selectStatement_.Append("DISTINCT ");
      }
      ArrayList _sqlStatementParamsProviderArrayList_=new ArrayList();
      if(propertyList==null){
        _selectStatement_.Append("(LIGNE_FACTURE.LNF_ART_ID),(LIGNE_FACTURE.LNF_FAC_ID),(LIGNE_FACTURE.LNF_ART_ID),(LIGNE_FACTURE.LNF_FAC_ID),(LIGNE_FACTURE.LNF_QTE),(LIGNE_FACTURE.LNF_PRIX)");
      }else{
        StringBuilder sb=new StringBuilder("LNF_ART_ID,LNF_FAC_ID");
        for(IEnumerator i=propertyList.GetEnumerator();i.MoveNext();){
          String selectedFieldName=(String)i.Current;
          switch(selectedFieldName){
            case "LNF_FAC_ID":
            case "lnfFacId":{  //field lnfFacId
              if (sb.Length > 0) {
                sb.Append(" , ");
              }
              sb.Append("LIGNE_FACTURE.LNF_FAC_ID");

              break;
            }
            case "LNF_PRIX":
            case "lnfPrix":{  //field lnfPrix
              if (sb.Length > 0) {
                sb.Append(" , ");
              }
              sb.Append("LIGNE_FACTURE.LNF_PRIX");

              break;
            }
            case "LNF_ART_ID":
            case "lnfArtId":{  //field lnfArtId
              if (sb.Length > 0) {
                sb.Append(" , ");
              }
              sb.Append("LIGNE_FACTURE.LNF_ART_ID");

              break;
            }
            case "LNF_QTE":
            case "lnfQte":{  //field lnfQte
              if (sb.Length > 0) {
                sb.Append(" , ");
              }
              sb.Append("LIGNE_FACTURE.LNF_QTE");

              break;
            }
            default :{
              // default
              break;
            }
          }
        }
        _selectStatement_.Append(sb.ToString());
      }
      _selectStatement_.Append(" FROM LIGNE_FACTURE");
      if(criteria!=null && criteria.GetJoins()!=null){
        _selectStatement_.Append(" ");
        _selectStatement_.Append(criteria.GetJoins());
      }
      if(criteria!=null && criteria.GetWhereClause()!=null){
        _selectStatement_.Append(" WHERE ");
        _selectStatement_.Append(criteria.GetWhereClause());
      }
        if(order!=null){
          _selectStatement_.Append(" ORDER BY ");
          bool orderFirst=true;
        for(IEnumerator i=order.GetEnumerator();i.MoveNext();){
          OrderList.OrderItem item=(OrderList.OrderItem) i.Current;String selectedFieldName=item.GetFieldName();
          switch(selectedFieldName){
            case "LNF_FAC_ID":
            case "lnfFacId":{  //field lnfFacId
              if(orderFirst){
                orderFirst=false;
              }else{
                _selectStatement_.Append(" , ");
              }
              _selectStatement_.Append("LIGNE_FACTURE.LNF_FAC_ID");
              _selectStatement_.Append(" ").Append(item.IsAscendent()?"ASC":"DESC");
              break;    }
            case "LNF_PRIX":
            case "lnfPrix":{  //field lnfPrix
              if(orderFirst){
                orderFirst=false;
              }else{
                _selectStatement_.Append(" , ");
              }
              _selectStatement_.Append("LIGNE_FACTURE.LNF_PRIX");
              _selectStatement_.Append(" ").Append(item.IsAscendent()?"ASC":"DESC");
              break;    }
            case "LNF_ART_ID":
            case "lnfArtId":{  //field lnfArtId
              if(orderFirst){
                orderFirst=false;
              }else{
                _selectStatement_.Append(" , ");
              }
              _selectStatement_.Append("LIGNE_FACTURE.LNF_ART_ID");
              _selectStatement_.Append(" ").Append(item.IsAscendent()?"ASC":"DESC");
              break;    }
            case "LNF_QTE":
            case "lnfQte":{  //field lnfQte
              if(orderFirst){
                orderFirst=false;
              }else{
                _selectStatement_.Append(" , ");
              }
              _selectStatement_.Append("LIGNE_FACTURE.LNF_QTE");
              _selectStatement_.Append(" ").Append(item.IsAscendent()?"ASC":"DESC");
              break;    }
            default :{
              //WHEN UNKNOWN FIELD PASSED AS IS TO SQL
              if(orderFirst){
                orderFirst=false;
              }else{
                _selectStatement_.Append(" , ");
              }
              _selectStatement_.Append(selectedFieldName);
              _selectStatement_.Append(" ").Append(item.IsAscendent()?"ASC":"DESC");
              break;
            }
          }
        }
        }
        ArrayList list=new ArrayList();
        PreparedStatement _prepStmt_ = new PreparedStatement(_conn_,_selectStatement_.ToString());
        int _min_=-1;
        int _max_=-1;
        int _statementParamPos_=1;
        for(IEnumerator _i_=_sqlStatementParamsProviderArrayList_.GetEnumerator();_i_.MoveNext();){
          SqlStatementParamsProvider _p_=(SqlStatementParamsProvider) _i_.Current; 
          _statementParamPos_+=_p_.PopulateStatement(_prepStmt_,_statementParamPos_); 
        }
        if(criteria!=null){
          criteria.PopulateStatement(_prepStmt_,_statementParamPos_);
          _min_=criteria.GetMinRowIndex();
          _max_=criteria.GetMaxRowIndex();
        }
        ResultSet _rs_=_prepStmt_.ExecuteQuery();
        int _count_=0;
        while(_count_<_min_ && _rs_.MoveNext()){
          _count_++;
        }
      if(propertyList==null){
        while((_max_<0 || _count_<=_max_) && _rs_.MoveNext()){
          _count_++;
          LigneFactureKey _tableKey_ = new LigneFactureKey(_rs_.GetInt(1),_rs_.GetInt(2));
          LigneFactureDTO data=new LigneFactureDTO();
          data.LnfArtId=(_rs_.GetInt(3));
          if(_rs_.WasNull()){
            data.SetProperty(LigneFactureProperties.LNF_ART_ID,null);
          }
          data.LnfFacId=(_rs_.GetInt(4));
          if(_rs_.WasNull()){
            data.SetProperty(LigneFactureProperties.LNF_FAC_ID,null);
          }
          data.LnfQte=(_rs_.GetInt(5));
          if(_rs_.WasNull()){
            data.SetProperty(LigneFactureProperties.LNF_QTE,null);
          }
          data.LnfPrix=(_rs_.GetDouble(6));
          if(_rs_.WasNull()){
            data.SetProperty(LigneFactureProperties.LNF_PRIX,null);
          }
          list.Add(data);
        }
      }else{
        while((_max_<0 || _count_<=_max_) && _rs_.MoveNext()){
          _count_++;
          int _col_=3;
          LigneFactureKey _tableKey_ = new LigneFactureKey(_rs_.GetInt(1),_rs_.GetInt(2));
          LigneFactureDTO data=new LigneFactureDTO();
        for(IEnumerator i=propertyList.KeySet().GetEnumerator();i.MoveNext();){
          String selectedFieldName=(String)i.Current;
          switch(selectedFieldName){
            case "LNF_FAC_ID":
            case "lnfFacId":{  //field lnfFacId
              data.LnfFacId=(_rs_.GetInt(_col_++));
              if(_rs_.WasNull()){
                data.SetProperty(LigneFactureProperties.LNF_FAC_ID,null);
              }

              break;
            }
            case "LNF_PRIX":
            case "lnfPrix":{  //field lnfPrix
              data.LnfPrix=(_rs_.GetDouble(_col_++));
              if(_rs_.WasNull()){
                data.SetProperty(LigneFactureProperties.LNF_PRIX,null);
              }

              break;
            }
            case "LNF_ART_ID":
            case "lnfArtId":{  //field lnfArtId
              data.LnfArtId=(_rs_.GetInt(_col_++));
              if(_rs_.WasNull()){
                data.SetProperty(LigneFactureProperties.LNF_ART_ID,null);
              }

              break;
            }
            case "LNF_QTE":
            case "lnfQte":{  //field lnfQte
              data.LnfQte=(_rs_.GetInt(_col_++));
              if(_rs_.WasNull()){
                data.SetProperty(LigneFactureProperties.LNF_QTE,null);
              }

              break;
            }
            default :{
              // default
              break;
            }
          }
        }
          list.Add(data);
        }
      }
      _rs_.Close();
      _prepStmt_.Close();
      return list;
    }catch(SqlException sqlExcp){
      throw new DataRetrievalException(sqlExcp);
    }
  }

  /**
  * @class:generator JBGen
  */
  public ICollection Select(LigneFactureProperties propertyList, LigneFactureDTO prototype, OrderList order){
    return Select(propertyList,_buildCriteriaQBE_(prototype),order);

  }

  private static Criteria _buildCriteriaQBE_(LigneFactureDTO prototype){
      Criteria criteria=null;
      // building criteria
    if (prototype != null && prototype.Size() > 0) {
      StringBuilder whereClause = new StringBuilder();
      criteria = new Criteria();
      int pos=1;
      for(IEnumerator i=prototype.KeySet().GetEnumerator();i.MoveNext();){
        String selectedFieldName=(String)i.Current;
        switch(selectedFieldName){
          case "LNF_FAC_ID":
          case "lnfFacId":{  //field lnfFacId
            if (whereClause.Length > 1) {
              whereClause.Append(" AND ");
            }
            int columnValue = prototype.LnfFacId;
            whereClause.Append("LIGNE_FACTURE.LNF_FAC_ID = ?");
            criteria.SetInt(pos++,columnValue);
            break;
          }
          case "LNF_PRIX":
          case "lnfPrix":{  //field lnfPrix
            if (whereClause.Length > 1) {
              whereClause.Append(" AND ");
            }
            double columnValue = prototype.LnfPrix;
            whereClause.Append("LIGNE_FACTURE.LNF_PRIX = ?");
            criteria.SetDouble(pos++,columnValue);
            break;
          }
          case "LNF_ART_ID":
          case "lnfArtId":{  //field lnfArtId
            if (whereClause.Length > 1) {
              whereClause.Append(" AND ");
            }
            int columnValue = prototype.LnfArtId;
            whereClause.Append("LIGNE_FACTURE.LNF_ART_ID = ?");
            criteria.SetInt(pos++,columnValue);
            break;
          }
          case "LNF_QTE":
          case "lnfQte":{  //field lnfQte
            if (whereClause.Length > 1) {
              whereClause.Append(" AND ");
            }
            int columnValue = prototype.LnfQte;
            whereClause.Append("LIGNE_FACTURE.LNF_QTE = ?");
            criteria.SetInt(pos++,columnValue);
            break;
          }
          default :{
            throw new UnknownFieldException(selectedFieldName);

          }
        }
      }
    	criteria.SetWhereClause(whereClause.ToString());
    }
      // START method.findAll.userCode
      // code retreived from method.findAll.userCode
      // END   method.findAll.userCode

      return criteria;

  }

}
}
