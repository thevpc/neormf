using System;
using System.Collections;
using org.vpc.neormf.commons.beans;

namespace org.vpc.neormf.testjbgen.dto.lignefacture{
/**
* DO NOT EDIT MANUALLY
* GENERATED AUTOMATICALLY BY JBGen (0.1)
* @author Taha BEN SALAH (thevpc@walla.com)
* @organization Vpc Open Source Fondation 2001-2006
* @framework neormf (license GPL2)
* 
*/
public class LigneFactureProperties : org.vpc.neormf.commons.beans.PropertyList{
  public static String LNF_ART_ID="lnfArtId";
  public static String LNF_FAC_ID="lnfFacId";
  public static String LNF_QTE="lnfQte";
  public static String LNF_PRIX="lnfPrix";
  public static String[] ALL_PROPERTIES={LNF_ART_ID,LNF_FAC_ID,LNF_QTE,LNF_PRIX};
  /**
  * Constructor
  */
  public LigneFactureProperties(){

  }

  public LigneFactureProperties AddLnfArtId(){
    base.AddProperty(LNF_ART_ID);
    return this;
  }

  public LigneFactureProperties RemoveLnfArtId(){
    base.RemoveProperty(LNF_ART_ID);
    return this;
  }

  public bool ContainsLnfArtId(){
    return base.ContainsProperty(LNF_ART_ID);
  }

  public LigneFactureProperties AddLnfFacId(){
    base.AddProperty(LNF_FAC_ID);
    return this;
  }

  public LigneFactureProperties RemoveLnfFacId(){
    base.RemoveProperty(LNF_FAC_ID);
    return this;
  }

  public bool ContainsLnfFacId(){
    return base.ContainsProperty(LNF_FAC_ID);
  }

  public LigneFactureProperties AddLnfQte(){
    base.AddProperty(LNF_QTE);
    return this;
  }

  public LigneFactureProperties RemoveLnfQte(){
    base.RemoveProperty(LNF_QTE);
    return this;
  }

  public bool ContainsLnfQte(){
    return base.ContainsProperty(LNF_QTE);
  }

  public LigneFactureProperties AddLnfPrix(){
    base.AddProperty(LNF_PRIX);
    return this;
  }

  public LigneFactureProperties RemoveLnfPrix(){
    base.RemoveProperty(LNF_PRIX);
    return this;
  }

  public bool ContainsLnfPrix(){
    return base.ContainsProperty(LNF_PRIX);
  }

  public override void AddAllProperties(){
    base.AddAllProperties(ALL_PROPERTIES);

  }

  public override DataInfo Info(){
    return LigneFactureDTO.INFO;
  }

}
}
