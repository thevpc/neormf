using System;
using System.Collections;
using System.Data;
using System.Text;
using System.Data.SqlClient;
using org.vpc.neormf.commons.jwrapper;
using org.vpc.neormf.commons.beans;
using org.vpc.neormf.commons.exceptions;
using org.vpc.neormf.commons.types.converters;
using org.vpc.neormf.commons.sql;
using org.vpc.neormf.testjbgen.dto.facture;

namespace org.vpc.neormf.testjbgen.server.dao.facture{
/**
* DO NOT EDIT MANUALLY
* GENERATED AUTOMATICALLY BY JBGen (0.1)
* @author Taha BEN SALAH (thevpc@walla.com)
* @organization Vpc Open Source Fondation 2001-2006
* @framework neormf (license GPL2)
* 
*/
public class FactureDAO : DBConnector{
  private static org.vpc.neormf.commons.types.converters.DataTypeConverter facValid_converter=org.vpc.neormf.commons.types.converters.IntegerToBoolean.INTEGER_TO_BOOLEAN;
  /**
  * DBConnector Constructor
  */
  public FactureDAO(){

  }

  /**
  * DBConnector Constructor
  */
  public FactureDAO(DBConnector other) : base(other){

  }

  /**
  * DBConnector Constructor
  */
  public FactureDAO(SqlConnection cnx) : base(){
    SetConnection(cnx);
  }

  /**
  * DBConnector Constructor
  */
  public FactureDAO(SqlConnection cnx, String caller) : base(){
    SetConnection(cnx);
    SetCallerPrincipalName(caller);
  }

  /**
  * DBConnector Constructor
  * @class:generator JBGen
  */
  public FactureKey Insert(FactureDTO data){
    // START Prologue initialization
     int facId=0;
     bool facId_isNull_=false;
     DateTime facDate=DateTime.MinValue;
     bool facDate_isNull_=false;
     int facCliId=0;
     bool facCliId_isNull_=false;
     int facValid=0;
     bool facValid_isNull_=false;
    // END   Prologue initialization
    // START Prologue checking
    if(data.ContainsFacId()){
      throw new ForbiddenFieldOnInsertException(FactureDTO.INFO.GetField(FactureProperties.FAC_ID));
    }
    if(!data.ContainsFacDate()){
      throw new RequiredFieldOnInsertException(FactureDTO.INFO.GetField(FactureProperties.FAC_DATE));
    }
    if(!data.ContainsFacCliId()){
      throw new RequiredFieldOnInsertException(FactureDTO.INFO.GetField(FactureProperties.FAC_CLI_ID));
    }
    if(data.ContainsFacValid()){
      throw new ForbiddenFieldOnInsertException(FactureDTO.INFO.GetField(FactureProperties.FAC_VALID));
    }
    // END  Prologue checking

    SqlConnection  _conn_=null;
    String _insertStatement_ = null;
    PreparedStatement _prepStmt_  = null;
    try{
      _conn_=GetConnection();

      // START data.preInsert.userCode
      // code retreived from data.preInsert.userCode
      // END   data.preInsert.userCode
      // START Local Fields Updates
    for(IEnumerator i=data.KeySet().GetEnumerator();i.MoveNext();){
      String selectedFieldName=(String)i.Current;
      switch(selectedFieldName){
        case "facMnt":
        case "facMnt":{  //field facMnt
          // facMnt is a view field
          break;    }
        case "FAC_ID":
        case "facId":{  //field facId
            // START field.facId.preInsert.userCode
            // code retreived from field.facId.preInsert.userCode
            // END   field.facId.preInsert.userCode
          if(data.GetProperty(FactureProperties.FAC_ID)==null){
            facId_isNull_=true;
          }else{
            facId=(data.FacId);
          }
            // START field.facId.postInsert.userCode
            // code retreived from field.facId.postInsert.userCode
            // END   field.facId.postInsert.userCode
          break;    }
        case "FAC_DATE":
        case "facDate":{  //field facDate
            // START field.facDate.preInsert.userCode
            // code retreived from field.facDate.preInsert.userCode
            // END   field.facDate.preInsert.userCode
          if(data.GetProperty(FactureProperties.FAC_DATE)==null){
            facDate_isNull_=true;
          }else{
            facDate=(data.FacDate);
          }
            // START field.facDate.postInsert.userCode
            // code retreived from field.facDate.postInsert.userCode
            // END   field.facDate.postInsert.userCode
          break;    }
        case "FAC_CLI_ID":
        case "facCliId":{  //field facCliId
            // START field.facCliId.preInsert.userCode
            // code retreived from field.facCliId.preInsert.userCode
            // END   field.facCliId.preInsert.userCode
          if(data.GetProperty(FactureProperties.FAC_CLI_ID)==null){
            facCliId_isNull_=true;
          }else{
            facCliId=(data.FacCliId);
          }
            // START field.facCliId.postInsert.userCode
            // code retreived from field.facCliId.postInsert.userCode
            // END   field.facCliId.postInsert.userCode
          break;    }
        case "FAC_VALID":
        case "facValid":{  //field facValid
            // START field.facValid.preInsert.userCode
            // code retreived from field.facValid.preInsert.userCode
            // END   field.facValid.preInsert.userCode
          if(data.GetProperty(FactureProperties.FAC_VALID)==null){
            facValid_isNull_=true;
          }else{
            facValid=(((int)facValid_converter.BusinessToSQL((data.FacValid))));
          }
            // START field.facValid.postInsert.userCode
            // code retreived from field.facValid.postInsert.userCode
            // END   field.facValid.postInsert.userCode
          break;    }
        default :{
          throw new UnknownFieldException(selectedFieldName);
        }
      }
    }
      // END   Local Fields Updates

      // START Database persistance
      _insertStatement_ = "INSERT INTO FACTURE(FAC_DATE, FAC_CLI_ID, FAC_VALID) VALUES (?, ?, ?)";
      _prepStmt_ = new PreparedStatement(_conn_,_insertStatement_);
    if(facDate_isNull_){
      _prepStmt_.SetNull(1,SqlDbType.Timestamp);
    }else{
      _prepStmt_.SetTimestamp(1,facDate);
    }
    if(facCliId_isNull_){
      _prepStmt_.SetNull(2,SqlDbType.Int);
    }else{
      _prepStmt_.SetInt(2,facCliId);
    }
    if(facValid_isNull_){
      _prepStmt_.SetNull(3,SqlDbType.Int);
    }else{
      _prepStmt_.SetInt(3,facValid);
    }
      _prepStmt_.ExecuteUpdate();
      _prepStmt_.Close();


      // START Sequence Handling
      String _selectNewIdStatement_ = "SELECT @@IDENTITY";
      _prepStmt_ = new PreparedStatement(_conn_,_selectNewIdStatement_);
      ResultSet _rs_=_prepStmt_.ExecuteQuery();
      if(_rs_.MoveNext()){
        data.FacId=(_rs_.GetInt(1));
        _rs_.Close();
        _prepStmt_.Close();
      }
      _rs_.Close();
      _prepStmt_.Close();
      // END Sequence Handling
      // START data.postInsert.userCode
      // code retreived from data.postInsert.userCode
      // END   data.postInsert.userCode
      // END   Database persistance

      // returning Identifier;
      return data.GetFactureKey();
    }catch(SqlException sqlExcp){
      throw new CreateDataException(sqlExcp);
    }
  }

  /**
  * @class:generator JBGen
  */
  public void Update(FactureDTO data){
    if(data.Size()==0){
      return;
    }
    // START Prologue Checking
    // END   ForbiddenFieldOnUpdate Cheking

      // START data.preUpdate.userCode
      // code retreived from data.preUpdate.userCode
      // END   data.preUpdate.userCode
    SqlConnection  _conn_=null;
    try{
      _conn_=GetConnection();
      StringBuilder _updateStatement_ = new StringBuilder();
      int _ucount_ = 0;
      PreparedStatement _prepStmt_ = null;
      bool _firstColumn_=true;
      _updateStatement_.Append( "UPDATE FACTURE SET ");
      if(data.ContainsFacDate()){
        if(_firstColumn_){
          _firstColumn_=false;
        }else{
          _updateStatement_.Append(", ");
        }
        _updateStatement_.Append("FAC_DATE=? ");
      }
      if(data.ContainsFacCliId()){
        if(_firstColumn_){
          _firstColumn_=false;
        }else{
          _updateStatement_.Append(", ");
        }
        _updateStatement_.Append("FAC_CLI_ID=? ");
      }
      if(data.ContainsFacValid()){
        if(_firstColumn_){
          _firstColumn_=false;
        }else{
          _updateStatement_.Append(", ");
        }
        _updateStatement_.Append("FAC_VALID=? ");
      }
    _updateStatement_.Append(" WHERE FAC_ID = ? ");
      _prepStmt_ = new PreparedStatement(_conn_,_updateStatement_.ToString());
      int _pos_=1;
      if(data.ContainsFacDate()){
    if(data.GetProperty(FactureProperties.FAC_DATE)==null){
        _prepStmt_.SetNull(_pos_++,SqlDbType.Timestamp);
    }else{
        _prepStmt_.SetTimestamp(_pos_++,data.FacDate);
    }
      }
      if(data.ContainsFacCliId()){
    if(data.GetProperty(FactureProperties.FAC_CLI_ID)==null){
        _prepStmt_.SetNull(_pos_++,SqlDbType.Int);
    }else{
        _prepStmt_.SetInt(_pos_++,data.FacCliId);
    }
      }
      if(data.ContainsFacValid()){
    if(data.GetProperty(FactureProperties.FAC_VALID)==null){
        _prepStmt_.SetNull(_pos_++,SqlDbType.Int);
    }else{
        _prepStmt_.SetInt(_pos_++,(((int)facValid_converter.BusinessToSQL(data.FacValid))));
    }
      }
      _prepStmt_.SetInt(_pos_++,data.FacId);
      _ucount_=_prepStmt_.ExecuteUpdate();
      _prepStmt_.Close();
      if(_ucount_<=0){
        throw new UpdateDataException();
      }
      // START data.postUpdate.userCode
      // code retreived from data.postUpdate.userCode
      // END   data.postUpdate.userCode
    }catch(SqlException sqlExcp){
      throw new UpdateDataException(sqlExcp);
    }
  }

  /**
  * @class:generator JBGen
  */
  public void Delete(FactureKey key){
    SqlConnection  _conn_=null;
    try{
      _conn_=GetConnection();
      // START data.preDelete.userCode
      // code retreived from data.preDelete.userCode
      // END   data.preDelete.userCode
      int _ucount_=0;
      String _removeStatement_ = null;
      PreparedStatement _prepStmt_ = null;
      _removeStatement_ = "DELETE FROM FACTURE WHERE FAC_ID = ? ";
      _prepStmt_ = new PreparedStatement(_conn_,_removeStatement_);
      _prepStmt_.SetInt(1,(key.GetFacId()));
      _ucount_=_prepStmt_.ExecuteUpdate();
      _prepStmt_.Close();
      if(_ucount_<=0){
        throw new RemoveDataException();
      }
      // START data.postDelete.userCode
      // code retreived from data.postDelete.userCode
      // END   data.postDelete.userCode
    }catch(SqlException sqlExcp){
      throw new RemoveDataException(sqlExcp);
    }
  }

  /**
  * @class:generator JBGen
  */
  public FactureDTO GetData(FactureProperties propertyList, FactureKey primaryKey){
    String where="FACTURE.FAC_ID = ?";
    Criteria criteria=new Criteria(where);
    criteria.SetInt(1,primaryKey.GetFacId());
    ICollection collection=Select(propertyList,criteria,null);
    if(collection.Count>0){
      for(IEnumerator i=collection.GetEnumerator();i.MoveNext();){
        return (FactureDTO) i.Current;
      }
    }
     throw new DataNotFoundException();

  }

  /**
  * @class:generator JBGen
  */
  public bool Exists(FactureKey primaryKey){
     FactureProperties propertyList=new FactureProperties();
    propertyList.AddFacId();
    String where="FACTURE.FAC_ID = ?";
    Criteria criteria=new Criteria(where);
    criteria.SetInt(1,primaryKey.GetFacId());
    ICollection collection=Select(propertyList,criteria,null);
    if(collection.Count>0){
      for(IEnumerator i=collection.GetEnumerator();i.MoveNext();){
        return true;
      }
    }
     return false;

  }

  /**
  * @class:generator JBGen
  */
  public ICollection Select(FactureProperties propertyList, Criteria criteria, OrderList order){
    SqlConnection  _conn_=null;
    try{
      _conn_=GetConnection();
      StringBuilder _selectStatement_ = new StringBuilder("SELECT ");
      if(criteria!=null && criteria.IsDistinct()){
        _selectStatement_.Append("DISTINCT ");
      }
      ArrayList _sqlStatementParamsProviderArrayList_=new ArrayList();
      if(propertyList==null){
        _selectStatement_.Append("(FACTURE.FAC_ID),(FACTURE.FAC_ID),(FACTURE.FAC_DATE),(FACTURE.FAC_CLI_ID),(FACTURE.FAC_VALID),((Select Sum(LNF_PRIX*LNF_QTE) From LIGNE_FACTURE Where FAC_ID=LNF_FAC_ID))");
      }else{
        StringBuilder sb=new StringBuilder("FAC_ID");
        for(IEnumerator i=propertyList.GetEnumerator();i.MoveNext();){
          String selectedFieldName=(String)i.Current;
          switch(selectedFieldName){
            case "facMnt":
            case "facMnt":{  //field facMnt
              if (sb.Length > 0) {
                sb.Append(" , ");
              }
              sb.Append("(Select Sum(LNF_PRIX*LNF_QTE) From LIGNE_FACTURE Where FAC_ID=LNF_FAC_ID)");

              break;
            }
            case "FAC_ID":
            case "facId":{  //field facId
              if (sb.Length > 0) {
                sb.Append(" , ");
              }
              sb.Append("FACTURE.FAC_ID");

              break;
            }
            case "FAC_DATE":
            case "facDate":{  //field facDate
              if (sb.Length > 0) {
                sb.Append(" , ");
              }
              sb.Append("FACTURE.FAC_DATE");

              break;
            }
            case "FAC_CLI_ID":
            case "facCliId":{  //field facCliId
              if (sb.Length > 0) {
                sb.Append(" , ");
              }
              sb.Append("FACTURE.FAC_CLI_ID");

              break;
            }
            case "FAC_VALID":
            case "facValid":{  //field facValid
              if (sb.Length > 0) {
                sb.Append(" , ");
              }
              sb.Append("FACTURE.FAC_VALID");

              break;
            }
            default :{
              // default
              break;
            }
          }
        }
        _selectStatement_.Append(sb.ToString());
      }
      _selectStatement_.Append(" FROM FACTURE");
      if(criteria!=null && criteria.GetJoins()!=null){
        _selectStatement_.Append(" ");
        _selectStatement_.Append(criteria.GetJoins());
      }
      if(criteria!=null && criteria.GetWhereClause()!=null){
        _selectStatement_.Append(" WHERE ");
        _selectStatement_.Append(criteria.GetWhereClause());
      }
        if(order!=null){
          _selectStatement_.Append(" ORDER BY ");
          bool orderFirst=true;
        for(IEnumerator i=order.GetEnumerator();i.MoveNext();){
          OrderList.OrderItem item=(OrderList.OrderItem) i.Current;String selectedFieldName=item.GetFieldName();
          switch(selectedFieldName){
            case "facMnt":
            case "facMnt":{  //field facMnt
              if(orderFirst){
                orderFirst=false;
              }else{
                _selectStatement_.Append(" , ");
              }
              _selectStatement_.Append("(Select Sum(LNF_PRIX*LNF_QTE) From LIGNE_FACTURE Where FAC_ID=LNF_FAC_ID)");
              _selectStatement_.Append(" ").Append(item.IsAscendent()?"ASC":"DESC");
              break;    }
            case "FAC_ID":
            case "facId":{  //field facId
              if(orderFirst){
                orderFirst=false;
              }else{
                _selectStatement_.Append(" , ");
              }
              _selectStatement_.Append("FACTURE.FAC_ID");
              _selectStatement_.Append(" ").Append(item.IsAscendent()?"ASC":"DESC");
              break;    }
            case "FAC_DATE":
            case "facDate":{  //field facDate
              if(orderFirst){
                orderFirst=false;
              }else{
                _selectStatement_.Append(" , ");
              }
              _selectStatement_.Append("FACTURE.FAC_DATE");
              _selectStatement_.Append(" ").Append(item.IsAscendent()?"ASC":"DESC");
              break;    }
            case "FAC_CLI_ID":
            case "facCliId":{  //field facCliId
              if(orderFirst){
                orderFirst=false;
              }else{
                _selectStatement_.Append(" , ");
              }
              _selectStatement_.Append("FACTURE.FAC_CLI_ID");
              _selectStatement_.Append(" ").Append(item.IsAscendent()?"ASC":"DESC");
              break;    }
            case "FAC_VALID":
            case "facValid":{  //field facValid
              if(orderFirst){
                orderFirst=false;
              }else{
                _selectStatement_.Append(" , ");
              }
              _selectStatement_.Append("FACTURE.FAC_VALID");
              _selectStatement_.Append(" ").Append(item.IsAscendent()?"ASC":"DESC");
              break;    }
            default :{
              //WHEN UNKNOWN FIELD PASSED AS IS TO SQL
              if(orderFirst){
                orderFirst=false;
              }else{
                _selectStatement_.Append(" , ");
              }
              _selectStatement_.Append(selectedFieldName);
              _selectStatement_.Append(" ").Append(item.IsAscendent()?"ASC":"DESC");
              break;
            }
          }
        }
        }
        ArrayList list=new ArrayList();
        PreparedStatement _prepStmt_ = new PreparedStatement(_conn_,_selectStatement_.ToString());
        int _min_=-1;
        int _max_=-1;
        int _statementParamPos_=1;
        for(IEnumerator _i_=_sqlStatementParamsProviderArrayList_.GetEnumerator();_i_.MoveNext();){
          SqlStatementParamsProvider _p_=(SqlStatementParamsProvider) _i_.Current; 
          _statementParamPos_+=_p_.PopulateStatement(_prepStmt_,_statementParamPos_); 
        }
        if(criteria!=null){
          criteria.PopulateStatement(_prepStmt_,_statementParamPos_);
          _min_=criteria.GetMinRowIndex();
          _max_=criteria.GetMaxRowIndex();
        }
        ResultSet _rs_=_prepStmt_.ExecuteQuery();
        int _count_=0;
        while(_count_<_min_ && _rs_.MoveNext()){
          _count_++;
        }
      if(propertyList==null){
        while((_max_<0 || _count_<=_max_) && _rs_.MoveNext()){
          _count_++;
          FactureKey _tableKey_ = new FactureKey(_rs_.GetInt(1));
          FactureDTO data=new FactureDTO();
          data.FacId=(_rs_.GetInt(2));
          if(_rs_.WasNull()){
            data.SetProperty(FactureProperties.FAC_ID,null);
          }
          data.FacDate=(_rs_.GetTimestamp(3));
          if(_rs_.WasNull()){
            data.SetProperty(FactureProperties.FAC_DATE,null);
          }
          data.FacCliId=(_rs_.GetInt(4));
          if(_rs_.WasNull()){
            data.SetProperty(FactureProperties.FAC_CLI_ID,null);
          }
          data.FacValid=(((bool)facValid_converter.SqlToBusiness(_rs_.GetInt(5))));
          if(_rs_.WasNull()){
            data.SetProperty(FactureProperties.FAC_VALID,null);
          }
          data.FacMnt=(_rs_.GetDouble(6));
          if(_rs_.WasNull()){
            data.SetProperty(FactureProperties.FAC_MNT,null);
          }
          list.Add(data);
        }
      }else{
        while((_max_<0 || _count_<=_max_) && _rs_.MoveNext()){
          _count_++;
          int _col_=2;
          FactureKey _tableKey_ = new FactureKey(_rs_.GetInt(1));
          FactureDTO data=new FactureDTO();
        for(IEnumerator i=propertyList.KeySet().GetEnumerator();i.MoveNext();){
          String selectedFieldName=(String)i.Current;
          switch(selectedFieldName){
            case "facMnt":
            case "facMnt":{  //field facMnt
              data.FacMnt=(_rs_.GetDouble(_col_++));
              if(_rs_.WasNull()){
                data.SetProperty(FactureProperties.FAC_MNT,null);
              }

              break;
            }
            case "FAC_ID":
            case "facId":{  //field facId
              data.FacId=(_rs_.GetInt(_col_++));
              if(_rs_.WasNull()){
                data.SetProperty(FactureProperties.FAC_ID,null);
              }

              break;
            }
            case "FAC_DATE":
            case "facDate":{  //field facDate
              data.FacDate=(_rs_.GetTimestamp(_col_++));
              if(_rs_.WasNull()){
                data.SetProperty(FactureProperties.FAC_DATE,null);
              }

              break;
            }
            case "FAC_CLI_ID":
            case "facCliId":{  //field facCliId
              data.FacCliId=(_rs_.GetInt(_col_++));
              if(_rs_.WasNull()){
                data.SetProperty(FactureProperties.FAC_CLI_ID,null);
              }

              break;
            }
            case "FAC_VALID":
            case "facValid":{  //field facValid
              data.FacValid=(((bool)facValid_converter.SqlToBusiness(_rs_.GetInt(_col_++))));
              if(_rs_.WasNull()){
                data.SetProperty(FactureProperties.FAC_VALID,null);
              }

              break;
            }
            default :{
              // default
              break;
            }
          }
        }
          list.Add(data);
        }
      }
      _rs_.Close();
      _prepStmt_.Close();
      return list;
    }catch(SqlException sqlExcp){
      throw new DataRetrievalException(sqlExcp);
    }
  }

  /**
  * @class:generator JBGen
  */
  public ICollection Select(FactureProperties propertyList, FactureDTO prototype, OrderList order){
    return Select(propertyList,_buildCriteriaQBE_(prototype),order);

  }

  private static Criteria _buildCriteriaQBE_(FactureDTO prototype){
      Criteria criteria=null;
      // building criteria
    if (prototype != null && prototype.Size() > 0) {
      StringBuilder whereClause = new StringBuilder();
      criteria = new Criteria();
      int pos=1;
      for(IEnumerator i=prototype.KeySet().GetEnumerator();i.MoveNext();){
        String selectedFieldName=(String)i.Current;
        switch(selectedFieldName){
          case "facMnt":
          case "facMnt":{  //field facMnt
            if (whereClause.Length > 1) {
              whereClause.Append(" AND ");
            }
            double columnValue = prototype.FacMnt;
            whereClause.Append("(Select Sum(LNF_PRIX*LNF_QTE) From LIGNE_FACTURE Where FAC_ID=LNF_FAC_ID) = ?");
            criteria.SetDouble(pos++,columnValue);
            break;
          }
          case "FAC_ID":
          case "facId":{  //field facId
            if (whereClause.Length > 1) {
              whereClause.Append(" AND ");
            }
            int columnValue = prototype.FacId;
            whereClause.Append("FACTURE.FAC_ID = ?");
            criteria.SetInt(pos++,columnValue);
            break;
          }
          case "FAC_DATE":
          case "facDate":{  //field facDate
            if (whereClause.Length > 1) {
              whereClause.Append(" AND ");
            }
            DateTime columnValue = prototype.FacDate;
            whereClause.Append("FACTURE.FAC_DATE = ?");
            criteria.SetTimestamp(pos++,columnValue);
            break;
          }
          case "FAC_CLI_ID":
          case "facCliId":{  //field facCliId
            if (whereClause.Length > 1) {
              whereClause.Append(" AND ");
            }
            int columnValue = prototype.FacCliId;
            whereClause.Append("FACTURE.FAC_CLI_ID = ?");
            criteria.SetInt(pos++,columnValue);
            break;
          }
          case "FAC_VALID":
          case "facValid":{  //field facValid
            if (whereClause.Length > 1) {
              whereClause.Append(" AND ");
            }
            int columnValue = (((int)facValid_converter.BusinessToSQL(prototype.FacValid)));
            whereClause.Append("FACTURE.FAC_VALID = ?");
            criteria.SetInt(pos++,columnValue);
            break;
          }
          default :{
            throw new UnknownFieldException(selectedFieldName);

          }
        }
      }
    	criteria.SetWhereClause(whereClause.ToString());
    }
      // START method.findAll.userCode
      // code retreived from method.findAll.userCode
      // END   method.findAll.userCode

      return criteria;

  }

  public double GetFacMnt(FactureKey tableKey){
    int facId=tableKey.GetFacId();
    SqlConnection  _conn_=null;
    String _selectStatement_ = null;
    PreparedStatement _prepStmt_  = null;
    ResultSet _rs_  = null;
    try{
      _conn_=GetConnection();
      _selectStatement_="Select ((Select Sum(LNF_PRIX*LNF_QTE) From LIGNE_FACTURE Where FAC_ID=LNF_FAC_ID)) FROM FACTURE WHERE FAC_ID = ?";
      _prepStmt_ = new PreparedStatement(_conn_,_selectStatement_);
      _prepStmt_.SetInt(1,facId);
      _rs_=_prepStmt_.ExecuteQuery();
      if(_rs_.MoveNext()){
        return _rs_.GetDouble(1);
      }else{
        throw new DataNotFoundException();
      }
    }catch(SqlException sqlExcp){
      throw new DataRetrievalException(sqlExcp);
    }finally{
      try{
        if(_rs_!=null){
          _rs_.Close();
          _prepStmt_.Close();
        }
      }catch(Exception e){
        throw new DataRetrievalException(e);
      }
    }
  }

}
}
