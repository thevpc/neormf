IF EXISTS (SELECT name FROM master.dbo.sysdatabases WHERE name = N'neormfsample')
	DROP DATABASE [neormfsample]
GO

CREATE DATABASE [neormfsample]  ON (NAME = N'neormfsample_Data', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL\Data\neormfsample_Data.MDF' , SIZE = 1, FILEGROWTH = 10%) LOG ON (NAME = N'neormfsample_Log', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL\Data\neormfsample_Log.LDF' , SIZE = 1, FILEGROWTH = 10%)
 COLLATE French_CI_AS
GO

exec sp_dboption N'neormfsample', N'autoclose', N'true'
GO

exec sp_dboption N'neormfsample', N'bulkcopy', N'false'
GO

exec sp_dboption N'neormfsample', N'trunc. log', N'true'
GO

exec sp_dboption N'neormfsample', N'torn page detection', N'true'
GO

exec sp_dboption N'neormfsample', N'read only', N'false'
GO

exec sp_dboption N'neormfsample', N'dbo use', N'false'
GO

exec sp_dboption N'neormfsample', N'single', N'false'
GO

exec sp_dboption N'neormfsample', N'autoshrink', N'true'
GO

exec sp_dboption N'neormfsample', N'ANSI null default', N'false'
GO

exec sp_dboption N'neormfsample', N'recursive triggers', N'false'
GO

exec sp_dboption N'neormfsample', N'ANSI nulls', N'false'
GO

exec sp_dboption N'neormfsample', N'concat null yields null', N'false'
GO

exec sp_dboption N'neormfsample', N'cursor close on commit', N'false'
GO

exec sp_dboption N'neormfsample', N'default to local cursor', N'false'
GO

exec sp_dboption N'neormfsample', N'quoted identifier', N'false'
GO

exec sp_dboption N'neormfsample', N'ANSI warnings', N'false'
GO

exec sp_dboption N'neormfsample', N'auto create statistics', N'true'
GO

exec sp_dboption N'neormfsample', N'auto update statistics', N'true'
GO

if( (@@microsoftversion / power(2, 24) = 8) and (@@microsoftversion & 0xffff >= 724) )
	exec sp_dboption N'neormfsample', N'db chaining', N'false'
GO

use [neormfsample]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_FACTURE_CLIENT]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[FACTURE] DROP CONSTRAINT FK_FACTURE_CLIENT
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_CLIENT_CLIENT_INFO]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[CLIENT] DROP CONSTRAINT FK_CLIENT_CLIENT_INFO
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_LIGNE_FACTURE_FACTURE]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[LIGNE_FACTURE] DROP CONSTRAINT FK_LIGNE_FACTURE_FACTURE
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[CLIENT]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[CLIENT]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[CLIENT_INFO]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[CLIENT_INFO]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FACTURE]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[FACTURE]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[LIGNE_FACTURE]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[LIGNE_FACTURE]
GO

CREATE TABLE [dbo].[CLIENT] (
	[CLI_ID] [int] IDENTITY (1, 1) NOT NULL ,
	[CLI_NOM] [varchar] (50) COLLATE French_CI_AS NULL ,
	[CLI_ADDRESSE] [varchar] (255) COLLATE French_CI_AS NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[CLIENT_INFO] (
	[CLI_ID] [int] NOT NULL ,
	[CLI_ADDRESSE_2] [varchar] (255) COLLATE French_CI_AS NULL ,
	[CL_ADDRESSE_3] [varchar] (255) COLLATE French_CI_AS NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[FACTURE] (
	[FAC_ID] [int] IDENTITY (1, 1) NOT NULL ,
	[FAC_DATE] [datetime] NOT NULL ,
	[FAC_CLI_ID] [int] NOT NULL ,
	[FAC_VALID] [int] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[LIGNE_FACTURE] (
	[LNF_ART_ID] [int] NOT NULL ,
	[LNF_FAC_ID] [int] NOT NULL ,
	[LNF_QTE] [int] NULL ,
	[LNF_PRIX] [float] NULL 
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[CLIENT] WITH NOCHECK ADD 
	CONSTRAINT [PK_CLIENT] PRIMARY KEY  CLUSTERED 
	(
		[CLI_ID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[CLIENT_INFO] WITH NOCHECK ADD 
	CONSTRAINT [PK_CLIENT_INFO] PRIMARY KEY  CLUSTERED 
	(
		[CLI_ID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[FACTURE] WITH NOCHECK ADD 
	CONSTRAINT [PK_FACTURE] PRIMARY KEY  CLUSTERED 
	(
		[FAC_ID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[LIGNE_FACTURE] WITH NOCHECK ADD 
	CONSTRAINT [PK_LIGNE_FACTURE] PRIMARY KEY  CLUSTERED 
	(
		[LNF_ART_ID],
		[LNF_FAC_ID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[CLIENT] ADD 
	CONSTRAINT [FK_CLIENT_CLIENT_INFO] FOREIGN KEY 
	(
		[CLI_ID]
	) REFERENCES [dbo].[CLIENT_INFO] (
		[CLI_ID]
	)
GO

ALTER TABLE [dbo].[FACTURE] ADD 
	CONSTRAINT [FK_FACTURE_CLIENT] FOREIGN KEY 
	(
		[FAC_CLI_ID]
	) REFERENCES [dbo].[CLIENT] (
		[CLI_ID]
	)
GO

ALTER TABLE [dbo].[LIGNE_FACTURE] ADD 
	CONSTRAINT [FK_LIGNE_FACTURE_FACTURE] FOREIGN KEY 
	(
		[LNF_FAC_ID]
	) REFERENCES [dbo].[FACTURE] (
		[FAC_ID]
	)
GO

